"""Models used by the core orchestration layer.

These models are intentionally UI-agnostic so they can be used by CLI and the
future web interface.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from audiomason.core.context import ProcessingContext


def _new_job_meta() -> dict[str, str]:
    return {}


@dataclass(frozen=True)
class ProcessRequest:
    contexts: list[ProcessingContext]
    pipeline_path: Path
    plugin_loader: Any


@dataclass(frozen=True)
class ProcessContractRequest:
    contract_id: str
    plugin_name: str
    entrypoint_name: str
    plugin_loader: Any
    job_meta: dict[str, str] = field(default_factory=_new_job_meta)
