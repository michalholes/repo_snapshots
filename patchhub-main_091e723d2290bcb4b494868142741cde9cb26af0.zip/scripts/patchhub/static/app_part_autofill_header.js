/// <reference path="../../../types/am2-globals.d.ts" />
var autofillHeaderWindow = /** @type {PatchhubAutofillHeaderWindow} */ (window);
var autofillHeaderBridge = autofillHeaderWindow;
/** @type {PatchhubHeaderRuntime | null} */
var PH = autofillHeaderWindow.PH || null;
/** @type {PatchhubHeaderSummary} */
var headerSummaryCache = {};

/**
 * @param {string} name
 * @param {...unknown} args
 * @returns {unknown}
 */
function phCall(name, ...args) {
	if (!PH || typeof PH.call !== "function") return undefined;
	return PH.call(name, ...args);
}

function isProtectedRerunLatestLifecycleActive() {
	return !!phCall("isProtectedRerunLatestLifecycleActive");
}
/** @type {PatchhubHeaderDiagnostics | null} */
var headerDiagnosticsCache = null;
function prepareFormForNewPatchLoad() {
	if (isProtectedRerunLatestLifecycleActive()) return false;
	try {
		if (typeof dirty === "object" && dirty) {
			dirty.issueId = false;
			dirty.commitMsg = false;
			dirty.patchPath = false;
			dirty.targetRepo = false;
		}
	} catch (_) {}
	phCall("clearGateOverrides");
	try {
		const m = el("mode");
		if (m) m.value = "patch";
		const rc = el("rawCommand");
		if (rc) rc.value = "";
	} catch (_) {}
	try {
		const next = Number(autofillHeaderBridge.__ph_patch_load_seq || 0) + 1;
		autofillHeaderBridge.__ph_patch_load_seq = next;
	} catch (_) {}
	return true;
}

function applyAutofillFromPayload(
	/** @type {PatchhubLatestPatchResponse} */ p,
) {
	if (isProtectedRerunLatestLifecycleActive()) return false;
	if (!cfg || !cfg.autofill || !p) return false;

	if (cfg.autofill.fill_patch_path && p.stored_rel_path) {
		const n1 = el("patchPath");
		if (n1 && phCall("shouldOverwriteField", "patchPath", n1)) {
			n1.value = String(p.stored_rel_path);
		}
	}

	if (cfg.autofill.fill_issue_id && p.derived_issue != null) {
		const n2 = el("issueId");
		if (n2 && phCall("shouldOverwriteField", "issueId", n2)) {
			n2.value = String(p.derived_issue || "");
		}
	}

	if (cfg.autofill.fill_commit_message && p.derived_commit_message != null) {
		const n3 = el("commitMsg");
		if (n3 && phCall("shouldOverwriteField", "commitMsg", n3)) {
			n3.value = String(p.derived_commit_message || "");
		}
	}

	if (
		cfg.targeting &&
		cfg.targeting.zip_target_prefill_enabled &&
		p.derived_target_repo != null
	) {
		const n4 = el("targetRepo");
		if (n4 && phCall("shouldOverwriteField", "targetRepo", n4)) {
			n4.value = String(p.derived_target_repo || "");
		}
	}

	phCall("validateAndPreview");
	return true;
}

function resetOutputForNewPatch() {
	selectedJobId = null;
	AMP_UI.saveLiveJobId("");

	phCall("openLiveStream", null);
	setPre("tail", "");
	phCall("updateShortProgressFromText", "");

	suppressIdleOutput = true;

	if (cfg && cfg.ui && cfg.ui.show_autofill_clear_status) {
		setUiStatus("autofill: loaded new patch, output cleared");
	}
}

function pollLatestPatchOnce() {
	if (!cfg || !cfg.autofill || !cfg.autofill.enabled) return;
	var qs = latestToken
		? "?since_token=" + encodeURIComponent(String(latestToken))
		: "";
	apiGetETag("patches_latest", "/api/patches/latest" + qs).then((r) => {
		var latest = /** @type {PatchhubLatestPatchResponse} */ (r || {});
		if (!r || latest.ok === false) {
			setUiError(String(latest.error || "autofill scan failed"));
			return;
		}

		if (latest.unchanged) return;
		pushApiStatus(latest);
		if (!latest.found) return;
		var token = String(latest.token || "");
		if (!token || token === latestToken) return;
		latestToken = token;
		if (isProtectedRerunLatestLifecycleActive()) {
			if (cfg && cfg.ui && cfg.ui.clear_output_on_autofill) {
				if (token !== lastAutofillClearedToken) {
					resetOutputForNewPatch();
					lastAutofillClearedToken = token;
				}
			}
			return;
		}
		// New patch token: reset UI state deterministically.
		prepareFormForNewPatchLoad();
		applyAutofillFromPayload(latest);

		if (cfg && cfg.ui && cfg.ui.clear_output_on_autofill) {
			if (token !== lastAutofillClearedToken) {
				resetOutputForNewPatch();
				lastAutofillClearedToken = token;
			}
		}
	});
}

function stopAutofillPolling() {
	if (autofillTimer) {
		clearInterval(autofillTimer);
		autofillTimer = null;
	}
}

function startAutofillPolling() {
	if (autofillTimer) {
		clearInterval(autofillTimer);
		autofillTimer = null;
	}
	if (!cfg || !cfg.autofill || !cfg.autofill.enabled) return;
	var sec = parseInt(String(cfg.autofill.poll_interval_seconds || "10"), 10);
	if (isNaN(sec) || sec < 1) sec = 10;
	autofillTimer = setInterval(pollLatestPatchOnce, sec * 1000);
	pollLatestPatchOnce();
}

function headerBaseMeta(/** @type {string} */ base) {
	var meta = String(base || "");
	if (cfg && cfg.paths && cfg.paths.patches_root) {
		meta += " | patches: " + cfg.paths.patches_root;
	}
	return meta;
}

function extractHeaderSummary(/** @type {PatchhubHeaderDiagnostics} */ d) {
	var src = d || {};
	return {
		queue: src.queue || {},
		lock: src.lock || {},
		runs: src.runs || {},
		stats: src.stats || {},
	};
}

function buildHeaderSummaryMeta(
	/** @type {PatchhubHeaderSummary} */ summary,
	/** @type {string} */ base,
) {
	var meta = headerBaseMeta(base);
	/** @type {PatchhubHeaderLock} */
	var lock = (summary && summary.lock) || {};
	meta += lock.held ? " | LOCK:held" : " | LOCK:free";

	/** @type {PatchhubHeaderQueue} */
	var queue = (summary && summary.queue) || {};
	var q = Number(queue.queued || 0);
	var r = Number(queue.running || 0);
	if (!Number.isNaN(q) || !Number.isNaN(r)) {
		meta += " | queue:" + String(q) + "/" + String(r);
	}

	/** @type {PatchhubHeaderRuns} */
	var runs = (summary && summary.runs) || {};
	var count = Number(runs.count || 0);
	if (!Number.isNaN(count)) {
		meta += " | runs:" + String(count);
	}
	return meta;
}

function appendTelemetryMeta(
	/** @type {string} */ meta,
	/** @type {PatchhubHeaderDiagnostics} */ d,
) {
	/** @type {PatchhubDiagnosticsDisk} */
	var disk = (d && d.disk) || {};
	var pct = "";
	if (disk.total && disk.used) {
		pct = "disk:" + String(Math.round((disk.used / disk.total) * 100)) + "%";
	}
	if (pct) meta += " | " + pct;

	/** @type {PatchhubDiagnosticsResources} */
	var res = (d && d.resources) || {};
	/** @type {PatchhubDiagnosticsProcess} */
	var proc = res.process || {};
	/** @type {PatchhubDiagnosticsHost} */
	var host = res.host || {};
	var rss = "";
	var cpu = "";
	var net = "";
	var l1 = null;
	var rx = null;
	var tx = null;
	if (proc.rss_bytes) {
		rss = "rss:" + String(Math.round(proc.rss_bytes / 1048576)) + "MiB";
	}
	if (host.loadavg_1 != null) {
		l1 = Number(host.loadavg_1);
		if (!Number.isNaN(l1)) cpu = "cpu:load" + l1.toFixed(2);
	}
	if (host.net_rx_bytes_total != null && host.net_tx_bytes_total != null) {
		rx = Number(host.net_rx_bytes_total);
		tx = Number(host.net_tx_bytes_total);
		if (!Number.isNaN(rx) && !Number.isNaN(tx)) {
			net =
				"net:rx" +
				String(Math.round(rx / 1048576)) +
				"MiB tx" +
				String(Math.round(tx / 1048576)) +
				"MiB";
		}
	}
	if (rss) meta += " | " + rss;
	if (cpu) meta += " | " + cpu;
	if (net) meta += " | " + net;
	return meta;
}

function updateHeaderMeta(/** @type {string} */ base) {
	var meta = buildHeaderSummaryMeta(headerSummaryCache || {}, base);
	if (headerDiagnosticsCache) {
		meta = appendTelemetryMeta(meta, headerDiagnosticsCache);
	}
	if (el("hdrMeta")) el("hdrMeta").textContent = meta;
}

function renderHeaderFromSummary(
	/** @type {PatchhubHeaderSummary} */ summary,
	/** @type {string} */ base,
) {
	headerSummaryCache = extractHeaderSummary(summary);
	updateHeaderMeta(base);
}

function renderHeaderFromDiagnostics(
	/** @type {PatchhubHeaderDiagnostics} */ d,
	/** @type {string} */ base,
) {
	if (!d || d.ok === false) return;
	headerSummaryCache = extractHeaderSummary(d);
	headerDiagnosticsCache = d;
	updateHeaderMeta(base);
}

function refreshHeader(
	/** @type {{ mode?: string } | null | undefined} */ opts,
) {
	opts = opts || {};
	var mode = String(opts.mode || "user");
	var sf = mode === "periodic";

	var base = "";
	if (cfg && cfg.server && cfg.server.host && cfg.server.port) {
		base = "server: " + cfg.server.host + ":" + cfg.server.port;
	}

	apiGetETag("diagnostics", "/api/debug/diagnostics", {
		mode: mode,
		single_flight: sf,
	}).then((d) => {
		var diagnostics = /** @type {PatchhubDiagnosticsResponse} */ (d || {});
		if (!d || diagnostics.ok === false) return;
		if (diagnostics.unchanged) return;
		renderHeaderFromDiagnostics(diagnostics, base);
	});
}

function setTabActive(/** @type {string} */ which) {
	var tabs = ["Overview", "Logs", "Patch", "Diff", "Files"];
	tabs.forEach((t) => {
		var btn = el("tab" + t);
		if (btn) {
			if (t === which) btn.classList.add("active");
			else btn.classList.remove("active");
		}
	});
}

function renderIssueDetail() {
	var cardTitle = el("issueDetailTitle");
	var tabs = el("issueTabs");
	var content = el("issueTabContent");
	var links = el("issueTabLinks");
	var body = el("issueTabBody");

	if (!selectedRun) {
		if (cardTitle) cardTitle.textContent = "Select a run on the left.";
		if (tabs) tabs.style.display = "none";
		if (content) content.style.display = "none";
		return;
	}
	var run = selectedRun;

	if (cardTitle) {
		cardTitle.textContent =
			"Issue #" + String(run.issue_id) + " (" + String(run.result || "") + ")";
	}
	if (tabs) tabs.style.display = "flex";
	if (content) content.style.display = "block";

	function renderLinks() {
		/** @type {string[]} */
		var parts = [];

		function add(
			/** @type {string} */ label,
			/** @type {string | undefined} */ rel,
		) {
			if (!rel) return;
			parts.push(
				'<a class="linklike" href="/api/fs/download?path=' +
					encodeURIComponent(rel) +
					'">' +
					escapeHtml(label) +
					"</a>",
			);
		}

		add("log", run.log_rel_path);
		add("archived patch", run.archived_patch_rel_path);
		add("diff bundle", run.diff_bundle_rel_path);
		add("latest success zip", run.success_zip_rel_path);

		links.innerHTML = parts.join(" ");
	}

	function renderOverview() {
		setTabActive("Overview");
		renderLinks();
		setPre("issueTabBody", run);
	}

	function renderLogs() {
		setTabActive("Logs");
		renderLinks();
		if (!run.log_rel_path) {
			setPre("issueTabBody", "(no log path)");
			return;
		}
		var p = String(run.log_rel_path);
		var url =
			"/api/fs/read_text?path=" + encodeURIComponent(p) + "&tail_lines=2000";
		apiGet(url).then((r) => {
			var readText = /** @type {PatchhubReadTextResponse} */ (r || {});
			if (!r || readText.ok === false) {
				setPre("issueTabBody", r);
				return;
			}
			var t = String(readText.text || "");
			if (readText.truncated) {
				t += "\n\n[TRUNCATED]";
			}
			setPre("issueTabBody", t);
		});
	}

	function renderPatch() {
		setTabActive("Patch");
		renderLinks();
		if (run.archived_patch_rel_path) {
			setPre(
				"issueTabBody",
				"Download: /api/fs/download?path=" + run.archived_patch_rel_path,
			);
		} else {
			setPre("issueTabBody", "(no archived patch)");
		}
	}

	function renderDiff() {
		setTabActive("Diff");
		renderLinks();
		if (run.diff_bundle_rel_path) {
			setPre(
				"issueTabBody",
				"Download: /api/fs/download?path=" + run.diff_bundle_rel_path,
			);
		} else {
			setPre("issueTabBody", "(no diff bundle)");
		}
	}

	function renderFiles() {
		setTabActive("Files");
		renderLinks();
		// Convenience: jump file manager to the issue directory if possible.
		var p = "";
		if (run.log_rel_path) {
			p = parentRel(stripPatchesPrefix(run.log_rel_path));
		}
		if (p) {
			el("fsPath").value = p;
			fsSelected = "";
			setFsHint("");
			refreshFs();
		}
		setPre(
			"issueTabBody",
			"File manager path set to: " + String(el("fsPath").value || ""),
		);
	}

	el("tabOverview").onclick = renderOverview;
	el("tabLogs").onclick = renderLogs;
	el("tabPatch").onclick = renderPatch;
	el("tabDiff").onclick = renderDiff;
	el("tabFiles").onclick = renderFiles;

	// Default to overview when switching run.
	renderOverview();
}

if (PH && typeof PH.register === "function") {
	PH.register("app_part_autofill_header", {
		applyAutofillFromPayload,
		prepareFormForNewPatchLoad,
		stopAutofillPolling,
		startAutofillPolling,
		renderHeaderFromSummary,
		refreshHeader,
		renderIssueDetail,
	});
}
