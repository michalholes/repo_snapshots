(() => {
	/**
	 * @typedef {{ source?: string, text?: string }} InfoPoolLatestHint
	 * @typedef {{
	 *   upload?: string,
	 *   enqueue?: string,
	 *   fs?: string,
	 *   parse?: string,
	 * }} InfoPoolHints
	 * @typedef {{
	 *   degradedNotes?: string[],
	 *   statusLines?: string[],
	 *   hints?: InfoPoolHints,
	 *   latestHint?: InfoPoolLatestHint,
	 *   backendDegradedNote?: string,
	 * }} InfoPoolSnapshot
	 * @typedef {{
	 *   filename_pattern?: string,
	 *   keep_count?: number,
	 *   matched_count?: number,
	 *   deleted_count?: number,
	 * }} CleanupRecentStatusRule
	 * @typedef {{
	 *   job_id?: string,
	 *   issue_id?: string,
	 *   created_utc?: string,
	 *   deleted_count?: number,
	 *   rules?: CleanupRecentStatusRule[],
	 *   summary_text?: string,
	 * }} CleanupRecentStatusItem
	 * @typedef {{
	 *   mode?: string,
	 *   authoritative_backend?: string,
	 *   backend_session_id?: string,
	 *   recovery_status?: string,
	 *   recovery_action?: string,
	 *   recovery_detail?: string,
	 *   degraded?: boolean,
	 * }} BackendModeStatus
	 * @typedef {{
	 *   cleanup_recent_status?: CleanupRecentStatusItem[],
	 *   backend_mode_status?: BackendModeStatus,
	 * }} OperatorInfoSnapshot
	 */

	/** @type {Window & typeof globalThis} */
	var infoPoolWindow = window;
	/** @type {PatchhubHeaderRuntime | null} */
	var PH = infoPoolWindow.PH || null;

	/** @type {OperatorInfoSnapshot} */
	var operatorInfoSnapshot = {
		cleanup_recent_status: [],
		backend_mode_status: {},
	};

	var infoPoolOpen = false;
	var infoPoolBound = false;

	function infoPoolModalEl(/** @type {string} */ id) {
		return el(id);
	}

	/** @returns {InfoPoolSnapshot} */
	function infoPoolSnapshot() {
		if (typeof getInfoPoolSnapshot === "function") {
			return /** @type {InfoPoolSnapshot} */ (getInfoPoolSnapshot());
		}
		return {
			degradedNotes: [],
			statusLines: [],
			hints: { upload: "", enqueue: "", fs: "", parse: "" },
			latestHint: { source: "", text: "" },
		};
	}

	/** @returns {OperatorInfoSnapshot} */
	function infoPoolOperatorInfo() {
		return operatorInfoSnapshot;
	}

	function normalizeBackendModeStatus(/** @type {unknown} */ payload) {
		var source =
			payload && typeof payload === "object"
				? /** @type {BackendModeStatus} */ (payload)
				: {};
		return {
			mode: String(source.mode || ""),
			authoritative_backend: String(source.authoritative_backend || ""),
			backend_session_id: String(source.backend_session_id || ""),
			recovery_status: String(source.recovery_status || "not_run") || "not_run",
			recovery_action: String(source.recovery_action || ""),
			recovery_detail: String(source.recovery_detail || ""),
			degraded: !!source.degraded,
		};
	}

	function normalizeOperatorInfoSnapshot(/** @type {unknown} */ payload) {
		var source =
			payload && typeof payload === "object"
				? /** @type {OperatorInfoSnapshot} */ (payload)
				: {};
		return {
			cleanup_recent_status: Array.isArray(source.cleanup_recent_status)
				? source.cleanup_recent_status.slice()
				: [],
			backend_mode_status: normalizeBackendModeStatus(
				source.backend_mode_status,
			),
		};
	}

	function infoPoolBackendDegradedNoteFromOperatorInfo(
		/** @type {unknown} */ operatorInfo,
	) {
		var info = /** @type {OperatorInfoSnapshot} */ (
			operatorInfo && typeof operatorInfo === "object" ? operatorInfo : {}
		);
		var status = /** @type {BackendModeStatus} */ (
			info.backend_mode_status || {}
		);
		var parts = [
			status.recovery_action,
			status.recovery_detail,
			status.recovery_status,
		]
			.filter(Boolean)
			.map(String);
		if (!(status.degraded || String(status.mode || "") === "file_emergency")) {
			return "";
		}
		return parts.length
			? `Backend file_emergency: ${parts.slice(0, 2).join("; ")}`
			: "Backend file_emergency";
	}

	infoPoolWindow.PH_BACKEND_DEGRADED_FROM_OPERATOR_INFO =
		infoPoolBackendDegradedNoteFromOperatorInfo;
	function infoPoolCleanupSummaryText(
		/** @type {CleanupRecentStatusItem} */ item,
	) {
		var summary = String(item?.summary_text || "").trim();
		if (summary) return summary;
		var issue = String(item?.issue_id || "").trim();
		var deleted = Number(item?.deleted_count || 0);
		return (
			"Repo snapshot cleanup" +
			(issue ? ` issue ${issue}` : "") +
			": deleted " +
			String(deleted) +
			" file(s)"
		);
	}

	function infoPoolMergedStatusLines(
		/** @type {InfoPoolSnapshot} */ snapshot,
		/** @type {OperatorInfoSnapshot} */ operatorInfo,
	) {
		var lines = Array.isArray(snapshot.statusLines)
			? snapshot.statusLines.slice()
			: [];
		var cleanupItems = /** @type {CleanupRecentStatusItem[]} */ (
			Array.isArray(operatorInfo.cleanup_recent_status)
				? operatorInfo.cleanup_recent_status
				: []
		);
		cleanupItems.forEach((/** @type {CleanupRecentStatusItem} */ item) => {
			lines.push(infoPoolCleanupSummaryText(item));
		});
		return lines;
	}

	function infoPoolPmSummary() {
		if (!PH || typeof PH.call !== "function") return "";
		return String(PH.call("getPmValidationSummary") || "");
	}

	/** @returns {PatchhubPmValidationPayload | null} */
	function infoPoolPmSnapshot() {
		if (!PH || typeof PH.call !== "function") return null;
		var snapshot = PH.call("getPmValidationSnapshot");
		if (!snapshot || typeof snapshot !== "object") return null;
		return /** @type {PatchhubPmValidationPayload} */ (snapshot);
	}

	function infoPoolCurrentBackendNote(
		/** @type {OperatorInfoSnapshot} */ operatorInfo,
	) {
		return infoPoolBackendDegradedNoteFromOperatorInfo(operatorInfo);
	}

	function infoPoolDegradedItems(
		/** @type {InfoPoolSnapshot} */ snapshot,
		/** @type {OperatorInfoSnapshot} */ operatorInfo,
	) {
		var items = [];
		var backend = infoPoolCurrentBackendNote(operatorInfo);
		if (!backend) backend = String(snapshot.backendDegradedNote || "");
		if (backend) items.push(backend);
		var degraded = Array.isArray(snapshot.degradedNotes)
			? snapshot.degradedNotes
			: [];
		if (degraded.length) {
			items.push(String(degraded[degraded.length - 1] || ""));
		}
		return items.filter(Boolean);
	}

	function infoPoolSummary(
		/** @type {InfoPoolSnapshot} */ snapshot,
		/** @type {OperatorInfoSnapshot} */ operatorInfo,
	) {
		var backend = infoPoolCurrentBackendNote(operatorInfo);
		if (!backend) backend = String(snapshot.backendDegradedNote || "");
		if (backend) {
			return `DEGRADED MODE: ${backend}`;
		}
		var degraded = Array.isArray(snapshot.degradedNotes)
			? snapshot.degradedNotes
			: [];
		if (degraded.length) {
			return `DEGRADED MODE: ${String(degraded[degraded.length - 1] || "")}`;
		}
		var pmSummary = infoPoolPmSummary();
		if (pmSummary) return pmSummary;
		if (snapshot.latestHint?.text) {
			return String(snapshot.latestHint.text || "");
		}
		var statusLines = Array.isArray(snapshot.statusLines)
			? snapshot.statusLines
			: [];
		if (statusLines.length) {
			return String(statusLines[statusLines.length - 1] || "");
		}
		return "(idle)";
	}

	function infoPoolHintValue(
		/** @type {string} */ label,
		/** @type {string} */ value,
	) {
		return (
			'<div class="info-pool-hint-row">' +
			'<div class="info-pool-hint-label">' +
			escapeHtml(label) +
			"</div>" +
			'<div class="info-pool-hint-value">' +
			escapeHtml(value || "(empty)") +
			"</div>" +
			"</div>"
		);
	}

	function infoPoolSection(
		/** @type {string} */ title,
		/** @type {string} */ bodyHtml,
	) {
		return (
			'<section class="info-pool-section">' +
			'<h3 class="info-pool-section-title">' +
			escapeHtml(title) +
			"</h3>" +
			bodyHtml +
			"</section>"
		);
	}

	function infoPoolList(
		/** @type {string[]} */ lines,
		/** @type {string} */ emptyText,
	) {
		var items = Array.isArray(lines) ? lines : [];
		if (!items.length) {
			return `<div class="info-pool-empty">${escapeHtml(emptyText)}</div>`;
		}
		return (
			'<div class="info-pool-lines">' +
			items
				.map((/** @type {string} */ line) => {
					return `<div class="info-pool-line">${escapeHtml(line)}</div>`;
				})
				.join("") +
			"</div>"
		);
	}

	function infoPoolPre(
		/** @type {string} */ text,
		/** @type {string} */ emptyText,
	) {
		var value = String(text || "");
		if (!value) {
			return `<div class="info-pool-empty">${escapeHtml(emptyText)}</div>`;
		}
		return `<pre class="info-pool-pre">${escapeHtml(value)}</pre>`;
	}

	function infoPoolToolkitResolutionSection(
		/** @type {PatchhubToolkitResolutionRecord | null} */ resolution,
	) {
		if (!resolution || typeof resolution !== "object") {
			return infoPoolSection(
				"Toolkit resolution",
				'<div class="info-pool-empty">(empty)</div>',
			);
		}
		var html = [
			infoPoolHintValue("Remote sig", String(resolution.remote_sig || "")),
			infoPoolHintValue(
				"Cached before",
				String(resolution.cached_sig_before || ""),
			),
			infoPoolHintValue("Selected sig", String(resolution.selected_sig || "")),
			infoPoolHintValue("Cache hit", String(!!resolution.cache_hit)),
			infoPoolHintValue(
				"Download performed",
				String(!!resolution.download_performed),
			),
			infoPoolHintValue(
				"Integrity",
				String(resolution.integrity_check_result || ""),
			),
			infoPoolHintValue(
				"Resolution mode",
				String(resolution.resolution_mode || ""),
			),
			infoPoolHintValue("Checked at", String(resolution.checked_at || "")),
			infoPoolHintValue("Error", String(resolution.error || "")),
		].join("");
		return infoPoolSection(
			"Toolkit resolution",
			`<div class="info-pool-hints">${html}</div>`,
		);
	}

	function infoPoolPmSection(
		/** @type {PatchhubPmValidationPayload | null} */ snapshot,
	) {
		if (!snapshot || typeof snapshot !== "object") return "";
		var metaRows = [
			infoPoolHintValue(
				"Summary",
				infoPoolPmSummary() || String(snapshot.status || ""),
			),
			infoPoolHintValue("Status", String(snapshot.status || "")),
			infoPoolHintValue("Mode", String(snapshot.effective_mode || "")),
			infoPoolHintValue("Issue", String(snapshot.issue_id || "")),
			infoPoolHintValue("Message", String(snapshot.commit_message || "")),
			infoPoolHintValue("Patch", String(snapshot.patch_path || "")),
			infoPoolHintValue(
				"Authority",
				Array.isArray(snapshot.authority_sources)
					? snapshot.authority_sources.join(", ")
					: "",
			),
			infoPoolHintValue(
				"Supplemental",
				Array.isArray(snapshot.supplemental_files)
					? snapshot.supplemental_files.join(", ")
					: "",
			),
		];
		if (String(snapshot.failure_summary || "").trim()) {
			metaRows.push(
				infoPoolHintValue(
					"Failure summary",
					String(snapshot.failure_summary || ""),
				),
			);
		}
		var metaHtml = metaRows.join("");
		return infoPoolSection(
			"PM validation",
			'<div class="info-pool-hints">' +
				metaHtml +
				"</div>" +
				infoPoolToolkitResolutionSection(snapshot.toolkit_resolution || null) +
				infoPoolSection(
					"Raw validator output",
					infoPoolPre(String(snapshot.raw_output || ""), "(empty)"),
				),
		);
	}

	function renderInfoPoolModal() {
		var modal = infoPoolModalEl("uiStatusModal");
		var body = infoPoolModalEl("uiStatusModalBody");
		if (!modal || !body) return;
		var snapshot = infoPoolSnapshot();
		var operatorInfo = infoPoolOperatorInfo();
		var hints = snapshot.hints || {};
		var degraded = infoPoolDegradedItems(snapshot, operatorInfo);
		var hintHtml = [
			infoPoolHintValue("Upload", String(hints.upload || "")),
			infoPoolHintValue("Start run", String(hints.enqueue || "")),
			infoPoolHintValue("Files", String(hints.fs || "")),
			infoPoolHintValue("Advanced", String(hints.parse || "")),
		].join("");
		var pmHtml = infoPoolPmSection(infoPoolPmSnapshot());
		var recentStatusLines = infoPoolMergedStatusLines(snapshot, operatorInfo);
		body.innerHTML = [
			infoPoolSection("Degraded mode", infoPoolList(degraded, "(empty)")),
			infoPoolSection(
				"Current hints",
				`<div class="info-pool-hints">${hintHtml}</div>`,
			),
			pmHtml,
			infoPoolSection(
				"Recent status",
				infoPoolList(recentStatusLines, "(empty)"),
			),
		]
			.filter(Boolean)
			.join("");
		modal.classList.toggle("hidden", !infoPoolOpen);
		modal.setAttribute("aria-hidden", infoPoolOpen ? "false" : "true");
	}

	function infoPoolVisiblePmSummary(/** @type {string} */ summary) {
		var pmSummary = infoPoolPmSummary();
		if (!pmSummary || summary !== pmSummary) return "";
		return pmSummary;
	}

	function renderInfoPoolUi() {
		var strip = infoPoolModalEl("uiStatusBar");
		if (!strip) return;
		var summary = infoPoolSummary(infoPoolSnapshot(), infoPoolOperatorInfo());
		var visiblePmSummary = infoPoolVisiblePmSummary(summary);
		strip.textContent = summary;
		strip.classList.add("statusbar-clickable");
		strip.classList.toggle("statusbar-idle", summary === "(idle)");
		strip.classList.toggle(
			"statusbar-pm-pass",
			visiblePmSummary === "PM validation: PASS",
		);
		strip.classList.toggle(
			"statusbar-pm-fail",
			visiblePmSummary.indexOf("PM validation: FAIL") === 0,
		);
		if (infoPoolOpen) renderInfoPoolModal();
	}

	function setInfoPoolOpen(/** @type {boolean} */ nextOpen) {
		infoPoolOpen = !!nextOpen;
		renderInfoPoolModal();
	}

	function infoPoolSyncLegacyDegradedBanner() {
		var node = infoPoolModalEl("uiDegradedBanner");
		if (!node) return;
		var snapshot = infoPoolSnapshot();
		var degraded = infoPoolDegradedItems(snapshot, infoPoolOperatorInfo());
		var text = degraded.length ? String(degraded[0] || "") : "";
		node.textContent = text;
		node.classList.toggle("hidden", !text);
	}

	function infoPoolSetOperatorInfoSnapshot(/** @type {unknown} */ payload) {
		operatorInfoSnapshot = normalizeOperatorInfoSnapshot(payload);
		renderInfoPoolUi();
		infoPoolSyncLegacyDegradedBanner();
	}

	function onInfoPoolStripKeydown(/** @type {KeyboardEvent} */ event) {
		var key = event?.key ? String(event.key) : "";
		if (key !== "Enter" && key !== " ") return;
		if (event && typeof event.preventDefault === "function") {
			event.preventDefault();
		}
		setInfoPoolOpen(true);
	}

	function onInfoPoolDocumentKeydown(/** @type {KeyboardEvent} */ event) {
		var key = event?.key ? String(event.key) : "";
		if (key === "Escape") setInfoPoolOpen(false);
	}

	function onInfoPoolModalClick(/** @type {MouseEvent} */ event) {
		if (event && event.target === infoPoolModalEl("uiStatusModal")) {
			setInfoPoolOpen(false);
		}
	}

	function initInfoPoolUi() {
		var strip = infoPoolModalEl("uiStatusBar");
		var modal = infoPoolModalEl("uiStatusModal");
		var closeBtn = infoPoolModalEl("uiStatusModalCloseBtn");
		if (!strip || !modal || infoPoolBound) {
			renderInfoPoolUi();
			return;
		}
		infoPoolBound = true;
		strip.addEventListener("click", () => {
			setInfoPoolOpen(true);
		});
		strip.addEventListener("keydown", onInfoPoolStripKeydown);
		if (closeBtn) {
			closeBtn.addEventListener("click", () => {
				setInfoPoolOpen(false);
			});
		}
		modal.addEventListener("click", onInfoPoolModalClick);
		if (document && typeof document.addEventListener === "function") {
			document.addEventListener("keydown", onInfoPoolDocumentKeydown);
		}
		renderInfoPoolUi();
		infoPoolSyncLegacyDegradedBanner();
	}

	infoPoolWindow.PH_GET_OPERATOR_INFO_SNAPSHOT = () => {
		return normalizeOperatorInfoSnapshot(operatorInfoSnapshot);
	};
	infoPoolWindow.PH_SET_OPERATOR_INFO_SNAPSHOT =
		infoPoolSetOperatorInfoSnapshot;
	infoPoolWindow.PH_INFO_POOL_SYNC_LEGACY_DEGRADED_BANNER =
		infoPoolSyncLegacyDegradedBanner;

	if (PH && typeof PH.register === "function") {
		PH.register("app_part_info_pool", {
			initInfoPoolUi,
			renderInfoPoolUi,
		});
	}
})();
