from __future__ import annotations

import json
from typing import Any

from fastapi import FastAPI

from ..util.paths import debug_enabled, ui_overrides_path
from .debug_bundle import mount_debug_bundle


def _default_nav() -> list[dict[str, Any]]:
    nav: list[dict[str, Any]] = [
        {"title": "Dashboard", "route": "/", "page_id": "dashboard"},
        {"title": "Config", "route": "/config", "page_id": "config"},
        {"title": "Plugins", "route": "/plugins", "page_id": "plugins"},
        {"title": "Stage", "route": "/stage", "page_id": "stage"},
        {"title": "Import", "route": "/import", "page_id": "import"},
        {"title": "Wizards", "route": "/wizards", "page_id": "wizards"},
        {"title": "Jobs", "route": "/jobs", "page_id": "jobs"},
        {"title": "Logs", "route": "/logs", "page_id": "logs"},
        {"title": "UI Config", "route": "/ui-config", "page_id": "ui_config"},
    ]

    if debug_enabled():
        nav.append({"title": "Debug JS", "route": "/debug-js", "page_id": "debug_js"})

    return nav


def _default_pages() -> dict[str, dict[str, Any]]:
    pages: dict[str, dict[str, Any]] = {
        "dashboard": {
            "id": "dashboard",
            "title": "Dashboard",
            "layout": {
                "type": "grid",
                "children": [
                    {
                        "type": "card",
                        "title": "Status",
                        "content": {
                            "type": "stat_list",
                            "source": {"type": "api", "path": "/api/status"},
                            "fields": [
                                {"label": "pid", "key": "pid"},
                                {"label": "uptime_s", "key": "uptime_s"},
                            ],
                        },
                    },
                    {
                        "type": "card",
                        "title": "Run wizard here",
                        "content": {"type": "root_browser"},
                    },
                ],
            },
        },
        "config": {
            "id": "config",
            "title": "Config",
            "layout": {
                "type": "grid",
                "children": [{"type": "am_config"}],
            },
        },
        "plugins": {
            "id": "plugins",
            "title": "Plugins",
            "layout": {
                "type": "grid",
                "children": [{"type": "plugin_manager"}],
            },
        },
        "stage": {
            "id": "stage",
            "title": "Stage",
            "layout": {"type": "grid", "children": [{"type": "stage_manager"}]},
        },
        "import": {
            "id": "import",
            "title": "Import",
            "layout": {
                "type": "grid",
                "children": [
                    {
                        "type": "card",
                        "title": "Import wizard",
                        "content": {"type": "import_wizard"},
                    }
                ],
            },
        },
        "wizards": {
            "id": "wizards",
            "title": "Wizards",
            "layout": {"type": "grid", "children": [{"type": "wizard_manager"}]},
        },
        "jobs": {
            "id": "jobs",
            "title": "Jobs",
            "layout": {"type": "grid", "children": [{"type": "jobs_log_viewer"}]},
        },
        "logs": {
            "id": "logs",
            "title": "Logs",
            "layout": {
                "type": "grid",
                "children": [
                    {
                        "type": "card",
                        "title": "Debug bundle",
                        "content": {
                            "type": "button_row",
                            "buttons": [
                                {
                                    "label": "Download debug bundle",
                                    "action": {
                                        "type": "download",
                                        "href": "/api/debug/bundle",
                                    },
                                }
                            ],
                        },
                    },
                    {
                        "type": "card",
                        "title": "EventBus (diagnostics)",
                        "content": {
                            "type": "log_stream",
                            "stream_kind": "eventbus",
                            "tail_source": {
                                "type": "api",
                                "path": "/api/logs/tail?lines=200",
                            },
                            "source": {
                                "type": "sse",
                                "path": "/api/logs/stream?since_id=0",
                            },
                        },
                    },
                    {
                        "type": "card",
                        "title": "LogBus (core logs)",
                        "content": {
                            "type": "log_stream",
                            "stream_kind": "logbus",
                            "tail_source": {
                                "type": "api",
                                "path": "/api/logbus/tail?lines=200",
                            },
                            "source": {
                                "type": "sse",
                                "path": "/api/logbus/stream?since_id=0",
                            },
                        },
                    },
                ],
            },
        },
        "ui_config": {
            "id": "ui_config",
            "title": "UI Config",
            "layout": {
                "type": "grid",
                "children": [
                    {
                        "type": "card",
                        "title": "UI overrides",
                        "content": {
                            "type": "json_editor",
                            "source": {"type": "api", "path": "/api/ui/config"},
                            "save_action": {
                                "type": "api",
                                "method": "PUT",
                                "path": "/api/ui/config",
                            },
                            "field": "data",
                        },
                    }
                ],
            },
        },
    }

    if debug_enabled():
        # In debug mode, surface browser-side debug information in the same place
        # as all other logs (no DevTools required).
        logs_children = pages.get("logs", {}).get("layout", {}).get("children")
        if isinstance(logs_children, list):
            logs_children.insert(
                0,
                {
                    "type": "card",
                    "title": "Browser debug (client-side)",
                    "content": {"type": "ui_debug_feed"},
                },
            )

    if debug_enabled():
        pages["debug_js"] = {
            "id": "debug_js",
            "title": "Debug JS",
            "layout": {
                "type": "grid",
                "children": [
                    {
                        "type": "card",
                        "title": "JavaScript errors",
                        "content": {"type": "js_error_feed"},
                    }
                ],
            },
        }

    return pages


def _load_overrides() -> dict[str, Any]:
    p = ui_overrides_path()
    if not p.exists():
        return {"pages": {}, "nav": []}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {"pages": {}, "nav": []}


def mount_ui_schema(app: FastAPI) -> None:
    mount_debug_bundle(app)

    @app.get("/api/ui/schema")
    def ui_schema() -> dict[str, Any]:
        """Developer-friendly schema snapshot.

        This is not an OpenAPI replacement. It exposes the UI nav/pages schema and
        the primary configuration hooks used by the web interface.
        """

        return {
            "nav": _default_nav(),
            "pages": _default_pages(),
            "ui_overrides": {
                "path": str(ui_overrides_path()),
                "format": "json",
                "default": {"pages": {}, "nav": []},
            },
            "env": {
                "WEB_INTERFACE_DEBUG": (
                    "if truthy, API responses may include extra diagnostic fields"
                ),
                "WEB_INTERFACE_STAGE_DIR": "override the stage upload directory",
                "WEB_INTERFACE_LOG_PATH": "optional log file path for server log tail/stream",
            },
        }

    @app.get("/api/ui/nav")
    def ui_nav() -> dict[str, Any]:
        ov = _load_overrides()
        nav = ov.get("nav")
        if isinstance(nav, list) and nav:
            return {"items": nav}
        return {"items": _default_nav()}

    @app.get("/api/ui/pages")
    def ui_pages() -> dict[str, Any]:
        pages = _default_pages()
        ov = _load_overrides()
        pov = ov.get("pages")
        if isinstance(pov, dict):
            for k, v in pov.items():
                if isinstance(v, dict):
                    pages[k] = v
        return {"items": [{"id": k, "title": v.get("title", k)} for k, v in pages.items()]}

    @app.get("/api/ui/page/{page_id}")
    def ui_page(page_id: str) -> dict[str, Any]:
        pages = _default_pages()
        ov = _load_overrides()
        pov = ov.get("pages")
        if isinstance(pov, dict) and page_id in pov and isinstance(pov[page_id], dict):
            pages[page_id] = pov[page_id]
        return pages.get(page_id, pages["dashboard"])

    @app.get("/api/ui/config")
    def ui_config_get() -> dict[str, Any]:
        p = ui_overrides_path()
        out: dict[str, Any] = {"data": _load_overrides(), "info": ""}
        if p.exists():
            out["info"] = "user"
        if debug_enabled():
            out["path"] = str(p)
        return out

    @app.put("/api/ui/config")
    def ui_config_put(body: dict[str, Any]) -> dict[str, Any]:
        p = ui_overrides_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        data = body.get("data")
        if not isinstance(data, dict):
            data = body if isinstance(body, dict) else {"pages": {}, "nav": []}
        p.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        out: dict[str, Any] = {"ok": True, "info": "user"}
        if debug_enabled():
            out["path"] = str(p)
        return out
