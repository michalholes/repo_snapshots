"""TUI plugin."""
