/// <reference path="../../../../../types/am2-import-ui-globals.d.ts" />
(() => {
	/** @type {Window} */
	var root = window;

	/** @param {string} id */
	function $(id) {
		return document.getElementById(id);
	}

	/** @type {AM2FlowJSONModalDomUi} */
	var ui = {
		modal: $("flowJsonModal"),
		title: $("flowJsonModalTitle"),
		subtitle: $("flowJsonModalSubtitle"),
		editor: /** @type {HTMLTextAreaElement | null} */ (
			$("flowJsonModalEditor")
		),
		status: $("flowJsonModalStatus"),
		error: $("flowJsonModalError"),
		reread: $("flowJsonReread"),
		abort: $("flowJsonAbort"),
		save: $("flowJsonSave"),
		openFromFile: $("flowJsonOpenFromFile"),
		saveToFile: $("flowJsonSaveToFile"),
		close: $("flowJsonModalClose"),
		cancel: $("flowJsonCancel"),
		copySelected: $("flowJsonCopySelected"),
		copyAll: $("flowJsonCopyAll"),
		apply: $("flowJsonApply"),
	};

	if (!ui.modal || !ui.editor) {
		return;
	}

	/** @type {HTMLElement} */
	var modal = ui.modal;
	/** @type {HTMLTextAreaElement} */
	var editor = ui.editor;

	function isOpen() {
		return !modal.classList.contains("is-hidden");
	}

	/** @param {boolean} open */
	function setOpen(open) {
		modal.classList.toggle("is-hidden", open !== true);
		modal.setAttribute("aria-hidden", open === true ? "false" : "true");
		if (open === true && editor.focus) {
			editor.focus();
		}
	}

	/** @param {string} title
	 * @param {string} subtitle
	 */
	function setArtifactMeta(title, subtitle) {
		if (ui.title) ui.title.textContent = String(title || "");
		if (ui.subtitle) ui.subtitle.textContent = String(subtitle || "");
	}

	/** @param {string} text */
	function setValue(text) {
		editor.value = String(text || "");
	}

	function getValue() {
		return String(editor.value || "");
	}

	/** @param {string} msg
	 * @param {string} kind
	 */
	function setStatus(msg, kind) {
		if (!ui.status) return;
		ui.status.textContent = String(msg || "");
		ui.status.classList.toggle("is-ok", kind === "ok");
		ui.status.classList.toggle("is-bad", kind === "bad");
	}

	/** @param {string} msg */
	function setError(msg) {
		if (!ui.error) return;
		ui.error.textContent = String(msg || "");
	}

	function clearFeedback() {
		setStatus("", "");
		setError("");
	}

	function getSelectedText() {
		var value = getValue();
		var start = Number(editor.selectionStart || 0);
		var end = Number(editor.selectionEnd || 0);
		if (end <= start) {
			return "";
		}
		return value.slice(start, end);
	}

	root.AM2FlowJSONModalDOM = {
		ui: ui,
		clearFeedback: clearFeedback,
		getSelectedText: getSelectedText,
		getValue: getValue,
		isOpen: isOpen,
		setArtifactMeta: setArtifactMeta,
		setError: setError,
		setOpen: setOpen,
		setStatus: setStatus,
		setValue: setValue,
	};
})();
