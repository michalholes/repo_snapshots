"""UI-facing FastAPI router for the import plugin.

The host is responsible for mounting this router.

ASCII-only.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def build_router(*, engine: Any):
    try:
        from fastapi import APIRouter
        from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
    except Exception as e:  # pragma: no cover
        raise RuntimeError("fastapi is required for import UI router") from e

    from .engine import _exception_envelope
    from .engine_diagnostics_required import start_process_runtime
    from .engine_session_start_boundary import ALLOWED_USER_START_INTENTS, start_user_facing_session
    from .field_schema_validation import FieldSchemaValidationError
    from .session_effective_model import EffectiveModelJsonError
    from .ui_editor_api import bind_editor_routes

    start_process_runtime(engine=engine)
    router = APIRouter(prefix="/import/ui")

    base_dir = Path(__file__).resolve().parent
    ui_web_dir = base_dir / "ui" / "web"
    assets_dir = ui_web_dir / "assets"

    @router.get("/assets/{asset_path:path}")
    def ui_asset(asset_path: str):
        if not assets_dir.is_dir():
            return JSONResponse(status_code=404, content={"error": {"code": "NOT_FOUND"}})

        rel = Path(asset_path)
        if rel.is_absolute() or ".." in rel.parts:
            return JSONResponse(status_code=404, content={"error": {"code": "NOT_FOUND"}})

        root = assets_dir.resolve()
        candidate = (assets_dir / rel).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            return JSONResponse(status_code=404, content={"error": {"code": "NOT_FOUND"}})

        if not candidate.is_file():
            return JSONResponse(status_code=404, content={"error": {"code": "NOT_FOUND"}})

        return FileResponse(str(candidate))

    session_start_allowed_keys = {"intent", "mode", "path", "root"}
    session_start_required_keys = {"mode", "path", "root"}
    session_start_allowed_modes = {"inplace", "stage"}

    def _validate_session_start_body(body: Any) -> tuple[str, str, str, str | None]:
        if not isinstance(body, dict):
            raise FieldSchemaValidationError(
                message="request body must be an object",
                path="$",
                reason="invalid_type",
                meta={},
            )

        keys = {k for k in body if isinstance(k, str)}
        unknown = sorted(keys - session_start_allowed_keys)
        if unknown:
            key = unknown[0]
            raise FieldSchemaValidationError(
                message="unknown field in request body",
                path=f"$.{key}",
                reason="unknown_field",
                meta={
                    "allowed": sorted(session_start_allowed_keys),
                    "unknown": unknown,
                },
            )

        missing = sorted(session_start_required_keys - keys)
        if missing:
            key = missing[0]
            raise FieldSchemaValidationError(
                message="missing required field in request body",
                path=f"$.{key}",
                reason="missing_required",
                meta={"required": sorted(session_start_required_keys)},
            )

        root = body.get("root")
        if not isinstance(root, str) or not root:
            raise FieldSchemaValidationError(
                message="root must be a non-empty string",
                path="$.root",
                reason="missing_or_invalid",
                meta={},
            )

        path = body.get("path")
        if not isinstance(path, str) or not path:
            raise FieldSchemaValidationError(
                message="path must be a non-empty string",
                path="$.path",
                reason="missing_or_invalid",
                meta={},
            )

        mode = body.get("mode")
        if not isinstance(mode, str) or not mode:
            raise FieldSchemaValidationError(
                message="mode must be a non-empty string",
                path="$.mode",
                reason="missing_or_invalid",
                meta={"allowed": sorted(session_start_allowed_modes)},
            )
        if mode not in session_start_allowed_modes:
            raise FieldSchemaValidationError(
                message="mode must be one of the allowed values",
                path="$.mode",
                reason="invalid_enum",
                meta={
                    "allowed": sorted(session_start_allowed_modes),
                    "value": mode,
                },
            )

        intent = body.get("intent")
        if intent is not None:
            if not isinstance(intent, str) or not intent:
                raise FieldSchemaValidationError(
                    message="intent must be a non-empty string when provided",
                    path="$.intent",
                    reason="missing_or_invalid",
                    meta={"allowed": sorted(ALLOWED_USER_START_INTENTS)},
                )
            if intent not in ALLOWED_USER_START_INTENTS:
                raise FieldSchemaValidationError(
                    message="intent must be one of the allowed values",
                    path="$.intent",
                    reason="invalid_enum",
                    meta={"allowed": sorted(ALLOWED_USER_START_INTENTS), "value": intent},
                )

        return root, path, mode, intent

    def _status_code_for_envelope(envelope: dict[str, Any]) -> int:
        err = envelope.get("error")
        if not isinstance(err, dict):
            return 500
        code = err.get("code")
        if code == "NOT_FOUND":
            return 404
        if code == "SESSION_START_CONFLICT":
            return 409
        if code in {"VALIDATION_ERROR", "INVARIANT_VIOLATION", "CONFLICTS_UNRESOLVED"}:
            return 400
        if code == "INTERNAL_ERROR":
            return 500
        return 500

    def _as_response(result: Any):
        if isinstance(result, dict) and "error" in result:
            return JSONResponse(
                status_code=_status_code_for_envelope(result),
                content=result,
            )
        return result

    def _effective_model_reason(message: str) -> str:
        if "missing" in message:
            return "missing_file"
        if "invalid JSON" in message:
            return "invalid_json"
        if "must be an object" in message:
            return "invalid_type"
        return "invalid"

    def _call(handler):
        try:
            return _as_response(handler())
        except EffectiveModelJsonError as e:
            env = {
                "error": {
                    "code": "VALIDATION_ERROR",
                    "message": str(e),
                    "details": [
                        {
                            "path": "$.effective_model",
                            "reason": _effective_model_reason(str(e)),
                            "meta": {"path": str(e.rel_path)},
                        }
                    ],
                }
            }
            return JSONResponse(status_code=400, content=env)
        except Exception as e:
            env = _exception_envelope(e)
            return JSONResponse(status_code=_status_code_for_envelope(env), content=env)

    @router.get("/")
    def ui_index():
        idx = ui_web_dir / "index.html"
        if not idx.is_file():
            env = {
                "error": {
                    "code": "NOT_FOUND",
                    "message": "import UI index.html is missing",
                    "details": [
                        {
                            "path": "$.ui.web.index",
                            "reason": "not_found",
                            "meta": {"expected": str(idx)},
                        }
                    ],
                }
            }
            return JSONResponse(status_code=404, content=env)
        return HTMLResponse(idx.read_text(encoding="utf-8"))

    @router.get("/flow")
    def get_flow():
        return _call(lambda: engine.get_flow_model())

    bind_editor_routes(router=router, engine=engine, call=_call)

    @router.post("/session/start")
    def session_start(body: dict[str, Any]):
        def _impl():
            root, path, mode, intent = _validate_session_start_body(body)
            return start_user_facing_session(
                engine=engine,
                root=root,
                relative_path=path,
                mode=mode,
                intent=intent,
            )

        return _call(_impl)

    @router.get("/session/{session_id}/state")
    def session_state(session_id: str):
        return _call(lambda: engine.get_state(session_id))

    @router.get("/session/{session_id}/step/{step_id}")
    def step_definition(session_id: str, step_id: str):
        return _call(lambda: engine.get_step_definition(session_id, step_id))

    @router.post("/session/{session_id}/step/{step_id}")
    def step_submit(session_id: str, step_id: str, body: dict[str, Any]):
        return _call(lambda: engine.submit_step(session_id, step_id, body))

    @router.post("/session/{session_id}/preview/{step_id}")
    def step_preview(session_id: str, step_id: str, body: dict[str, Any]):
        return _call(lambda: engine.preview_action(session_id, step_id, body))

    @router.post("/session/{session_id}/start_processing")
    def start_processing(session_id: str, body: dict[str, Any]):
        return _call(lambda: engine.start_processing(session_id, body))

    return router
