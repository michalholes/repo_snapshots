"""Pipeline executor - YAML to DAG to async execution.

Reads declarative YAML pipeline definitions and executes them
as a DAG (Directed Acyclic Graph) with async and parallel support.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, TypeGuard, cast

from audiomason.core.context import ProcessingContext
from audiomason.core.diagnostics import build_envelope
from audiomason.core.errors import PipelineError
from audiomason.core.events import get_event_bus
from audiomason.core.logging import get_logger
from audiomason.core.serde import yaml_safe_load_stream


def _is_str_any_dict(value: object) -> TypeGuard[dict[str, object]]:
    return isinstance(value, dict)


def _require_str(value: object, *, field: str) -> str:
    if not isinstance(value, str):
        raise PipelineError(f"Invalid pipeline step field '{field}': expected string")
    return value


class _PluginLoaderProtocol(Protocol):
    def get_plugin(self, name: str) -> object: ...


class _ProcessorPlugin(Protocol):
    async def process(self, context: ProcessingContext) -> ProcessingContext: ...


class _EnricherPlugin(Protocol):
    async def enrich(self, context: ProcessingContext) -> ProcessingContext: ...


@dataclass
class PipelineStep:
    """Single pipeline step definition."""

    id: str
    plugin: str
    interface: str
    after: list[str]  # Step dependencies
    parallel: bool = False


@dataclass
class Pipeline:
    """Pipeline definition."""

    name: str
    description: str
    steps: list[PipelineStep]


class PipelineExecutor:
    """Execute pipeline as DAG.

    Example YAML:
        pipeline:
          name: standard
          steps:
            - id: import
              plugin: audio_importer
              interface: IProcessor

            - id: convert
              plugin: audio_converter
              interface: IProcessor
              after: [import]

            - id: fetch_metadata
              plugin: metadata_fetcher
              interface: IProvider
              after: [import]
              parallel: true
    """

    def __init__(
        self,
        plugin_loader: _PluginLoaderProtocol,
        log_fn: Callable[[str], None] | None = None,
    ) -> None:
        """Initialize pipeline executor.

        Args:
            plugin_loader: Plugin loader instance
            log_fn: Optional logger callback for step events
        """
        self.plugin_loader = plugin_loader
        self._log_fn = log_fn
        self._logger = get_logger(__name__)

    def _log(self, msg: str) -> None:
        if self._log_fn is not None:
            self._log_fn(msg)

    def _emit_diag(self, event: str, *, operation: str, data: dict[str, object]) -> None:
        """Emit a structured diagnostic event via the authoritative EventBus."""
        with contextlib.suppress(Exception):
            envelope = build_envelope(
                event=event,
                component="pipeline",
                operation=operation,
                data=data,
            )
            get_event_bus().publish(event, envelope)

    async def execute(self, pipeline: Pipeline, context: ProcessingContext) -> ProcessingContext:
        """Execute pipeline.

        Args:
            pipeline: Pipeline definition
            context: Initial context

        Returns:
            Final context after all steps

        Raises:
            PipelineError: If execution fails
        """
        # Build DAG
        dag = self._build_dag(pipeline.steps)

        # Execute topologically
        for level in dag:
            context = await self._execute_level(level, context)

        return context

    async def execute_from_yaml(
        self, yaml_path: Path, context: ProcessingContext
    ) -> ProcessingContext:
        """Load and execute pipeline from YAML file.

        Args:
            yaml_path: Path to pipeline YAML
            context: Initial context

        Returns:
            Final context

        Raises:
            PipelineError: If loading or execution fails
        """
        start_time = time.monotonic()
        self._emit_diag(
            "diag.pipeline.start",
            operation="execute_from_yaml",
            data={
                "pipeline_path": str(yaml_path),
                "source": str(context.source),
                "status": "running",
            },
        )
        pipeline = self.load_pipeline(yaml_path)
        try:
            result = await self.execute(pipeline, context)
        except Exception as e:
            self._emit_diag(
                "diag.pipeline.end",
                operation="execute_from_yaml",
                data={
                    "pipeline_path": str(yaml_path),
                    "source": str(context.source),
                    "status": "failed",
                    "duration_ms": int((time.monotonic() - start_time) * 1000),
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                },
            )
            raise
        else:
            self._emit_diag(
                "diag.pipeline.end",
                operation="execute_from_yaml",
                data={
                    "pipeline_path": str(yaml_path),
                    "source": str(context.source),
                    "status": "succeeded",
                    "duration_ms": int((time.monotonic() - start_time) * 1000),
                },
            )
            return result

    def load_pipeline(self, yaml_path: Path) -> Pipeline:
        """Load pipeline from YAML.

        Args:
            yaml_path: Path to YAML file

        Returns:
            Pipeline definition

        Raises:
            PipelineError: If loading fails
        """
        if not yaml_path.exists():
            raise PipelineError(f"Pipeline file not found: {yaml_path}")

        try:
            with open(yaml_path) as f:
                raw_data = yaml_safe_load_stream(f)

            if not _is_str_any_dict(raw_data):
                raise PipelineError("Invalid pipeline YAML: root must be a mapping")
            data = raw_data

            if "pipeline" not in data:
                raise PipelineError("Invalid pipeline YAML: missing 'pipeline' key")

            pipeline_data_raw = data["pipeline"]
            if not _is_str_any_dict(pipeline_data_raw):
                raise PipelineError("Invalid pipeline YAML: 'pipeline' must be a mapping")
            pipeline_data = pipeline_data_raw

            raw_steps = pipeline_data.get("steps", [])
            if not isinstance(raw_steps, list):
                raise PipelineError("Invalid pipeline YAML: 'steps' must be a list")
            raw_steps_list = cast(list[object], raw_steps)

            steps: list[PipelineStep] = []
            for step_data_raw in raw_steps_list:
                if not _is_str_any_dict(step_data_raw):
                    raise PipelineError("Invalid pipeline YAML: each step must be a mapping")
                step_data = step_data_raw

                after_raw = step_data.get("after", [])
                if not isinstance(after_raw, list):
                    raise PipelineError("Invalid pipeline YAML: 'after' must be list[str]")
                after_list = cast(list[object], after_raw)
                if not all(isinstance(item, str) for item in after_list):
                    raise PipelineError("Invalid pipeline YAML: 'after' must be list[str]")

                parallel_raw = step_data.get("parallel", False)
                if not isinstance(parallel_raw, bool):
                    raise PipelineError("Invalid pipeline YAML: 'parallel' must be bool")

                step = PipelineStep(
                    id=_require_str(step_data.get("id"), field="id"),
                    plugin=_require_str(step_data.get("plugin"), field="plugin"),
                    interface=_require_str(step_data.get("interface"), field="interface"),
                    after=[str(item) for item in after_list],
                    parallel=parallel_raw,
                )
                steps.append(step)

            name = pipeline_data.get("name", "unnamed")
            if not isinstance(name, str):
                raise PipelineError("Invalid pipeline YAML: 'name' must be string")

            description = pipeline_data.get("description", "")
            if not isinstance(description, str):
                raise PipelineError("Invalid pipeline YAML: 'description' must be string")

            return Pipeline(
                name=name,
                description=description,
                steps=steps,
            )

        except Exception as e:
            raise PipelineError(f"Failed to load pipeline: {e}") from e

    def _build_dag(self, steps: list[PipelineStep]) -> list[list[PipelineStep]]:
        """Build DAG from steps using topological sort.

        Returns:
            List of levels, where each level contains steps that can run in parallel

        Raises:
            PipelineError: If DAG has cycles
        """
        # Build dependency graph
        step_map = {step.id: step for step in steps}
        in_degree = {step.id: 0 for step in steps}

        for step in steps:
            for dep in step.after:
                if dep not in step_map:
                    raise PipelineError(f"Step '{step.id}' depends on unknown step '{dep}'")
                in_degree[step.id] += 1

        # Topological sort (Kahn's algorithm)
        levels: list[list[PipelineStep]] = []
        remaining = set(step_map.keys())

        while remaining:
            # Find steps with no dependencies
            current_level = [step_map[step_id] for step_id in remaining if in_degree[step_id] == 0]

            if not current_level:
                # Cycle detected
                raise PipelineError(f"Pipeline has circular dependencies: {remaining}")

            levels.append(current_level)

            # Remove from remaining
            for step in current_level:
                remaining.remove(step.id)

                # Decrease in-degree for dependent steps
                for other_step in steps:
                    if step.id in other_step.after:
                        in_degree[other_step.id] -= 1

        return levels

    async def _execute_level(
        self, steps: list[PipelineStep], context: ProcessingContext
    ) -> ProcessingContext:
        """Execute all steps in a level (potentially in parallel).

        Args:
            steps: Steps to execute
            context: Current context

        Returns:
            Updated context

        Raises:
            PipelineError: If any step fails
        """
        if not steps:
            return context

        # Separate parallel and sequential steps
        parallel_steps = [s for s in steps if s.parallel]
        sequential_steps = [s for s in steps if not s.parallel]

        # Execute sequential steps first
        for step in sequential_steps:
            context = await self._execute_step(step, context)

        # Execute parallel steps
        if parallel_steps:
            tasks = [self._execute_step(step, context) for step in parallel_steps]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Check for errors
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    raise PipelineError(
                        f"Step '{parallel_steps[i].id}' failed: {result}"
                    ) from result

            # Use last result (all should have updated same context)
            if results:
                context = results[-1]  # type: ignore

        return context

    async def _execute_step(
        self, step: PipelineStep, context: ProcessingContext
    ) -> ProcessingContext:
        """Execute a single step.

        Args:
            step: Step to execute
            context: Current context

        Returns:
            Updated context

        Raises:
            PipelineError: If step fails
        """
        self._logger.verbose(f"step start: {step.id}")

        start_time = time.monotonic()

        self._emit_diag(
            "diag.pipeline.step.start",
            operation="step",
            data={
                "step_id": step.id,
                "plugin": step.plugin,
                "interface": step.interface,
                "source": str(context.source),
            },
        )

        try:
            # Mark step as current
            context.current_step = step.id

            # Get plugin
            plugin = self.plugin_loader.get_plugin(step.plugin)

            # Execute based on interface
            if step.interface == "IProcessor":
                if not hasattr(plugin, "process"):
                    raise PipelineError(f"Plugin '{step.plugin}' missing process()")
                processor = cast(_ProcessorPlugin, plugin)
                context = await processor.process(context)
            elif step.interface == "IProvider":
                # Providers return data, not context
                # For now, just call fetch and ignore result
                # Real implementation would store result in context
                pass
            elif step.interface == "IEnricher":
                if not hasattr(plugin, "enrich"):
                    raise PipelineError(f"Plugin '{step.plugin}' missing enrich()")
                enricher = cast(_EnricherPlugin, plugin)
                context = await enricher.enrich(context)
            else:
                raise PipelineError(f"Unknown interface: {step.interface}")

            # Mark step complete
            context.mark_step_complete(step.id)

            self._logger.verbose(f"step done: {step.id}")

            self._emit_diag(
                "diag.pipeline.step.end",
                operation="step",
                data={
                    "step_id": step.id,
                    "status": "succeeded",
                    "duration_ms": int((time.monotonic() - start_time) * 1000),
                    "plugin": step.plugin,
                    "interface": step.interface,
                    "source": str(context.source),
                },
            )

            return context

        except Exception as e:
            self._emit_diag(
                "diag.boundary.fail",
                operation="plugin_call",
                data={
                    "step_id": step.id,
                    "plugin": step.plugin,
                    "interface": step.interface,
                    "source": str(context.source),
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                },
            )
            self._logger.error(f"step failed: {step.id}: {e}")
            self._emit_diag(
                "diag.pipeline.step.end",
                operation="step",
                data={
                    "step_id": step.id,
                    "status": "failed",
                    "duration_ms": int((time.monotonic() - start_time) * 1000),
                    "plugin": step.plugin,
                    "interface": step.interface,
                    "source": str(context.source),
                    "error_type": type(e).__name__,
                    "error": str(e),
                },
            )
            raise PipelineError(f"Step '{step.id}' failed: {e}") from e
