"""Data models for the import wizard engine.

Catalog/flow payloads handled here are compatibility projections derived from the
active import authority. Only minimal schema validation is implemented here.

ASCII-only.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import TypeGuard, cast

from .errors import ModelLoadError, ModelValidationError

# Required vs optional steps are defined by the project specification.
#
# BASE_REQUIRED_STEP_IDS are PHASE 1 steps that must always exist.
# OPTIONAL_STEP_IDS may exist in the catalog/flow but must not be required.
BASE_REQUIRED_STEP_IDS = {
    "select_authors",
    "select_books",
    "plan_preview_batch",
    "effective_author_title",
    "conflict_policy",
    "final_summary_confirm",
    "resolve_conflicts_batch",
    "processing",
}

OPTIONAL_STEP_IDS = {
    "filename_policy",
    "covers_policy",
    "id3_policy",
    "audio_processing",
    "publish_policy",
    "delete_source_policy",
    "skip_processed_books",
    "parallelism",
}


_ALLOWED_FIELD_TYPES = {
    "text",
    "toggle",
    "confirm",
    "select",
    "number",
    "multi_select_indexed",
    "table_edit",
}


def _is_object_list(value: object) -> TypeGuard[list[object]]:
    return isinstance(value, list)


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    if not isinstance(value, dict):
        return False
    return all(isinstance(key, str) for key in cast(dict[object, object], value))


@dataclass(frozen=True)
class CatalogModel:
    version: int
    steps: list[dict[str, object]]

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> CatalogModel:
        if not _is_str_object_dict(data):
            raise ModelLoadError("Catalog must be an object")
        version = data.get("version")
        steps = data.get("steps")
        if not isinstance(version, int):
            raise ModelLoadError("Catalog missing valid 'version' (int)")
        if not _is_object_list(steps):
            raise ModelLoadError("Catalog missing valid 'steps' list")
        normalized_steps: list[dict[str, object]] = []
        for i, step in enumerate(steps):
            if not _is_str_object_dict(step):
                raise ModelLoadError(f"Catalog step[{i}] must be an object")
            _validate_step_schema(step, i)
            normalized_steps.append(step)
        return cls(version=version, steps=normalized_steps)

    def step_ids(self) -> set[str]:
        ids: set[str] = set()
        for step in self.steps:
            sid = step.get("step_id")
            if isinstance(sid, str) and sid:
                ids.add(sid)
        return ids


@dataclass(frozen=True)
class FlowNode:
    step_id: str
    next_step_id: str | None
    prev_step_id: str | None


@dataclass(frozen=True)
class FlowModel:
    version: int
    entry_step_id: str
    nodes: list[FlowNode]

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> FlowModel:
        if not _is_str_object_dict(data):
            raise ModelLoadError("Flow must be an object")
        version = data.get("version")
        entry = data.get("entry_step_id")
        nodes_raw = data.get("nodes")
        if not isinstance(version, int):
            raise ModelLoadError("Flow missing valid 'version' (int)")
        if not isinstance(entry, str) or not entry:
            raise ModelLoadError("Flow missing valid 'entry_step_id'")
        if not _is_object_list(nodes_raw):
            raise ModelLoadError("Flow missing valid 'nodes' list")

        nodes: list[FlowNode] = []

        # Accept either list[str] (implicit linear) or list[dict].
        if all(isinstance(n, str) for n in nodes_raw):
            step_ids = [str(x) for x in nodes_raw]
            for i, step_id in enumerate(step_ids):
                next_id = step_ids[i + 1] if i + 1 < len(step_ids) else None
                prev_id = step_ids[i - 1] if i - 1 >= 0 else None
                nodes.append(FlowNode(step_id=step_id, next_step_id=next_id, prev_step_id=prev_id))
        else:
            for i, n in enumerate(nodes_raw):
                if not _is_str_object_dict(n):
                    raise ModelLoadError(f"Flow node[{i}] must be an object")
                sid_any = n.get("step_id")
                if not isinstance(sid_any, str) or not sid_any:
                    raise ModelLoadError(f"Flow node[{i}] missing valid 'step_id'")
                sid: str = sid_any
                next_any = n.get("next_step_id")
                prev_any = n.get("prev_step_id")
                if next_any is not None and not isinstance(next_any, str):
                    raise ModelLoadError(f"Flow node[{i}] invalid 'next_step_id'")
                if prev_any is not None and not isinstance(prev_any, str):
                    raise ModelLoadError(f"Flow node[{i}] invalid 'prev_step_id'")
                next_id = next_any if isinstance(next_any, str) else None
                prev_id = prev_any if isinstance(prev_any, str) else None
                nodes.append(
                    FlowNode(
                        step_id=sid,
                        next_step_id=next_id,
                        prev_step_id=prev_id,
                    )
                )

        return cls(version=version, entry_step_id=entry, nodes=nodes)

    def node_map(self) -> dict[str, FlowNode]:
        return {n.step_id: n for n in self.nodes}


def validate_models(catalog: CatalogModel, flow: FlowModel) -> None:
    step_ids = catalog.step_ids()

    missing = sorted(BASE_REQUIRED_STEP_IDS - step_ids)
    if missing:
        raise ModelValidationError(f"Catalog missing required step_ids: {missing}")

    node_ids = {n.step_id for n in flow.nodes}
    if flow.entry_step_id not in node_ids:
        raise ModelValidationError("Flow entry_step_id must exist in nodes")

    # Engine Guard (10.6): steps must not be inserted before select_authors.
    if flow.entry_step_id != "select_authors":
        raise ModelValidationError("Flow entry_step_id must be select_authors")

    for required in sorted(BASE_REQUIRED_STEP_IDS):
        if required not in node_ids:
            raise ModelValidationError(f"Flow missing required step node: {required}")

    # Ensure next/prev references are within node_ids when present.
    for n in flow.nodes:
        if n.next_step_id is not None and n.next_step_id not in node_ids:
            raise ModelValidationError(
                f"Flow node '{n.step_id}' references missing next_step_id '{n.next_step_id}'"
            )
        if n.prev_step_id is not None and n.prev_step_id not in node_ids:
            raise ModelValidationError(
                f"Flow node '{n.step_id}' references missing prev_step_id '{n.prev_step_id}'"
            )

    reachable = _reachable_step_ids(flow)
    if "final_summary_confirm" not in reachable:
        raise ModelValidationError("Flow must reach final_summary_confirm from entry_step_id")
    if "processing" not in reachable:
        raise ModelValidationError("Flow must reach processing from entry_step_id")


def _require_ascii_str(value: object, *, field: str, step_index: int) -> str:
    if not isinstance(value, str) or not value:
        raise ModelValidationError(
            f"Catalog step[{step_index}] missing valid '{field}' (non-empty string)"
        )
    try:
        value.encode("ascii")
    except UnicodeEncodeError as e:
        raise ModelValidationError(
            f"Catalog step[{step_index}] field '{field}' must be ASCII-only"
        ) from e
    return value


def _require_bool(value: object, *, field: str, step_index: int) -> bool:
    if not isinstance(value, bool):
        raise ModelValidationError(f"Catalog step[{step_index}] missing valid '{field}' (bool)")
    return value


def _validate_step_schema(step: dict[str, object], step_index: int) -> None:
    _ = _require_ascii_str(step.get("step_id"), field="step_id", step_index=step_index)
    _ = _require_ascii_str(step.get("title"), field="title", step_index=step_index)
    _ = _require_bool(step.get("computed_only"), field="computed_only", step_index=step_index)

    fields_any = step.get("fields")
    if not _is_object_list(fields_any):
        raise ModelValidationError(f"Catalog step[{step_index}] missing valid 'fields' (list)")

    for i, f in enumerate(fields_any):
        if not _is_str_object_dict(f):
            raise ModelValidationError(f"Catalog step[{step_index}] field[{i}] must be an object")
        name = f.get("name")
        ftype = f.get("type")
        required = f.get("required")
        _ = _require_ascii_str(name, field="name", step_index=step_index)
        _ = _require_ascii_str(ftype, field="type", step_index=step_index)
        _ = _require_bool(required, field="required", step_index=step_index)
        if str(ftype) not in _ALLOWED_FIELD_TYPES:
            raise ModelValidationError(
                f"Catalog step[{step_index}] field[{i}] has unsupported type '{ftype}'"
            )
        constraints_any = f.get("constraints", {})
        if not _is_str_object_dict(constraints_any):
            raise ModelValidationError(
                f"Catalog step[{step_index}] field[{i}] constraints must be an object"
            )

        # Optional schema extensions for certain baseline types.
        if str(ftype) == "multi_select_indexed":
            items_any = f.get("items")
            if items_any is not None and not _is_object_list(items_any):
                raise ModelValidationError(
                    f"Catalog step[{step_index}] field[{i}] items must be a list when present"
                )


def _reachable_step_ids(flow: FlowModel) -> set[str]:
    node_map = flow.node_map()
    start = flow.entry_step_id
    visited: set[str] = set()
    queue: deque[str] = deque([start])
    while queue:
        cur = queue.popleft()
        if cur in visited:
            continue
        visited.add(cur)
        node = node_map.get(cur)
        if node is None:
            continue
        if node.next_step_id is not None and node.next_step_id not in visited:
            queue.append(node.next_step_id)
    return visited
