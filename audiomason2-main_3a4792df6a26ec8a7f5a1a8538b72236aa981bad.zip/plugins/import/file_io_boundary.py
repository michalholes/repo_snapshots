"""Import-owned file/materialization boundary helpers.

Resolver-friendly refs remain the only authority. Absolute paths are
materialized here only for execution-time needs.

ASCII-only.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Protocol, TypeGuard, cast

from plugins.file_io.import_runtime import normalize_relative_path
from plugins.file_io.service import FileService, RootName


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    if not isinstance(value, dict):
        return False
    return all(isinstance(key, str) for key in cast(dict[object, object], value))


def _as_str_object_dict(value: object) -> dict[str, object]:
    return dict(value) if _is_str_object_dict(value) else {}


class _ResolveLocalPathCallable(Protocol):
    def __call__(
        self,
        root_name: RootName,
        rel: str,
        *,
        silent_polling_read: bool = False,
    ) -> Path: ...


def _normalize_root_name(root: str | RootName) -> RootName:
    return root if isinstance(root, RootName) else RootName(str(root))


def _source_ref_from_state(state: dict[str, object]) -> tuple[RootName | None, str]:
    source = _as_str_object_dict(state.get("source"))
    root_text = str(source.get("root") or "").strip()
    rel = normalize_relative_path(str(source.get("relative_path") or ""))
    if not root_text:
        return None, rel
    try:
        return RootName(root_text), rel
    except ValueError:
        return None, rel


def _join_source_relative_path(*, source_prefix: str, source_relative_path: str) -> str:
    base = normalize_relative_path(source_prefix)
    rel = normalize_relative_path(source_relative_path)
    if not base:
        return rel
    if not rel:
        return base
    return f"{base}/{rel}"


def _materialize_root_dir(fs: FileService, root: str | RootName) -> Path:
    root_name = _normalize_root_name(root)
    root_dir = cast(object, getattr(fs, "root_dir", None))
    if callable(root_dir):
        return cast(Callable[[RootName], Path], root_dir)(root_name)
    root_cfg = cast(object, getattr(fs, "_root", None))
    if callable(root_cfg):
        cfg = cast(Callable[[RootName], object], root_cfg)(root_name)
        path = cast(object, getattr(cfg, "dir_path", None))
        if isinstance(path, Path):
            return path
    raise RuntimeError("file_io root materialization unavailable")


def _materialize_local_path(
    fs: FileService,
    root: str | RootName,
    rel_path: str,
    *,
    silent_polling_read: bool = False,
) -> Path:
    root_name = _normalize_root_name(root)
    rel = normalize_relative_path(rel_path)
    resolver = cast(object, getattr(fs, "_resolve_local_path", None))
    if callable(resolver):
        resolved = cast(_ResolveLocalPathCallable, resolver)(
            root_name,
            rel,
            silent_polling_read=silent_polling_read,
        )
        return resolved
    resolve_abs = cast(object, getattr(fs, "resolve_abs_path", None))
    if callable(resolve_abs):
        return cast(Callable[[RootName, str], Path], resolve_abs)(root_name, rel)
    base = _materialize_root_dir(fs, root_name)
    if not rel:
        return base
    return base / Path(*[part for part in rel.split("/") if part])


def _read_json_ref(fs: FileService, root: str | RootName, rel_path: str) -> dict[str, object]:
    with fs.open_read(_normalize_root_name(root), normalize_relative_path(rel_path)) as handle:
        data = handle.read()
    parsed = cast(object, json.loads(data.decode("utf-8")))
    if not _is_str_object_dict(parsed):
        raise ValueError("JSON artifact must be an object")
    return parsed


normalize_root_name = _normalize_root_name
source_ref_from_state = _source_ref_from_state
join_source_relative_path = _join_source_relative_path
materialize_root_dir = _materialize_root_dir
materialize_local_path = _materialize_local_path
read_json_ref = _read_json_ref

__all__ = [
    "join_source_relative_path",
    "materialize_local_path",
    "materialize_root_dir",
    "normalize_root_name",
    "read_json_ref",
    "source_ref_from_state",
]
