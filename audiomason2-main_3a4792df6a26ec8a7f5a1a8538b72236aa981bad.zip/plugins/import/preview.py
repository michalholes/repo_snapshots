"""Preview artifact generation for the import wizard.

Preview artifacts are isolated engine-owned JSON documents written under:
  import/previews/<preview_id>.json

They must not modify session snapshots.

ASCII-only.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeGuard, cast

from plugins.file_io.service import FileService
from plugins.file_io.service.types import RootName

from .fingerprints import fingerprint_json
from .storage import atomic_write_json

if TYPE_CHECKING:  # pragma: no cover
    from .engine import ImportWizardEngine


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    if not isinstance(value, dict):
        return False
    return all(isinstance(key, str) for key in cast(dict[object, object], value))


def _is_object_list(value: object) -> TypeGuard[list[object]]:
    return isinstance(value, list)


def write_preview_artifact(
    *,
    fs: FileService,
    session_id: str,
    step_id: str,
    payload: dict[str, object],
    discovery_fingerprint: str,
    effective_config_fingerprint: str,
) -> dict[str, object]:
    """Write a preview artifact and return a small response envelope."""

    preview_id = fingerprint_json(
        {
            "session_id": session_id,
            "step_id": step_id,
            "payload": payload,
            "discovery_fingerprint": discovery_fingerprint,
            "effective_config_fingerprint": effective_config_fingerprint,
        }
    )

    doc: dict[str, object] = {
        "version": 1,
        "preview_id": preview_id,
        "session_id": session_id,
        "step_id": step_id,
        "payload": payload,
    }

    rel_path = f"import/previews/{preview_id}.json"
    atomic_write_json(fs, RootName.WIZARDS, rel_path, doc)
    return {"preview_id": preview_id, "path": f"wizards:{rel_path}"}


def preview_action_impl(
    *,
    engine: ImportWizardEngine,
    session_id: str,
    step_id: str,
    payload: object,
) -> dict[str, object]:
    """Implementation for ImportWizardEngine.preview_action.

    Uses the engine's existing payload validation and must not mutate the session.
    """

    from .errors import StepSubmissionError, invariant_violation

    state = engine.load_state(session_id)
    phase_any = state.get("phase")
    phase = phase_any if isinstance(phase_any, int) else 1
    if phase == 2:
        return invariant_violation(
            message="session is locked (phase 2)",
            path="$.phase",
            reason="phase_locked",
            meta={},
        )
    if state.get("status") != "in_progress":
        raise StepSubmissionError("session is not in progress")

    if not _is_str_object_dict(payload):
        raise StepSubmissionError("payload must be an object")

    effective_model = engine.load_effective_model(session_id)
    steps_any = effective_model.get("steps")
    if not _is_object_list(steps_any):
        raise StepSubmissionError("effective model missing steps")

    steps = [s for s in steps_any if _is_str_object_dict(s)]
    step_ids = {str(s.get("step_id")) for s in steps if isinstance(s.get("step_id"), str)}
    if step_id not in step_ids:
        raise StepSubmissionError("unknown step_id")

    current = str(state.get("current_step_id") or "select_authors")
    if step_id != current:
        raise StepSubmissionError("step_id must match current_step_id")

    schema: dict[str, object] | None = None
    for s in steps:
        if s.get("step_id") == step_id:
            schema = s
            break
    if schema is None:
        raise StepSubmissionError("unknown step_id")

    if step_id in {"plan_preview_batch", "processing"}:
        raise StepSubmissionError("computed-only step cannot be previewed")

    preview_action_any = schema.get("preview_action")
    if preview_action_any is None:
        raise StepSubmissionError("step has no preview_action")
    if not isinstance(preview_action_any, dict):
        raise StepSubmissionError("step.preview_action must be an object")

    normalized_payload = engine.validate_and_canonicalize_payload(
        step_id=step_id,
        schema=schema,
        payload=payload,
        state=state,
    )

    derived_any = state.get("derived")
    if not _is_str_object_dict(derived_any):
        raise StepSubmissionError("session state missing derived")
    discovery_fp = derived_any.get("discovery_fingerprint")
    eff_cfg_fp = derived_any.get("effective_config_fingerprint")
    if not isinstance(discovery_fp, str) or not discovery_fp:
        raise StepSubmissionError("session state missing discovery_fingerprint")
    if not isinstance(eff_cfg_fp, str) or not eff_cfg_fp:
        raise StepSubmissionError("session state missing effective_config_fingerprint")

    return write_preview_artifact(
        fs=engine.get_file_service(),
        session_id=session_id,
        step_id=step_id,
        payload=normalized_payload,
        discovery_fingerprint=discovery_fp,
        effective_config_fingerprint=eff_cfg_fp,
    )
