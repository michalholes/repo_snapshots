"""Interactive CLI renderer for Import Wizard.

This is UI-only: it renders steps, collects inputs, and delegates all
validation and transitions to ImportWizardEngine.

ASCII-only.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol, TypeGuard, cast, runtime_checkable

from .cli_launcher_facade import (
    begin_phase2,
    prompt_session_start_intent,
    resolve_launcher_inputs,
)
from .engine import ImportWizardEngine
from .engine_diagnostics_required import start_process_runtime
from .engine_session_start_boundary import start_user_facing_session


@dataclass(frozen=True)
class RendererConfig:
    launcher_mode: str
    default_root: str
    default_path: str
    noninteractive: bool
    confirm_defaults: bool
    show_internal_ids: bool
    max_list_items: int
    nav_ui: str


@runtime_checkable
class _ConfigResolver(Protocol):
    def resolve(self, key: str) -> tuple[object, object]: ...


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    if not isinstance(value, dict):
        return False
    return all(isinstance(key, str) for key in cast(dict[object, object], value))


def _is_object_list(value: object) -> TypeGuard[list[object]]:
    return isinstance(value, list)


def _to_int_or_default(value: object, default: int) -> int:
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return default
    return default


def _field_list(value: object) -> list[dict[str, object]]:
    if not _is_object_list(value):
        return []
    return [dict(item) for item in value if _is_str_object_dict(item)]


def _as_str_object_dict(value: object) -> dict[str, object]:
    return dict(value) if _is_str_object_dict(value) else {}


def _json_dump(obj: object) -> str:
    return json.dumps(obj, ensure_ascii=True, sort_keys=True)


def _cfg_get(resolver: object, key: str, default: object) -> object:
    if not isinstance(resolver, _ConfigResolver):
        return default
    try:
        resolved = resolver.resolve(key)
    except Exception:
        return default
    if resolved:
        return resolved[0]
    return default


def load_renderer_config(resolver: object) -> RendererConfig:
    launcher_mode = str(_cfg_get(resolver, "plugins.import.cli.launcher_mode", "interactive"))
    default_root = str(_cfg_get(resolver, "plugins.import.cli.default_root", "inbox"))
    default_path = str(_cfg_get(resolver, "plugins.import.cli.default_path", ""))

    noninteractive = bool(_cfg_get(resolver, "plugins.import.cli.noninteractive", False))
    confirm_defaults = bool(_cfg_get(resolver, "plugins.import.cli.render.confirm_defaults", True))
    show_internal_ids = bool(
        _cfg_get(resolver, "plugins.import.cli.render.show_internal_ids", False)
    )
    max_list_items_any = _cfg_get(resolver, "plugins.import.cli.render.max_list_items", 200)
    max_list_items = _to_int_or_default(max_list_items_any, 200)

    if max_list_items < 1:
        max_list_items = 1
    if max_list_items > 5000:
        max_list_items = 5000

    nav_ui_raw = str(_cfg_get(resolver, "plugins.import.cli.render.nav_ui", "prompt"))
    nav_ui = nav_ui_raw.strip().lower() or "prompt"
    if nav_ui not in {"prompt", "inline", "both"}:
        nav_ui = "prompt"

    if launcher_mode not in {"interactive", "fixed", "disabled"}:
        launcher_mode = "interactive"

    return RendererConfig(
        launcher_mode=launcher_mode,
        default_root=default_root,
        default_path=default_path,
        noninteractive=noninteractive,
        confirm_defaults=confirm_defaults,
        show_internal_ids=show_internal_ids,
        max_list_items=max_list_items,
        nav_ui=nav_ui,
    )


def run_launcher(
    *,
    engine: ImportWizardEngine,
    resolver: object,
    cli_overrides: dict[str, object],
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> int:
    start_process_runtime(engine=engine)
    cfg = load_renderer_config(resolver)
    cfg = _apply_overrides(cfg, cli_overrides)
    if cfg.launcher_mode == "disabled":
        return 0

    ok, root, rel_path, err = resolve_launcher_inputs(
        engine=engine,
        cfg=cfg,
        input_fn=input_fn,
        print_fn=print_fn,
    )
    if not ok:
        print_fn(err or "ERROR: unable to resolve launcher inputs")
        return 1

    state = start_user_facing_session(
        engine=engine,
        root=root,
        relative_path=rel_path,
        mode="stage",
        intent=None,
    )
    error_payload: dict[str, object] = {}
    error_any = state.get("error")
    if _is_str_object_dict(error_any):
        error_payload = error_any
    if _is_str_object_dict(error_payload) and error_payload.get("code") == "SESSION_START_CONFLICT":
        if cfg.noninteractive:
            print_fn(_json_dump({"state": state}))
            return 1
        details = error_payload.get("details")
        first_detail = details[0] if _is_object_list(details) and details else None
        meta = (
            _as_str_object_dict(first_detail.get("meta"))
            if _is_str_object_dict(first_detail)
            else {}
        )
        session_id = str(meta.get("session_id") or "")
        intent = prompt_session_start_intent(
            session_id=session_id,
            input_fn=input_fn,
            print_fn=print_fn,
        )
        if intent is None:
            print_fn("Canceled.")
            return 1
        state = start_user_facing_session(
            engine=engine,
            root=root,
            relative_path=rel_path,
            mode="stage",
            intent=intent,
        )

    session_id = str(state.get("session_id") or "")
    if not session_id:
        print_fn(_json_dump({"state": state}))
        return 1

    return _render_loop(
        engine=engine,
        cfg=cfg,
        session_id=session_id,
        input_fn=input_fn,
        print_fn=print_fn,
    )


def _apply_overrides(cfg: RendererConfig, overrides: dict[str, object]) -> RendererConfig:
    launcher_mode = str(overrides.get("launcher_mode", cfg.launcher_mode))
    if launcher_mode not in {"interactive", "fixed", "disabled"}:
        launcher_mode = cfg.launcher_mode

    default_root = str(overrides.get("root", cfg.default_root))
    default_path = str(overrides.get("path", cfg.default_path))

    noninteractive = bool(overrides.get("noninteractive", cfg.noninteractive))
    confirm_defaults = bool(overrides.get("confirm_defaults", cfg.confirm_defaults))
    show_internal_ids = bool(overrides.get("show_internal_ids", cfg.show_internal_ids))

    max_list_items = cfg.max_list_items
    if "max_list_items" in overrides:
        max_list_items = _to_int_or_default(overrides["max_list_items"], cfg.max_list_items)

    if max_list_items < 1:
        max_list_items = 1
    if max_list_items > 5000:
        max_list_items = 5000

    return RendererConfig(
        launcher_mode=launcher_mode,
        default_root=default_root,
        default_path=default_path,
        noninteractive=noninteractive,
        confirm_defaults=confirm_defaults,
        show_internal_ids=show_internal_ids,
        max_list_items=max_list_items,
        nav_ui=cfg.nav_ui,
    )


def _render_loop(
    *,
    engine: ImportWizardEngine,
    cfg: RendererConfig,
    session_id: str,
    input_fn: Callable[[str], str],
    print_fn: Callable[[str], None],
) -> int:
    while True:
        state = engine.get_state(session_id)
        status = str(state.get("status") or "")
        if status and status != "in_progress":
            print_fn(_json_dump({"state": state}))
            return 0 if status == "completed" else 1
        cur = str(state.get("current_step_id") or "")
        if not cur:
            print_fn(_json_dump({"state": state}))
            return 1

        if _to_int_or_default(state.get("phase"), 1) == 2:
            return _finalize(engine, session_id, print_fn=print_fn)

        step = engine.get_step_definition(session_id, cur)
        if "error" in step:
            print_fn(_json_dump({"step": step}))
            return 1

        title = str(step.get("title") or cur)
        if cfg.show_internal_ids:
            print_fn(f"Step: {title} [{cur}]")
        else:
            print_fn(f"Step: {title}")

        v3_prompt = _v3_prompt_metadata(step)
        if v3_prompt is not None:
            if cfg.noninteractive:
                print_fn("ERROR: noninteractive mode requires explicit wizard step payloads.")
                return 1
            v3_payload, v3_rc = _collect_v3_prompt_payload(
                engine=engine,
                session_id=session_id,
                step=step,
                metadata=v3_prompt,
                input_fn=input_fn,
                print_fn=print_fn,
                confirm_defaults=cfg.confirm_defaults,
                allow_inline=cfg.nav_ui in {"inline", "both"},
            )
            if v3_payload is None:
                if v3_rc is not None:
                    return v3_rc
                continue
            state3 = engine.submit_step(session_id, cur, v3_payload)
            if "error" in state3:
                print_fn(_json_dump({"state": state3}))
                return 1
            if _to_int_or_default(state3.get("phase"), 1) == 2:
                return _finalize(engine, session_id, print_fn=print_fn)
            continue

        computed_only = bool(step.get("computed_only"))
        fields_any = step.get("fields")
        fields = _field_list(fields_any)

        if computed_only or not fields:
            # No user input required; advance.
            state2 = engine.apply_action(session_id, "next")
            if _to_int_or_default(state2.get("phase"), 1) == 2:
                return _finalize(engine, session_id, print_fn=print_fn)
            continue

        if cfg.noninteractive:
            print_fn("ERROR: noninteractive mode requires explicit wizard step payloads.")
            return 1

        nav_ui = str(cfg.nav_ui or "prompt")
        allow_inline = nav_ui in {"inline", "both"}
        show_action_prompt = nav_ui in {"prompt", "both"}

        def _handle_inline_nav(
            raw: str, *, _allow_inline: bool = allow_inline
        ) -> tuple[bool, int | None]:
            if not _allow_inline:
                return False, None
            expr = str(raw or "").strip().lower()
            if expr in {":back", "back"}:
                engine.apply_action(session_id, "back")
                return True, None
            if expr in {":cancel", "cancel"}:
                engine.apply_action(session_id, "cancel")
                return True, 1
            return False, None

        payload: dict[str, object] = {}
        back_requested = False

        for f in fields:
            name = f.get("name")
            ftype = f.get("type")
            if not isinstance(name, str) or not isinstance(ftype, str):
                continue

            if ftype == "multi_select_indexed":
                _show_select_items(field=f, name=name, cfg=cfg, print_fn=print_fn)
                expr = input_fn(f"{name} selection (e.g. all, 1,3,5-8): ").strip()
                handled, rc = _handle_inline_nav(expr)
                if handled:
                    if rc is not None:
                        return rc
                    back_requested = True
                    break
                payload[f"{name}_expr"] = expr
                continue

            if ftype in {"toggle", "confirm"}:
                raw = input_fn(f"{name} (y/n): ").strip().lower()
                handled, rc = _handle_inline_nav(raw)
                if handled:
                    if rc is not None:
                        return rc
                    back_requested = True
                    break
                payload[name] = raw in {"y", "yes", "1", "true", "t"}
                continue

            if ftype == "number":
                raw = input_fn(f"{name} (int): ").strip()
                handled, rc = _handle_inline_nav(raw)
                if handled:
                    if rc is not None:
                        return rc
                    back_requested = True
                    break
                try:
                    payload[name] = int(raw)
                except Exception:
                    payload[name] = raw
                continue

            if ftype in {"text", "select"}:
                raw = input_fn(f"{name}: ").rstrip("\n")
                handled, rc = _handle_inline_nav(raw)
                if handled:
                    if rc is not None:
                        return rc
                    back_requested = True
                    break
                payload[name] = raw
                continue

            # Fallback: ask for raw JSON value.
            raw = input_fn(f"{name} (raw): ").rstrip("\n")
            handled, rc = _handle_inline_nav(raw)
            if handled:
                if rc is not None:
                    return rc
                back_requested = True
                break
            payload[name] = raw

        if back_requested:
            continue

        state3 = engine.submit_step(session_id, cur, payload)
        if "error" in state3:
            print_fn(_json_dump({"state": state3}))
            return 1
        if _to_int_or_default(state3.get("phase"), 1) == 2:
            return _finalize(engine, session_id, print_fn=print_fn)

        if show_action_prompt:
            nav = input_fn("Action (:next, :back, :cancel, Enter=continue): ").strip().lower()
            if nav in {":next", "next"}:
                engine.apply_action(session_id, "next")
            elif nav in {":back", "back"}:
                engine.apply_action(session_id, "back")
            elif nav in {":cancel", "cancel"}:
                engine.apply_action(session_id, "cancel")
                return 1

        continue


def _show_select_items(
    *,
    field: dict[str, object],
    name: str,
    cfg: RendererConfig,
    print_fn: Callable[[str], None],
) -> None:
    items_any = field.get("items")
    if not _is_object_list(items_any):
        print_fn(f"ERROR: field '{name}' has no selectable items")
        return

    items = _field_list(items_any)
    if not items:
        print_fn(f"ERROR: field '{name}' has no selectable items")
        return

    print_fn(f"Selectable items for '{name}':")
    for idx, it in enumerate(items[: cfg.max_list_items], start=1):
        label = str(it.get("display_label") or it.get("label") or "")
        item_id = str(it.get("item_id") or "")
        if cfg.show_internal_ids and item_id:
            print_fn(f"  {idx}. {label} [{item_id}]")
        else:
            print_fn(f"  {idx}. {label}")
    if len(items) > cfg.max_list_items:
        print_fn(f"  ... ({len(items) - cfg.max_list_items} more)")


def _v3_prompt_metadata(step: dict[str, object]) -> dict[str, object] | None:
    primitive_id = str(step.get("primitive_id") or "")
    primitive_version = _to_int_or_default(step.get("primitive_version"), 0)
    ui_any = step.get("ui")
    if primitive_version != 1 or primitive_id not in {
        "ui.prompt_text",
        "ui.prompt_select",
        "ui.prompt_confirm",
    }:
        return None
    return dict(ui_any) if _is_str_object_dict(ui_any) else None


def _prompt_seed_value(metadata: dict[str, object]) -> object:
    if "prefill" in metadata:
        return metadata["prefill"]
    if "default_value" in metadata:
        return metadata["default_value"]
    return None


def _stringify_prompt_value(value: object) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float, str)):
        return str(value)
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)


def _parse_prompt_value(raw: str) -> object:
    if raw == "":
        return ""
    try:
        return cast(object, json.loads(raw))
    except Exception:
        return raw


def _display_prompt_select_items(
    metadata: dict[str, object],
    *,
    print_fn: Callable[[str], None],
) -> None:
    items_any = metadata.get("items")
    items = _field_list(items_any)
    if not items:
        return
    print_fn("Options:")
    for index, item in enumerate(items, start=1):
        label = str(item.get("display_label") or item.get("label") or item.get("item_id") or "")
        if not label:
            label = f"item {index}"
        print_fn(f"  {index}. {label}")


def _collect_v3_prompt_payload(
    *,
    engine: ImportWizardEngine,
    session_id: str,
    step: dict[str, object],
    metadata: dict[str, object],
    input_fn: Callable[[str], str],
    print_fn: Callable[[str], None],
    confirm_defaults: bool,
    allow_inline: bool,
) -> tuple[dict[str, object] | None, int | None]:
    primitive_id = str(step.get("primitive_id") or "")
    label = str(metadata.get("label") or "")
    prompt = str(metadata.get("prompt") or "")
    help_text = str(metadata.get("help") or "")
    hint = str(metadata.get("hint") or "")
    examples_any = metadata.get("examples")
    seed = _prompt_seed_value(metadata)
    seed_defined = "prefill" in metadata or "default_value" in metadata

    if label:
        print_fn(label)
    if prompt:
        print_fn(prompt)
    if help_text:
        print_fn(help_text)
    if hint:
        print_fn(f"Note: {hint}")
    if _is_object_list(examples_any) and examples_any:
        print_fn("Examples:")
        for example in examples_any:
            print_fn(f"  - {_stringify_prompt_value(example)}")
    if seed_defined:
        print_fn(f"Suggested: {_stringify_prompt_value(seed)}")
    if primitive_id == "ui.prompt_select":
        _display_prompt_select_items(metadata, print_fn=print_fn)

    def _handle_inline_nav(raw: str) -> tuple[dict[str, object] | None, int | None] | None:
        if not allow_inline:
            return None
        expr = raw.strip().lower()
        if expr in {":back", "back"}:
            engine.apply_action(session_id, "back")
            return None, None
        if expr in {":cancel", "cancel"}:
            engine.apply_action(session_id, "cancel")
            return None, 1
        return None

    if primitive_id == "ui.prompt_confirm":
        prompt_text = prompt or label or "Confirm"
        default_hint = ""
        if confirm_defaults and seed_defined and isinstance(seed, bool):
            default_hint = " (Enter=default)"
        raw = input_fn(f"{prompt_text} (y/n){default_hint}: ").strip().lower()
        nav_result = _handle_inline_nav(raw)
        if nav_result is not None:
            return nav_result
        if raw == "" and confirm_defaults and seed_defined and isinstance(seed, bool):
            return {"confirmed": seed}, None
        return {"confirmed": raw in {"y", "yes", "1", "true", "t"}}, None

    prompt_text = prompt or label or "Value"
    default_hint = ""
    if confirm_defaults and seed_defined:
        default_hint = " (Enter=default)"
    raw = input_fn(f"{prompt_text}{default_hint}: ").rstrip("\n")
    nav_result = _handle_inline_nav(raw)
    if nav_result is not None:
        return nav_result
    if raw == "" and primitive_id == "ui.prompt_text" and not seed_defined:
        return {"value": None}, None
    value = seed if raw == "" and confirm_defaults and seed_defined else _parse_prompt_value(raw)
    key = "value" if primitive_id == "ui.prompt_text" else "selection"
    return {key: value}, None


def _finalize(
    engine: ImportWizardEngine, session_id: str, *, print_fn: Callable[[str], None]
) -> int:
    return begin_phase2(engine, session_id, print_fn=print_fn)
