"""CLI plugin - Enhanced command-line interface with preflight and verbosity.

Features:
- Preflight detection (auto-guess metadata)
- Smart batch grouping
- 4 verbosity modes (quiet/normal/verbose/debug)
- Progress display
- User-friendly prompts
"""

from __future__ import annotations

import asyncio
import inspect
import sys
import uuid
from collections.abc import Awaitable, Callable, Mapping
from pathlib import Path
from typing import Protocol, cast

from audiomason.core import (
    ConfigResolver,
    CoverChoice,
    PluginLoader,
    PreflightResult,
    ProcessingContext,
    State,
    detect_file_groups,
    detect_format,
    find_file_cover,
    guess_author_from_path,
    guess_title_from_path,
    guess_year_from_path,
)
from audiomason.core.config_service import ConfigService
from audiomason.core.errors import PluginError
from audiomason.core.jobs.model import JobState
from audiomason.core.loader import PluginManifest
from audiomason.core.logging import apply_logging_policy, get_logger, set_log_file
from audiomason.core.orchestration import Orchestrator
from audiomason.core.orchestration_models import ProcessRequest
from audiomason.core.plugin_registry import PluginRegistry

log = get_logger(__name__)


class VerbosityLevel:
    """Verbosity levels."""

    QUIET = 0  # Errors only
    NORMAL = 1  # Progress + warnings + errors
    VERBOSE = 2  # Detailed info
    DEBUG = 3  # Everything


CORE_COMMANDS: set[str] = {
    "process",
    "web",
    "daemon",
    "checkpoints",
    "version",
    "help",
}


class _CLICommandsPlugin(Protocol):
    def get_cli_commands(self) -> dict[str, Callable[[list[str]], object]]: ...


class _WebPlugin(Protocol):
    config_resolver: ConfigResolver
    plugin_loader: PluginLoader
    verbosity: int

    async def run(self) -> object: ...


class _DaemonPlugin(Protocol):
    verbosity: int

    async def run(self) -> object: ...


class _TUIPlugin(Protocol):
    async def run(self) -> object: ...


class _TUIPluginFactory(Protocol):
    def __call__(self, config: dict[str, object]) -> _TUIPlugin: ...


def _dict_str_object(value: object) -> dict[str, object]:
    if not isinstance(value, Mapping):
        return {}
    mapping = cast(Mapping[object, object], value)
    out: dict[str, object] = {}
    for key, item in mapping.items():
        if isinstance(key, str):
            out[key] = item
    return out


def _to_str_or_none(value: object) -> str | None:
    if isinstance(value, str):
        text = value.strip()
        if text:
            return text
    return None


def _to_int_or_none(value: object) -> int | None:
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            return int(text)
        except ValueError:
            return None
    return None


def _to_bool_or_default(value: object, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    return default


def _path_name(path: Path) -> str:
    return path.name


def _manifest_name(item: tuple[Path, PluginManifest]) -> str:
    return item[1].name


def _as_awaitable(value: object) -> Awaitable[object] | None:
    if inspect.isawaitable(value):
        return cast(Awaitable[object], value)
    return None


def preload_supported_web_plugins(*, loader: PluginLoader, plugins_dir: Path) -> None:
    """Preload plugin surfaces required by the supported web launch path."""
    try:
        loader.get_plugin("import")
        return
    except PluginError:
        pass

    import_dir = plugins_dir / "import"
    if not (import_dir / "plugin.yaml").is_file():
        raise PluginError("Import plugin not found")

    loader.load_plugin(import_dir, validate=False)


class CLIPlugin:
    """Enhanced CLI plugin."""

    def __init__(self, config: dict[str, object] | None = None) -> None:
        """Initialize CLI plugin.

        Args:
            config: Plugin configuration
        """
        self.config = dict(config) if config is not None else {}
        self.verbosity = VerbosityLevel.NORMAL
        self.cli_args: dict[str, object] = {}
        # Original argv snapshot used for CLI parsing (set in run())
        self._original_argv: list[str] = []
        # Mapping: command_name -> (plugin_dir, plugin_name)
        self._plugin_cli_commands: dict[str, tuple[Path, str]] = {}
        # Session-level failure isolation: plugin_name -> error summary.
        self._failed_plugins: dict[str, str] = {}

    def _parse_cli_args(self, *, emit_debug: bool = True) -> dict[str, object]:
        """Parse all CLI arguments into a dictionary for ConfigResolver.

        Returns:
            Dictionary of CLI arguments with nested structure for dotted keys
        """
        cli_args: dict[str, object] = {}

        def _ensure_dict(root: dict[str, object], key: str) -> dict[str, object]:
            child = _dict_str_object(root.get(key))
            root[key] = child
            return child

        # Use original argv (before verbosity extraction)
        args_snapshot = self._original_argv if self._original_argv else sys.argv
        args = args_snapshot[1:]  # Skip program name
        i = 0

        while i < len(args):
            arg = args[i]

            # Verbosity flags
            if arg in ("-q", "--quiet"):
                _ensure_dict(cli_args, "logging")["level"] = "quiet"
            elif arg in ("-v", "--verbose"):
                _ensure_dict(cli_args, "logging")["level"] = "verbose"
            elif arg in ("-d", "--debug"):
                _ensure_dict(cli_args, "logging")["level"] = "debug"

            # Port flag - nested under 'web'
            elif arg == "--port" and i + 1 < len(args):
                _ensure_dict(cli_args, "web")["port"] = int(args[i + 1])
                i += 1  # Skip next arg

            # Bitrate flag - nested under 'audio'
            elif arg == "--bitrate" and i + 1 < len(args):
                _ensure_dict(cli_args, "audio")["bitrate"] = args[i + 1]
                i += 1

            # Output directory
            elif arg == "--output" and i + 1 < len(args):
                cli_args["output_dir"] = args[i + 1]
                i += 1

            # Pipeline
            elif arg == "--pipeline" and i + 1 < len(args):
                cli_args["pipeline"] = args[i + 1]
                i += 1

            # Loudnorm flag - nested under 'audio'
            elif arg == "--loudnorm":
                _ensure_dict(cli_args, "audio")["loudnorm"] = True
            elif arg == "--no-loudnorm":
                _ensure_dict(cli_args, "audio")["loudnorm"] = False

            # Split chapters - nested under 'audio'
            elif arg == "--split-chapters":
                _ensure_dict(cli_args, "audio")["split_chapters"] = True
            elif arg == "--no-split-chapters":
                _ensure_dict(cli_args, "audio")["split_chapters"] = False

            # Runtime diagnostics (structured event sink)
            elif arg == "--diagnostics":
                _ensure_dict(cli_args, "diagnostics")["enabled"] = True
            elif arg == "--no-diagnostics":
                _ensure_dict(cli_args, "diagnostics")["enabled"] = False

            i += 1

        if emit_debug:
            self._debug(f"Parsed CLI args: {cli_args}")
        return cli_args

    def _extract_verbosity_from_argv(self) -> None:
        """Extract verbosity flags from sys.argv and remove them.

        This allows verbosity flags to be in ANY position:
        - audiomason -d tui
        - audiomason tui -d
        - audiomason -v process book.m4a
        """
        # Check all arguments for verbosity flags
        args_to_remove: list[int] = []

        for i, arg in enumerate(sys.argv):
            if arg in ("-q", "--quiet"):
                self.verbosity = VerbosityLevel.QUIET
                args_to_remove.append(i)
            elif arg in ("-v", "--verbose"):
                self.verbosity = VerbosityLevel.VERBOSE
                args_to_remove.append(i)
            elif arg in ("-d", "--debug"):
                self.verbosity = VerbosityLevel.DEBUG
                args_to_remove.append(i)

        # Remove verbosity flags from sys.argv (in reverse order to preserve indices)
        for i in reversed(args_to_remove):
            sys.argv.pop(i)

        self._debug(f"Verbosity level set to: {self.verbosity}")

    def _build_plugin_cli_stub_registry(
        self, *, plugin_dirs: list[Path] | None = None
    ) -> dict[str, tuple[Path, str]]:
        """Build manifest-only CLI command stub registry.

        Returns:
            Mapping: command_name -> plugin_name

        Raises:
            PluginError: on collisions, shadowing, or invalid manifests.
        """
        plugins_dir = Path(__file__).parent.parent

        # NOTE: For tests that provide explicit plugin dirs, do not read or enforce
        # user configuration state from ConfigService/PluginRegistry.
        reg: PluginRegistry | None
        if plugin_dirs is None:
            cfg = ConfigService()
            reg = PluginRegistry(cfg)
        else:
            reg = None

        loader = PluginLoader(builtin_plugins_dir=plugins_dir, registry=reg)

        if plugin_dirs is None:
            discovered = loader.discover()
        else:
            discovered = sorted(plugin_dirs, key=_path_name)

        manifests_and_dirs: list[tuple[Path, PluginManifest]] = []
        for pdir in discovered:
            manifest = loader.load_manifest_only(pdir)

            if reg is not None and not reg.is_enabled(manifest.name):
                continue
            if "ICLICommands" in manifest.interfaces:
                manifests_and_dirs.append((pdir, manifest))

        manifests_and_dirs.sort(key=_manifest_name)

        stubs: dict[str, tuple[Path, str]] = {}
        for pdir, manifest in manifests_and_dirs:
            for cmd in manifest.cli_commands:
                if cmd in CORE_COMMANDS:
                    raise PluginError(f"CLI command conflict with core command: {cmd}")
                if cmd in stubs:
                    raise PluginError(f"CLI command name collision: {cmd}")
                stubs[cmd] = (pdir, manifest.name)

        return stubs

    @staticmethod
    def _format_plugin_help_lines(
        stubs: dict[str, tuple[Path, str]], *, failed_plugins: dict[str, str]
    ) -> list[str]:
        lines: list[str] = []
        for cmd in sorted(stubs.keys()):
            plugin_name = stubs[cmd][1]
            suffix = " [unavailable]" if plugin_name in failed_plugins else ""
            lines.append(f"{cmd}    (plugin: {plugin_name}){suffix}")
        return lines

    @classmethod
    def _build_help_for_tests(cls, plugin_dirs: list[Path]) -> str:
        """Build help output for unit tests using temporary plugin dirs."""
        cli = cls()
        stubs = cli._build_plugin_cli_stub_registry(plugin_dirs=plugin_dirs)
        return cli._format_usage(stubs)

    async def run(self) -> None:
        """Run CLI - main entry point."""
        # Store original argv before modification
        self._original_argv = sys.argv.copy()

        # Extract verbosity flags from ANY position in argv
        self._extract_verbosity_from_argv()

        # Resolve logging policy and apply it to the core logger (global).
        # This must come from ConfigResolver.resolve_logging_policy() and must
        # not be derived directly from self.verbosity.
        cli_args = self._parse_cli_args(emit_debug=False)
        resolver = ConfigResolver(cli_args=cli_args)
        policy = resolver.resolve_logging_policy()
        apply_logging_policy(policy)

        # Optional human-readable system log file (global).
        try:
            if resolver.resolve_system_log_enabled():
                set_log_file(resolver.resolve_system_log_path())
            else:
                set_log_file(None)
        except Exception as e:
            set_log_file(None)
            log.warning(f"Failed to configure system log file: {e}")

        # Always register diagnostics sink; it self-filters when disabled.
        from audiomason.core.diagnostics import install_jsonl_sink

        install_jsonl_sink(resolver=resolver)

        # Now that core logging is configured, emit debug-only diagnostics.
        self._debug(f"Parsed CLI args: {cli_args}")

        # Build stub registry for plugin-provided CLI commands (manifest-only).
        self._plugin_cli_commands = self._build_plugin_cli_stub_registry()

        exit_code = await self._execute_argv(sys.argv)
        if exit_code != 0:
            raise SystemExit(exit_code)

    def _format_usage(self, stubs: dict[str, tuple[Path, str]]) -> str:
        lines: list[str] = []
        lines.append("AudioMason v2.0.0-alpha")
        lines.append("")
        lines.append("Usage:")
        lines.append("  audiomason process <file(s)>   Process audiobook file(s)")
        lines.append("  audiomason import              Run import wizard (CLI)")
        lines.append("  audiomason tui                 Terminal UI (ncurses)")
        lines.append("  audiomason web [--port PORT]   Start web server")
        lines.append("  audiomason daemon              Start daemon mode")
        lines.append("  audiomason checkpoints         Manage checkpoints")
        lines.append("  audiomason version             Show version")
        lines.append("  audiomason help                Show this help")
        lines.append("")
        lines.append("Options:")
        lines.append("  --author TEXT                  Book author")
        lines.append("  --title TEXT                   Book title")
        lines.append("  --year INT                     Publication year")
        lines.append("  --bitrate TEXT                 Audio bitrate (default: 128k)")
        lines.append("  --loudnorm                     Enable loudness normalization")
        lines.append("  --split-chapters               Split M4A by chapters")
        lines.append("  --cover [embedded|file|url|skip]  Cover source")
        lines.append("  --cover-url URL                Cover URL (if --cover url)")
        lines.append("  --diagnostics                  Enable runtime diagnostics JSONL sink")
        lines.append("  --no-diagnostics               Disable runtime diagnostics JSONL sink")
        lines.append("")
        lines.append("Verbosity:")
        lines.append("  -q, --quiet                    Quiet mode (errors only)")
        lines.append("  -v, --verbose                  Verbose mode (detailed info)")
        lines.append("  -d, --debug                    Debug mode (everything)")
        lines.append("")
        if stubs:
            lines.append("Plugin commands:")
            for line in self._format_plugin_help_lines(stubs, failed_plugins=self._failed_plugins):
                lines.append(f"  {line}")
            lines.append("")
        lines.append("Examples:")
        lines.append("  audiomason process book.m4a")
        lines.append('  audiomason process book.m4a --author "George Orwell" --title "1984"')
        lines.append("  audiomason web --port 8080")
        lines.append("  audiomason process *.m4a --bitrate 320k --loudnorm -v")
        return "\n".join(lines)

    def _print_usage(self) -> None:
        """Print usage information."""
        print(self._format_usage(self._plugin_cli_commands))

    async def _execute_argv(self, argv: list[str], *, plugin_dirs: list[Path] | None = None) -> int:
        """Execute a single CLI argv invocation.

        This is used by the real CLI entrypoint and by tests.

        Returns:
            Exit code (0 for success).
        """
        # Allow tests to provide isolated plugin directories.
        if plugin_dirs is not None:
            self._plugin_cli_commands = self._build_plugin_cli_stub_registry(
                plugin_dirs=plugin_dirs
            )

        if len(argv) < 2:
            self._print_usage()
            return 0

        command = argv[1]

        # Handle --help and -h flags
        if command in ("--help", "-h"):
            self._print_usage()
            return 0

        # Core commands are executed unchanged.
        if command == "process":
            await self._process_command(argv[2:])
            return 0
        if command == "tui":
            await self._tui_command()
            return 0
        if command == "version":
            self._version_command()
            return 0
        if command == "help":
            self._print_usage()
            return 0
        if command == "web":
            await self._web_command(argv[2:])
            return 0
        if command == "daemon":
            await self._daemon_command()
            return 0
        if command == "checkpoints":
            await self._checkpoints_command(argv[2:])
            return 0

        # Plugin command dispatch.
        return await self._execute_plugin_command(command, argv[2:])

    async def _execute_plugin_command(self, command: str, argv: list[str]) -> int:
        stub = self._plugin_cli_commands.get(command)
        if stub is None:
            self._error(f"Unknown command: {command}")
            self._print_usage()
            return 1

        plugin_dir, plugin_name = stub

        if plugin_name in self._failed_plugins:
            reason = self._failed_plugins[plugin_name]
            self._error(f"Plugin failed for session: {plugin_name}: {reason}")
            return 1

        plugins_dir = Path(__file__).parent.parent
        cfg = ConfigService()
        reg = PluginRegistry(cfg)
        loader = PluginLoader(builtin_plugins_dir=plugins_dir, registry=reg)

        try:
            plugin_obj = loader.load_plugin(plugin_dir, validate=False)
            plugin = cast(_CLICommandsPlugin, plugin_obj)
            commands = plugin.get_cli_commands()
            if command not in commands:
                raise PluginError(
                    "ICLICommands contract violation: get_cli_commands() did not "
                    f"provide '{command}'"
                )

            handler = commands[command]
            result = handler(argv)
            awaitable_result = _as_awaitable(result)
            if awaitable_result is not None:
                await awaitable_result
            return 0
        except Exception as e:
            summary = str(e) or e.__class__.__name__
            self._failed_plugins[plugin_name] = summary
            self._error(f"Plugin command failed: {command} (plugin: {plugin_name}): {summary}")
            return 1

    def _version_command(self) -> None:
        """Print version."""
        print("AudioMason v2.0.0-alpha")

    async def _process_command(self, args: list[str]) -> None:
        """Process command.

        Args:
            args: Command arguments
        """
        # Parse arguments
        files, cli_args = self._parse_args(args)
        self.cli_args = cli_args  # Store for processing phase

        if not files:
            self._error("No input file(s) specified")
            self._print_usage()
            return

        # Verbosity is already set globally in run()

        self._info(f"[AUDIO] AudioMason v2 - Processing {len(files)} file(s)")
        self._info("")

        # ===========================================
        #  PHASE 0: PREFLIGHT
        # ===========================================

        self._verbose("Phase 0: Preflight detection...")
        preflight_results = await self._process_preflight_phase(files)

        # ===========================================
        #  PHASE 1: USER INPUT
        # ===========================================

        self._verbose("Phase 1: Collecting metadata...")
        contexts = await self._process_input_phase(files, preflight_results, cli_args)

        if not contexts:
            return

        # ===========================================
        #  PHASE 2: PROCESSING
        # ===========================================

        self._info("Phase 2: Processing...")
        self._info("")

        # Phase 2 is executed via the core orchestrator.
        await self._processing_phase_orchestrated(contexts)

    async def _processing_phase_orchestrated(self, contexts: list[ProcessingContext]) -> None:
        """Process via the core orchestrator (Phase 2).

        Args:
            contexts: Processing contexts
        """
        self._verbose("Loading plugins...")
        plugins_dir = Path(__file__).parent.parent
        cfg = ConfigService()
        reg = PluginRegistry(cfg)
        loader = PluginLoader(builtin_plugins_dir=plugins_dir, registry=reg)

        required_plugins = ["audio_processor", "file_io", "id3_tagger", "cover_handler"]
        for plugin_name in required_plugins:
            plugin_dir = plugins_dir / plugin_name
            if not plugin_dir.exists():
                continue
            try:
                loader.load_plugin(plugin_dir, validate=False)
                self._debug(f"  loaded {plugin_name}")
            except Exception as e:  # pragma: no cover
                self._verbose(f"  {plugin_name}: {e}")

        pipeline_name = _to_str_or_none(self.cli_args.get("pipeline")) or "standard"
        pipeline_path = Path(__file__).parent.parent.parent / "pipelines" / f"{pipeline_name}.yaml"
        if not pipeline_path.exists():
            self._error(f"Pipeline not found: {pipeline_path}")
            return

        orch = Orchestrator()
        job_id = orch.start_process(
            ProcessRequest(contexts=contexts, pipeline_path=pipeline_path, plugin_loader=loader)
        )

        offset = 0
        while True:
            job = orch.get_job(job_id)
            chunk, offset = orch.read_log(job_id, offset=offset)
            if chunk:
                for line in chunk.splitlines():
                    self._info(line)

            if job.state in (JobState.SUCCEEDED, JobState.FAILED, JobState.CANCELLED):
                break

            await asyncio.sleep(0.2)

        if job.state == JobState.FAILED and job.error:
            self._error(job.error)

    async def _process_preflight_phase(self, files: list[Path]) -> dict[Path, PreflightResult]:
        """Run preflight detection.

        Args:
            files: Input files

        Returns:
            Dict of file -> PreflightResult
        """
        results: dict[Path, PreflightResult] = {}

        for file in files:
            result = PreflightResult()

            # Detect format
            fmt = detect_format(file)
            result.is_m4a = fmt == "m4a"
            result.is_opus = fmt == "opus"
            result.is_mp3 = fmt == "mp3"

            # Guess metadata
            result.guessed_author = guess_author_from_path(file)
            result.guessed_title = guess_title_from_path(file)
            result.guessed_year = guess_year_from_path(file)

            # Check for file cover
            cover = find_file_cover(file.parent)
            result.has_file_cover = cover is not None
            result.file_cover_path = cover

            # File info
            result.file_size_bytes = file.stat().st_size

            results[file] = result

            self._debug(f"  {file.name}:")
            self._debug(f"    Format: {fmt}")
            self._debug(f"    Guessed author: {result.guessed_author}")
            self._debug(f"    Guessed title: {result.guessed_title}")

        return results

    async def _process_input_phase(
        self,
        files: list[Path],
        preflight_results: dict[Path, PreflightResult],
        cli_args: dict[str, object],
    ) -> list[ProcessingContext]:
        """Collect user input.

        Args:
            files: Input files
            preflight_results: Preflight results
            cli_args: CLI arguments

        Returns:
            List of contexts with metadata
        """
        contexts: list[ProcessingContext] = []

        # Smart grouping by author
        groups = detect_file_groups(files)

        self._verbose(f"Detected {len(groups)} author group(s)")

        # Ask for author per group
        author_map: dict[Path, str] = {}
        author_override = _to_str_or_none(cli_args.get("author"))
        title_override = _to_str_or_none(cli_args.get("title"))
        year_override = _to_int_or_none(cli_args.get("year"))
        cover_override = (_to_str_or_none(cli_args.get("cover")) or "").lower()
        cover_url_override = _to_str_or_none(cli_args.get("cover_url"))
        bitrate_option = _to_str_or_none(cli_args.get("bitrate")) or "128k"
        loudnorm_option = _to_bool_or_default(cli_args.get("loudnorm"), False)
        split_chapters_option = _to_bool_or_default(cli_args.get("split_chapters"), False)

        for author_guess, group_files in groups.items():
            # Check if author provided via CLI
            if author_override is not None:
                author = author_override
            else:
                # Prompt for author
                default = author_guess if author_guess != "unknown" else None
                prompt_text = f"\U0001f4da Author for {len(group_files)} file(s)"
                if default:
                    prompt_text += f" [{default}]"
                prompt_text += ": "

                try:
                    author = input(prompt_text).strip()
                    if not author and default:
                        author = default
                except (KeyboardInterrupt, EOFError):
                    self._error("\nCancelled")
                    return []

            # Map all files in group to this author
            for file in group_files:
                author_map[file] = author

        # Create contexts
        for file in files:
            preflight = preflight_results[file]

            # Create context
            ctx = ProcessingContext(
                id=str(uuid.uuid4()),
                source=file,
                state=State.INIT,
                preflight=preflight,
            )

            # Author
            ctx.author = author_map.get(file, "Unknown")

            # Title
            if title_override is not None:
                ctx.title = title_override
            else:
                default = preflight.guessed_title
                prompt_text = f"\U0001f4d6 Title for {file.name}"
                if default:
                    prompt_text += f" [{default}]"
                prompt_text += ": "

                try:
                    title = input(prompt_text).strip()
                    if not title and default:
                        title = default
                    ctx.title = title if title else file.stem
                except (KeyboardInterrupt, EOFError):
                    self._error("\nCancelled")
                    return []

            # Year
            if year_override is not None:
                ctx.year = year_override
            elif preflight.guessed_year:
                ctx.year = preflight.guessed_year

            # Cover choice
            if cover_override:
                ctx.cover_choice = {
                    "embedded": CoverChoice.EMBEDDED,
                    "file": CoverChoice.FILE,
                    "url": CoverChoice.URL,
                    "skip": CoverChoice.SKIP,
                }.get(cover_override, CoverChoice.SKIP)

                if ctx.cover_choice == CoverChoice.URL and cover_url_override is not None:
                    ctx.cover_url = cover_url_override

            # Processing options
            ctx.target_bitrate = bitrate_option
            ctx.loudnorm = loudnorm_option
            ctx.split_chapters = split_chapters_option

            contexts.append(ctx)

        self._info("")
        self._verbose(f"Collected metadata for {len(contexts)} file(s)")
        self._info("")

        return contexts

    def _parse_args(self, args: list[str]) -> tuple[list[Path], dict[str, object]]:
        """Parse command-line arguments.

        Args:
            args: Argument list

        Returns:
            (files, options) tuple
        """
        files: list[Path] = []
        options: dict[str, object] = {}
        i = 0

        while i < len(args):
            arg = args[i]

            if arg.startswith("--"):
                key = arg[2:]

                # Boolean flags
                if key in [
                    "loudnorm",
                    "split-chapters",
                    "split_chapters",
                    "quiet",
                    "verbose",
                    "debug",
                ]:
                    options[key.replace("-", "_")] = True
                    i += 1
                # Value options
                elif i + 1 < len(args) and not args[i + 1].startswith("-"):
                    value = args[i + 1]
                    options[key.replace("-", "_")] = value
                    i += 2
                else:
                    i += 1

            elif arg.startswith("-"):
                # Short flags
                if arg == "-q":
                    options["quiet"] = True
                elif arg == "-v":
                    options["verbose"] = True
                elif arg == "-d":
                    options["debug"] = True
                i += 1

            else:
                # File argument - expand wildcards
                from glob import glob

                matches = glob(arg)
                if matches:
                    files.extend([Path(f) for f in matches if Path(f).is_file()])
                else:
                    # Not a wildcard, just a file
                    file = Path(arg)
                    if file.exists():
                        files.append(file)
                i += 1

        return files, options

    # Logging methods
    def _info(self, msg: str) -> None:
        """Log info message."""
        log.info(msg)

    def _verbose(self, msg: str) -> None:
        """Log verbose message."""
        if self.verbosity >= VerbosityLevel.VERBOSE:
            log.info(msg)

    def _debug(self, msg: str) -> None:
        """Log debug message."""
        if self.verbosity >= VerbosityLevel.DEBUG:
            log.debug(msg)

    def _error(self, msg: str) -> None:
        """Log error message."""
        log.error(msg)

    def _configure_quiet_web_console(self) -> None:
        """Configure logging so quiet web mode prints only the required 2 lines.

        This is intentionally scoped to the current process invocation.
        """
        import logging

        # Disable everything below ERROR globally.
        logging.disable(logging.ERROR - 1)

        # Uvicorn uses these loggers for startup/shutdown and access logs.
        for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
            logger = logging.getLogger(name)
            logger.handlers.clear()
            logger.propagate = False
            logger.setLevel(logging.ERROR)

    async def _web_command(self, args: list[str]) -> None:
        """Start web server.

        Args:
            args: Command arguments
        """
        if self.verbosity >= VerbosityLevel.DEBUG:
            self._debug(f"Starting web server with verbosity: {self.verbosity}")

        # Parse CLI arguments
        cli_args = self._parse_cli_args()

        if self.verbosity >= VerbosityLevel.DEBUG:
            log.debug(f"Parsed CLI args: {cli_args}")

        # Create ConfigResolver with CLI args
        config_resolver = ConfigResolver(cli_args=cli_args)

        # Resolve web server port
        try:
            port, source = config_resolver.resolve("web.port")
            if self.verbosity >= VerbosityLevel.DEBUG:
                log.debug(f"Resolved port {port} from {source}")
            self._verbose(f"Using port {port} (source: {source})")
        except Exception as e:
            port = 8080
            if self.verbosity >= VerbosityLevel.DEBUG:
                log.debug(f"Failed to resolve web.port: {e}, using default 8080")
            self._debug("Using default port 8080")

        if self.verbosity <= VerbosityLevel.QUIET:
            self._configure_quiet_web_console()
            print(f"Starting web server on port {port}...", flush=True)
        else:
            self._info(f"\U0001f310 Starting web server on port {port}...")

        # Load web server plugin
        plugins_dir = Path(__file__).parent.parent
        cfg = ConfigService()
        reg = PluginRegistry(cfg)
        loader = PluginLoader(builtin_plugins_dir=plugins_dir, registry=reg)

        if self.verbosity >= VerbosityLevel.DEBUG:
            log.debug(f"Plugins directory: {plugins_dir}")

        try:
            preload_supported_web_plugins(loader=loader, plugins_dir=plugins_dir)
        except Exception as e:
            self._error(f"X Error preloading import plugin: {e}")
            raise SystemExit(1) from e

        # Deterministic manifest-only selection (no eager load-all).
        candidate_names = ["web_interface", "web_server"]
        plugin_dirs = sorted(
            [d for d in plugins_dir.iterdir() if d.is_dir() and (d / "plugin.yaml").exists()],
            key=_path_name,
        )

        selected_dir: Path | None = None
        selected_name: str | None = None

        for plugin_dir in plugin_dirs:
            try:
                manifest = loader.load_manifest_only(plugin_dir)
            except Exception as e:
                if self.verbosity >= VerbosityLevel.DEBUG:
                    log.debug(
                        f"Manifest load failed for {plugin_dir.name}: {type(e).__name__}: {e}"
                    )
                continue

            if manifest.name not in candidate_names:
                continue

            # Prefer web_interface over web_server.
            if manifest.name == "web_interface":
                selected_dir = plugin_dir
                selected_name = manifest.name
                break

            if selected_dir is None:
                selected_dir = plugin_dir
                selected_name = manifest.name

        if selected_dir is None or selected_name is None:
            self._error("X Web server plugin not found")
            return

        try:
            web_plugin = loader.load_plugin(selected_dir, validate=False)
        except Exception as e:
            # Mandatory call-boundary diagnostics (fail-safe).
            try:
                from audiomason.core.diagnostics import build_envelope
                from audiomason.core.events import get_event_bus

                get_event_bus().publish(
                    "plugin.load_failed",
                    build_envelope(
                        event="plugin.load_failed",
                        component="cmd_interface",
                        operation="web.startup",
                        data={
                            "plugin_id": selected_name or selected_dir.name,
                            "error_type": type(e).__name__,
                            "error_message": str(e),
                        },
                    ),
                )
            except Exception as diag_exc:
                if self.verbosity >= VerbosityLevel.DEBUG:
                    log.debug(
                        "Diagnostics emission failed for web plugin load: "
                        f"{type(diag_exc).__name__}: {diag_exc}"
                    )

            self._error(f"X Error loading web server plugin: {e}")
            raise SystemExit(1) from e

        exit_code = 0
        reason = "normal exit"
        try:
            # Pass ConfigResolver and PluginLoader
            web_plugin = cast(_WebPlugin, web_plugin)
            web_plugin.config_resolver = config_resolver
            web_plugin.plugin_loader = loader
            web_plugin.verbosity = self.verbosity

            if self.verbosity >= VerbosityLevel.DEBUG:
                log.debug("Web plugin initialized with:")
                log.debug(f"  - config_resolver: {type(config_resolver).__name__}")
                log.debug(f"  - plugin_loader: {type(loader).__name__}")
                log.debug(f"  - verbosity: {self.verbosity}")

            await web_plugin.run()
        except KeyboardInterrupt:
            exit_code = 130
            reason = "interrupted by user"
        except Exception as e:
            exit_code = 1
            reason = f"error: {type(e).__name__}: {e}"
            self._error(f"X Error starting web server: {e}")
            if self.verbosity >= VerbosityLevel.DEBUG:
                import traceback

                log.debug(traceback.format_exc())
        finally:
            if self.verbosity <= VerbosityLevel.QUIET:
                print(f"Finished (reason: {reason})", flush=True)
            else:
                self._info(f"Finished (reason: {reason})")
            raise SystemExit(exit_code)

    async def _daemon_command(self) -> None:
        """Start daemon mode."""
        self._debug(f"Starting daemon mode with verbosity: {self.verbosity}")
        self._info("\U0001f504 Starting daemon mode...")
        self._info("")

        plugins_dir = Path(__file__).parent.parent
        cfg = ConfigService()
        reg = PluginRegistry(cfg)
        loader = PluginLoader(builtin_plugins_dir=plugins_dir, registry=reg)

        daemon_plugin_dir = plugins_dir / "daemon"
        if not daemon_plugin_dir.exists():
            self._error("X Daemon plugin not found")
            return

        try:
            daemon_plugin_obj = loader.load_plugin(daemon_plugin_dir, validate=False)
            daemon_plugin = cast(_DaemonPlugin, daemon_plugin_obj)
            # Pass verbosity to daemon
            daemon_plugin.verbosity = self.verbosity
            await daemon_plugin.run()
        except Exception as e:
            self._error(f"X Error starting daemon: {e}")
            if self.verbosity >= VerbosityLevel.DEBUG:
                import traceback

                log.debug(traceback.format_exc())

    async def _checkpoints_command(self, args: list[str]) -> None:
        """Manage checkpoints.

        Args:
            args: Command arguments
        """
        from audiomason.checkpoint import CheckpointManager

        manager = CheckpointManager()

        if not args or args[0] == "list":
            # List checkpoints
            checkpoints = manager.list_checkpoints()

            if not checkpoints:
                print("No checkpoints found")
                return

            print("Available checkpoints:")
            print()
            for cp in checkpoints:
                progress_raw = cp.get("progress", 0.0)
                progress = float(progress_raw) if isinstance(progress_raw, int | float) else 0.0
                print(f"  {cp['id']}")
                print(f"    Title: {cp['title']}")
                print(f"    Author: {cp['author']}")
                print(f"    Progress: {progress * 100:.0f}%")
                print(f"    State: {cp['state']}")
                print()

        elif args[0] == "cleanup":
            # Cleanup old checkpoints
            days = 7
            if len(args) > 1 and args[1] == "--days":
                days = int(args[2])

            deleted = manager.cleanup_old_checkpoints(days=days)
            print(f"Deleted {deleted} checkpoint(s) older than {days} days")

    async def _tui_command(self) -> None:
        """Launch TUI interface."""
        self._debug(f"Launching TUI with verbosity level: {self.verbosity}")

        try:
            # Load TUI plugin
            plugins_dir = Path(__file__).parent.parent
            tui_dir = plugins_dir / "tui"

            if not tui_dir.exists():
                self._error("TUI plugin not found!")
                print("Install TUI plugin to use this feature.")
                return

            # Import and run
            sys.path.insert(0, str(tui_dir))
            from plugin import TUIPlugin as TUIPluginRaw  # type: ignore[import-not-found]

            # Pass verbosity level to TUI
            tui_plugin_factory = cast(_TUIPluginFactory, TUIPluginRaw)
            tui = tui_plugin_factory(config={"verbosity": self.verbosity})
            await tui.run()

        except ImportError as e:
            self._error(f"Failed to load TUI: {e}")
            print("\nTUI requires the 'curses' module.")
            print("On Windows, install: pip install windows-curses")
        except Exception as e:
            self._error(f"TUI error: {e}")
            import traceback

            if self.verbosity >= VerbosityLevel.DEBUG:
                log.debug(traceback.format_exc())
