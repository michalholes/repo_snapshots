"""Deterministic metadata projection for PHASE 1 import sessions.

ASCII-only.
"""

from __future__ import annotations

import re
import time
import unicodedata
from copy import deepcopy
from typing import TypeGuard, cast

from .metadata_boundary import validate_author_title


def _is_str_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    if not isinstance(value, dict):
        return False
    return all(isinstance(key, str) for key in cast(dict[object, object], value))


def _is_object_list(value: object) -> TypeGuard[list[object]]:
    return isinstance(value, list)


def _as_str_object_dict(value: object) -> dict[str, object]:
    return dict(value) if _is_str_object_dict(value) else {}


def _as_nested_str_object_dict(value: object) -> dict[str, dict[str, object]]:
    if not _is_str_object_dict(value):
        return {}
    return {key: _as_str_object_dict(item) for key, item in value.items()}


def _as_str_list(value: object) -> list[str]:
    if not _is_object_list(value):
        return []
    return [item for item in value if isinstance(item, str)]


def _as_str_str_dict(value: object) -> dict[str, str]:
    if not _is_str_object_dict(value):
        return {}
    out: dict[str, str] = {}
    for key, raw in value.items():
        if isinstance(raw, str) and raw:
            out[key] = raw
    return out


DEFAULT_FILENAME_POLICY: dict[str, object] = {"mode": "keep", "template": "{author}/{title}"}
DEFAULT_FIELD_MAP: dict[str, str] = {
    "title": "title",
    "artist": "artist",
    "album": "album",
    "album_artist": "album_artist",
}
_ROOT_AUDIO_AUTHOR = "__ROOT_AUDIO__"
_ROOT_AUDIO_TITLE = "Untitled"
_ROOT_SENTINELS = {"", "(root)"}
_ARCHIVE_SUFFIXES = (
    ".tar.bz2",
    ".tar.gz",
    ".tar",
    ".tgz",
    ".zip",
    ".rar",
    ".7z",
)
_TRAILING_TAG_RE = re.compile(r"(?:\s*(?:\([^)]*\)|\[[^]]*\]))+\s*$")
_DURATION_SUFFIX_RE = re.compile(r"\s*\(\d+h\d+m(?:\d+s)?\)\s*$", re.IGNORECASE)
_TITLE_TOKEN_RE = re.compile(r"[^a-z0-9]+")
_TITLE_STOPWORDS = {
    "a",
    "an",
    "and",
    "at",
    "do",
    "i",
    "in",
    "k",
    "konci",
    "na",
    "of",
    "po",
    "s",
    "the",
    "u",
    "v",
    "ve",
    "z",
}


def _ascii_fold(text: str) -> str:
    normalized = unicodedata.normalize("NFKD", text)
    return normalized.encode("ascii", "ignore").decode("ascii")


def _cleanup_whitespace(text: str) -> str:
    return " ".join(part for part in str(text).replace("_", " ").split() if part)


def _title_tokens_for_overlap(value: str) -> set[str]:
    folded = _ascii_fold(_cleanup_whitespace(value)).lower()
    tokens = {
        token for token in _TITLE_TOKEN_RE.split(folded) if token and token not in _TITLE_STOPWORDS
    }
    return tokens


def _prefer_source_title_if_translation(*, requested_title: str, suggested_title: str) -> str:
    requested = _cleanup_whitespace(requested_title)
    suggested = _cleanup_whitespace(suggested_title)
    if not requested or not suggested:
        return suggested or requested
    requested_tokens = _title_tokens_for_overlap(requested)
    suggested_tokens = _title_tokens_for_overlap(suggested)
    if not requested_tokens or not suggested_tokens:
        return suggested
    shared = len(requested_tokens & suggested_tokens)
    base = max(len(requested_tokens), len(suggested_tokens))
    overlap_ratio = float(shared) / float(base)
    if overlap_ratio < 0.45:
        return requested
    return suggested


def _strip_trailing_tags(text: str) -> str:
    previous = str(text)
    while True:
        updated = _TRAILING_TAG_RE.sub("", previous).strip()
        if updated == previous:
            return updated
        previous = updated


def _normalize_source_author_label(value: object) -> str:
    text = _cleanup_whitespace(str(value or ""))
    text = _strip_trailing_tags(text)
    if "," in text:
        parts = [part.strip() for part in text.split(",", 1)]
        if len(parts) == 2 and parts[0] and parts[1]:
            text = f"{parts[1]} {parts[0]}"
    text = _cleanup_whitespace(_ascii_fold(text))
    return text


def _normalize_source_title_label(*, author: str, value: object) -> str:
    raw = _cleanup_whitespace(str(value or ""))
    raw = _DURATION_SUFFIX_RE.sub("", raw).strip()
    raw = _strip_trailing_tags(raw)
    folded = _cleanup_whitespace(_ascii_fold(raw))
    folded_author = _cleanup_whitespace(_ascii_fold(author))
    if folded_author:
        lower_author = folded_author.lower()
        if folded.lower().startswith(lower_author + " - "):
            folded = folded[len(folded_author) + 3 :].strip()
        elif folded.lower().startswith(lower_author + "/"):
            folded = folded[len(folded_author) + 1 :].strip()
        else:
            author_tokens = [token for token in folded_author.split() if token]
            if len(author_tokens) >= 2:
                first = author_tokens[0]
                last = author_tokens[-1]
                initial = first[:1]
                prefix_patterns = (
                    f"{last} {initial} ",
                    f"{last}, {initial} ",
                    f"{last} {first} ",
                )
                lowered = folded.lower()
                for prefix in prefix_patterns:
                    if lowered.startswith(prefix.lower()):
                        folded = folded[len(prefix) :].strip()
                        break
    return _cleanup_whitespace(folded)


def _answer_dict(state: dict[str, object], key: str) -> dict[str, object]:
    answers = _as_str_object_dict(state.get("answers"))
    value = answers.get(key)
    return _as_str_object_dict(value)


def _author_overrides_by_book(
    *,
    source_projection: dict[str, object],
    state: dict[str, object],
    selected_book_ids: list[str],
) -> tuple[dict[str, str], dict[str, bool]]:
    vars_state = _as_str_object_dict(state.get("vars"))
    author_loop = _as_str_object_dict(vars_state.get("author_loop"))
    confirmed = _as_str_object_dict(author_loop.get("confirmed"))
    if not confirmed:
        return {}, {}

    selected_books_set = set(selected_book_ids)
    author_to_books_any = source_projection.get("author_to_books")
    author_to_books = _as_str_object_dict(author_to_books_any)
    selected_authors = _as_str_object_dict(source_projection.get("select_authors"))
    selected_author_ids = _as_str_list(selected_authors.get("selected_ids"))
    selected_author_labels = _as_str_list(selected_authors.get("selected_author_label_list"))

    default_by_author_id: dict[str, str] = {}
    for index, author_id in enumerate(selected_author_ids):
        if index < len(selected_author_labels):
            default_by_author_id[author_id] = str(selected_author_labels[index]).strip()

    overrides: dict[str, str] = {}
    manual_by_book: dict[str, bool] = {}
    for author_id in selected_author_ids:
        override = str(confirmed.get(author_id) or "").strip()
        if not override:
            continue
        default_author = str(default_by_author_id.get(author_id) or "").strip()
        manual_override = bool(default_author) and override != default_author
        book_ids = _as_str_list(author_to_books.get(author_id))
        for book_id in book_ids:
            if book_id in selected_books_set:
                overrides[book_id] = override
                manual_by_book[book_id] = manual_override
    return overrides, manual_by_book


def _title_overrides_by_book(
    *,
    source_projection: dict[str, object],
    state: dict[str, object],
    selected_book_ids: list[str],
) -> tuple[dict[str, str], dict[str, bool]]:
    vars_state = _as_str_object_dict(state.get("vars"))
    title_loop = _as_str_object_dict(vars_state.get("title_loop"))
    confirmed = _as_str_object_dict(title_loop.get("confirmed"))
    if not confirmed:
        return {}, {}

    selected_books = _as_str_object_dict(source_projection.get("select_books"))
    selected_ids = _as_str_list(selected_books.get("selected_ids"))
    selected_labels = _as_str_list(selected_books.get("selected_book_label_list"))
    selected_books_set = set(selected_book_ids)

    default_by_book_id: dict[str, str] = {}
    for index, book_id in enumerate(selected_ids):
        if index < len(selected_labels):
            default_by_book_id[book_id] = str(selected_labels[index]).strip()

    overrides: dict[str, str] = {}
    manual_by_book: dict[str, bool] = {}
    for book_id in selected_ids:
        if book_id not in selected_books_set:
            continue
        override = str(confirmed.get(book_id) or "").strip()
        if override:
            overrides[book_id] = override
            default_title = str(default_by_book_id.get(book_id) or "").strip()
            manual_by_book[book_id] = bool(default_title) and override != default_title
    return overrides, manual_by_book


def _normalize_root_audio_value(*, value: object, fallback: str) -> str:
    text = str(value or "").strip()
    if text in _ROOT_SENTINELS:
        return fallback
    return text or fallback


def _looks_like_archive_label(label: str) -> bool:
    lower = label.lower()
    return any(lower.endswith(suffix) for suffix in _ARCHIVE_SUFFIXES)


def _archive_virtual_author_title(
    *,
    source_relative_path: str,
) -> tuple[str | None, str | None]:
    parts = [part for part in str(source_relative_path).replace("\\", "/").split("/") if part]
    archive_index = -1
    for index, part in enumerate(parts):
        if _looks_like_archive_label(part):
            archive_index = index
            break
    if archive_index < 0 or archive_index + 1 >= len(parts):
        return None, None
    first_inside = parts[archive_index + 1]
    second_inside = parts[archive_index + 2] if archive_index + 2 < len(parts) else ""

    if second_inside:
        author_hint = _normalize_source_author_label(first_inside)
        title_hint = _normalize_source_title_label(author=author_hint, value=second_inside)
        return (author_hint or None, title_hint or None)

    single = _normalize_source_title_label(author="", value=first_inside)
    if " - " in single:
        left, right = single.split(" - ", 1)
        author_hint = _normalize_source_author_label(left)
        title_hint = _normalize_source_title_label(author=author_hint, value=right)
        return (author_hint or None, title_hint or None)
    return None, (single or None)


_VALIDATION_CACHE: dict[tuple[str, str], tuple[dict[str, object], dict[str, object]]] = {}


def _validation_cache_key(author: str, title: str) -> tuple[str, str]:
    author_key = " ".join(str(author).split()).casefold()
    title_key = " ".join(str(title).split()).casefold()
    return (author_key, title_key)


def _has_validation_signal(
    *,
    author_result: dict[str, object],
    book_result: dict[str, object],
) -> bool:
    if bool(author_result.get("valid")) or bool(book_result.get("valid")):
        return True

    author_suggestion = str(author_result.get("suggestion") or "").strip()
    author_canonical = str(author_result.get("canonical") or "").strip()
    if author_suggestion or author_canonical:
        return True

    for key in ("canonical", "suggestion"):
        candidate = book_result.get(key)
        if _is_str_object_dict(candidate):
            book_author = str(candidate.get("author") or "").strip()
            book_title = str(candidate.get("title") or "").strip()
            if book_author or book_title:
                return True
    return False


class _OpenLibraryValidateCallable:
    def cache_clear(self) -> None:
        _VALIDATION_CACHE.clear()

    def __call__(self, author: str, title: str) -> tuple[dict[str, object], dict[str, object]]:
        key = _validation_cache_key(author, title)
        cached = _VALIDATION_CACHE.get(key)
        if cached is not None:
            return dict(cached[0]), dict(cached[1])
        author_validation, book_validation = validate_author_title(author, title)
        if _has_validation_signal(author_result=author_validation, book_result=book_validation):
            _VALIDATION_CACHE[key] = (dict(author_validation), dict(book_validation))
        return dict(author_validation), dict(book_validation)


_openlibrary_validate = _OpenLibraryValidateCallable()


def _validated_author_title(*, author: str, title: str) -> tuple[dict[str, object], str, str]:
    author_validation: dict[str, object] = dict()
    book_validation: dict[str, object] = dict()
    for attempt in range(3):
        author_validation, book_validation = _openlibrary_validate(author, title)
        if _has_validation_signal(author_result=author_validation, book_result=book_validation):
            break
        if attempt < 2:
            time.sleep(0.2)

    canonical_author = str(author_validation.get("canonical") or author)
    suggestion_author = author_validation.get("suggestion")
    if isinstance(suggestion_author, str) and suggestion_author.strip():
        canonical_author = suggestion_author.strip()

    canonical_title = title
    canonical_book = book_validation.get("canonical")
    suggestion_book = book_validation.get("suggestion")
    if _is_str_object_dict(canonical_book):
        canonical_author = str(canonical_book.get("author") or canonical_author)
        canonical_title = str(canonical_book.get("title") or canonical_title)
    elif _is_str_object_dict(suggestion_book):
        canonical_author = str(suggestion_book.get("author") or canonical_author)
        canonical_title = str(suggestion_book.get("title") or canonical_title)

    canonical_author = _normalize_root_audio_value(
        value=canonical_author,
        fallback=_ROOT_AUDIO_AUTHOR,
    )
    canonical_title = _normalize_root_audio_value(
        value=canonical_title,
        fallback=_ROOT_AUDIO_TITLE,
    )
    canonical_title = _prefer_source_title_if_translation(
        requested_title=title,
        suggested_title=canonical_title,
    )

    return (
        {
            "provider": "metadata_openlibrary",
            "author": dict(author_validation),
            "book": dict(book_validation),
        },
        canonical_author,
        canonical_title,
    )


def _sanitize_validation_payload(result_any: object) -> dict[str, object] | None:
    if not _is_str_object_dict(result_any):
        return None
    return {
        "provider": str(result_any.get("provider") or "metadata_openlibrary"),
        "author": _as_str_object_dict(result_any.get("author")),
        "book": _as_str_object_dict(result_any.get("book")),
    }


def _canonicalize_validation_payload(
    *,
    validation: dict[str, object],
    fallback_author: str,
    fallback_title: str,
) -> tuple[dict[str, object], str, str]:
    canonical_author = str(fallback_author)
    author_payload = _as_str_object_dict(validation.get("author"))
    canonical_author_value = author_payload.get("canonical")
    suggestion_author = author_payload.get("suggestion")
    if isinstance(canonical_author_value, str) and canonical_author_value.strip():
        canonical_author = canonical_author_value.strip()
    if isinstance(suggestion_author, str) and suggestion_author.strip():
        canonical_author = suggestion_author.strip()

    canonical_title = str(fallback_title)
    book_payload = _as_str_object_dict(validation.get("book"))
    canonical_book = book_payload.get("canonical")
    suggestion_book = book_payload.get("suggestion")
    if _is_str_object_dict(canonical_book):
        canonical_author = str(canonical_book.get("author") or canonical_author)
        canonical_title = str(canonical_book.get("title") or canonical_title)
    elif _is_str_object_dict(suggestion_book):
        canonical_author = str(suggestion_book.get("author") or canonical_author)
        canonical_title = str(suggestion_book.get("title") or canonical_title)

    canonical_author = _normalize_root_audio_value(
        value=canonical_author,
        fallback=_ROOT_AUDIO_AUTHOR,
    )
    canonical_title = _normalize_root_audio_value(
        value=canonical_title,
        fallback=_ROOT_AUDIO_TITLE,
    )
    canonical_title = _prefer_source_title_if_translation(
        requested_title=fallback_title,
        suggested_title=canonical_title,
    )
    return validation, canonical_author, canonical_title


def _explicit_validation_from_state(
    state: dict[str, object],
) -> tuple[dict[str, object] | None, str | None, bool]:
    for step_id in (
        "metadata_validate_after_title",
        "metadata_validate_after_author",
        "metadata_validate_initial",
    ):
        answer = _answer_dict(state, step_id)
        if answer:
            validation = _sanitize_validation_payload(answer.get("result"))
            return validation, step_id, True
    return None, None, False


def _latest_validation_answer(state: dict[str, object]) -> tuple[dict[str, object], str | None]:
    for step_id in (
        "metadata_validate_after_title",
        "metadata_validate_after_author",
        "metadata_validate_initial",
    ):
        answer = _answer_dict(state, step_id)
        if answer:
            return answer, step_id
    return {}, None


def _suggested_author(validation: dict[str, object], fallback: str) -> str:
    author_payload = _as_str_object_dict(validation.get("author"))
    book_payload = _as_str_object_dict(validation.get("book"))
    for candidate in (
        author_payload.get("suggestion"),
        author_payload.get("canonical"),
    ):
        if isinstance(candidate, str) and candidate.strip():
            return _normalize_source_author_label(candidate)
    for candidate in (
        book_payload.get("suggestion"),
        book_payload.get("canonical"),
    ):
        if _is_str_object_dict(candidate):
            value = candidate.get("author")
            if isinstance(value, str) and value.strip():
                return _normalize_source_author_label(value)
    return _normalize_source_author_label(fallback)


def _suggested_title(
    validation: dict[str, object], fallback_author: str, fallback_title: str
) -> str:
    book_payload = _as_str_object_dict(validation.get("book"))
    for candidate in (
        book_payload.get("canonical"),
        book_payload.get("suggestion"),
    ):
        if _is_str_object_dict(candidate):
            value = candidate.get("title")
            if isinstance(value, str) and value.strip():
                return _normalize_source_title_label(author=fallback_author, value=value)
    return _normalize_source_title_label(author=fallback_author, value=fallback_title)


def _prompt_examples(*, primary: str, fallback: str) -> list[str]:
    examples: list[str] = []
    for value in (primary, fallback):
        text = str(value or "").strip()
        if text and text not in examples:
            examples.append(text)
    return examples


def _unique_examples(values: list[str], *, fallback: str) -> list[str]:
    examples: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in examples:
            examples.append(text)
    fallback_text = str(fallback or "").strip()
    if fallback_text and fallback_text not in examples:
        examples.append(fallback_text)
    return examples


def _validation_hint(
    *,
    validation: dict[str, object],
    answer: dict[str, object],
    normalized_author: str,
    normalized_title: str,
) -> tuple[str, list[str], list[str]]:
    if not answer:
        return (
            "Metadata lookup not available.",
            _prompt_examples(primary=normalized_author, fallback=normalized_author),
            _prompt_examples(primary=normalized_title, fallback=normalized_title),
        )
    error = _as_str_object_dict(answer.get("error"))
    if error:
        message = str(error.get("message") or error.get("type") or "lookup failed")
        hint = f"Metadata lookup failed: {message}"
        return (
            hint,
            _prompt_examples(primary=normalized_author, fallback=normalized_author),
            _prompt_examples(primary=normalized_title, fallback=normalized_title),
        )

    if not validation:
        return (
            "Metadata lookup found no stronger match.",
            _prompt_examples(primary=normalized_author, fallback=normalized_author),
            _prompt_examples(primary=normalized_title, fallback=normalized_title),
        )

    author_payload = _as_str_object_dict(validation.get("author"))
    book_payload = _as_str_object_dict(validation.get("book"))
    author_valid = bool(author_payload.get("valid"))
    book_valid = bool(book_payload.get("valid"))
    has_suggestion = any(
        value is not None
        for value in (
            author_payload.get("suggestion"),
            author_payload.get("canonical"),
            book_payload.get("suggestion"),
            book_payload.get("canonical"),
        )
    )
    suggested_author = _suggested_author(validation, normalized_author)
    suggested_title = _suggested_title(
        validation,
        fallback_author=suggested_author or normalized_author,
        fallback_title=normalized_title,
    )
    if author_valid and book_valid:
        hint = "Metadata lookup found a matching author and title."
    elif has_suggestion:
        hint = "Metadata lookup suggested canonical author/title."
    else:
        hint = "Metadata lookup found no stronger match."
    return (
        hint,
        _prompt_examples(primary=suggested_author, fallback=normalized_author),
        _prompt_examples(primary=suggested_title, fallback=normalized_title),
    )


def build_phase1_metadata_projection(
    *,
    source_projection: dict[str, object],
    state: dict[str, object],
) -> dict[str, object]:
    source_book_meta = _as_nested_str_object_dict(source_projection.get("book_meta"))
    selected = _as_str_object_dict(source_projection.get("select_books"))
    selected_ids = _as_str_list(selected.get("selected_ids"))
    selected_paths = _as_str_list(selected.get("selected_source_relative_paths"))
    (
        author_overrides_by_book,
        manual_author_overrides_by_book,
    ) = _author_overrides_by_book(
        source_projection=source_projection,
        state=state,
        selected_book_ids=selected_ids,
    )
    (
        title_overrides_by_book,
        manual_title_overrides_by_book,
    ) = _title_overrides_by_book(
        source_projection=source_projection,
        state=state,
        selected_book_ids=selected_ids,
    )

    validated_books: dict[str, dict[str, object]] = {}
    for book_id in selected_ids:
        source_book = _as_str_object_dict(source_book_meta.get(book_id))
        source_relative_path = str(source_book.get("source_relative_path") or "")
        source_author_label = str(source_book.get("author_label") or "")
        archive_author_hint, archive_title_hint = _archive_virtual_author_title(
            source_relative_path=source_relative_path
        )
        source_author_input: object = source_book.get("author_label")
        if _looks_like_archive_label(source_author_label) and archive_author_hint:
            source_author_input = archive_author_hint
        normalized_source_author = _normalize_source_author_label(source_author_input)
        source_author = _normalize_root_audio_value(
            value=normalized_source_author,
            fallback=_ROOT_AUDIO_AUTHOR,
        )
        source_title_input: object = source_book.get("book_label")
        if _looks_like_archive_label(source_author_label) and archive_title_hint:
            source_title_input = archive_title_hint
        normalized_source_title = _normalize_source_title_label(
            author=source_author,
            value=source_title_input,
        )
        source_title = _normalize_root_audio_value(
            value=normalized_source_title,
            fallback=_ROOT_AUDIO_TITLE,
        )
        validated_books[book_id] = {
            "source_author": source_author,
            "source_title": source_title,
            "author_label": source_author,
            "book_label": source_title,
            "display_label": (
                source_author
                if source_author == source_title
                else f"{source_author} / {source_title}"
            ),
            "source_relative_path": source_relative_path,
            "validation": {},
        }

    first_book = validated_books.get(selected_ids[0], {}) if selected_ids else {}
    source_author = str(first_book.get("source_author") or _ROOT_AUDIO_AUTHOR)
    source_title = str(first_book.get("source_title") or _ROOT_AUDIO_TITLE)

    author_answer = _answer_dict(state, "store_author_item")
    if not author_answer.get("author"):
        author_answer = _answer_dict(state, "effective_author")
    title_answer = _answer_dict(state, "store_title_item")
    if not title_answer.get("title"):
        title_answer = _answer_dict(state, "effective_title")
    merged_answer = _answer_dict(state, "effective_author_title")

    explicit_author_override_raw = author_answer.get("author")
    explicit_title_override_raw = title_answer.get("title")

    author_override_raw = explicit_author_override_raw
    if author_override_raw is None:
        author_override_raw = merged_answer.get("author")
    title_override_raw = explicit_title_override_raw
    if title_override_raw is None:
        title_override_raw = merged_answer.get("title")

    author_override_present = explicit_author_override_raw is not None
    title_override_present = explicit_title_override_raw is not None
    explicit_validation, explicit_validation_step, _ = _explicit_validation_from_state(state)

    if (
        explicit_validation is not None
        and not author_overrides_by_book
        and not title_overrides_by_book
    ):
        requested_author = _normalize_root_audio_value(
            value=(author_override_raw if author_override_present else source_author),
            fallback=source_author,
        )
        requested_title = _normalize_root_audio_value(
            value=(title_override_raw if title_override_present else source_title),
            fallback=source_title,
        )
        _, canonical_author, canonical_title = _canonicalize_validation_payload(
            validation=explicit_validation,
            fallback_author=requested_author,
            fallback_title=requested_title,
        )
        apply_title_from_validation = not (
            explicit_validation_step == "metadata_validate_after_author"
            and not title_override_present
        )
        target_ids: set[str] = set(selected_ids)
        if (
            explicit_validation_step == "metadata_validate_initial"
            and not author_override_present
            and not title_override_present
            and selected_ids
        ):
            target_ids = {selected_ids[0]}
        for book_id in target_ids:
            current = dict(validated_books.get(book_id) or {})
            current_title = str(current.get("book_label") or _ROOT_AUDIO_TITLE)
            applied_title = canonical_title if apply_title_from_validation else current_title
            validated_books[book_id] = {
                **current,
                "author_label": canonical_author,
                "book_label": applied_title,
                "display_label": (
                    canonical_author
                    if canonical_author == applied_title
                    else f"{canonical_author} / {applied_title}"
                ),
                "validation": dict(explicit_validation),
            }
    elif (
        author_overrides_by_book
        or title_overrides_by_book
        or author_override_present
        or title_override_present
    ):
        target_ids = set(selected_ids)
        vars_state = _as_str_object_dict(state.get("vars"))
        title_loop = _as_str_object_dict(vars_state.get("title_loop"))
        title_index_any = title_loop.get("index")
        if (
            isinstance(title_index_any, int)
            and not isinstance(title_index_any, bool)
            and 0 <= title_index_any < len(selected_ids)
        ):
            target_ids = {selected_ids[title_index_any]}
        elif (
            author_overrides_by_book
            and not title_overrides_by_book
            and not title_override_present
            and selected_ids
        ):
            # During author loop (before title loop starts), avoid network validation
            # fan-out across all selected books. Validate only the first book for
            # prompt quality; propagate deterministic overrides to the rest.
            target_ids = {selected_ids[0]}

        for book_id in selected_ids:
            current = dict(validated_books.get(book_id) or {})
            requested_author_source: object | None = author_overrides_by_book.get(book_id)
            if requested_author_source is None:
                if author_overrides_by_book:
                    requested_author_source = current.get("author_label")
                else:
                    requested_author_source = (
                        author_override_raw
                        if author_override_present
                        else current.get("author_label")
                    )
            requested_author = _normalize_root_audio_value(
                value=requested_author_source,
                fallback=str(current.get("author_label") or _ROOT_AUDIO_AUTHOR),
            )
            requested_title_source: object | None = title_overrides_by_book.get(book_id)
            if requested_title_source is None:
                if title_overrides_by_book:
                    requested_title_source = current.get("book_label")
                else:
                    requested_title_source = (
                        title_override_raw if title_override_present else current.get("book_label")
                    )
            requested_title = _normalize_root_audio_value(
                value=requested_title_source,
                fallback=str(current.get("book_label") or _ROOT_AUDIO_TITLE),
            )
            should_validate = book_id in target_ids
            if should_validate:
                validation, canonical_author, canonical_title = _validated_author_title(
                    author=requested_author,
                    title=requested_title,
                )
            else:
                validation = _as_str_object_dict(current.get("validation"))
                canonical_author = requested_author
                canonical_title = requested_title
            manual_override = bool(
                manual_author_overrides_by_book.get(book_id)
                or manual_title_overrides_by_book.get(book_id)
            )
            if manual_override:
                canonical_author = requested_author
                canonical_title = requested_title
            validated_books[book_id] = {
                **current,
                "author_label": canonical_author,
                "book_label": canonical_title,
                "display_label": (
                    canonical_author
                    if canonical_author == canonical_title
                    else f"{canonical_author} / {canonical_title}"
                ),
                "validation": validation,
            }

    effective_book = (
        _as_str_object_dict(validated_books.get(selected_ids[0])) if selected_ids else {}
    )
    normalized_author = _normalize_root_audio_value(
        value=effective_book.get("author_label"),
        fallback=_ROOT_AUDIO_AUTHOR,
    )
    normalized_book_title = _normalize_root_audio_value(
        value=effective_book.get("book_label"),
        fallback=_ROOT_AUDIO_TITLE,
    )
    effective_author_title = {
        "author": normalized_author,
        "title": normalized_book_title,
    }
    validation = _as_str_object_dict(effective_book.get("validation"))
    latest_validation_answer, _latest_validation_step = _latest_validation_answer(state)
    (
        author_prompt_hint,
        author_prompt_examples,
        title_prompt_examples,
    ) = _validation_hint(
        validation=validation,
        answer=latest_validation_answer,
        normalized_author=normalized_author,
        normalized_title=normalized_book_title,
    )
    title_prompt_hint = author_prompt_hint
    unique_authors = sorted(
        {
            str(book.get("author_label") or "").strip()
            for book in validated_books.values()
            if _is_str_object_dict(book) and str(book.get("author_label") or "").strip()
        }
    )
    unique_titles = sorted(
        {
            str(book.get("book_label") or "").strip()
            for book in validated_books.values()
            if _is_str_object_dict(book) and str(book.get("book_label") or "").strip()
        }
    )
    author_prompt_prefill = normalized_author if len(unique_authors) <= 1 else None
    title_prompt_prefill = normalized_book_title if len(unique_titles) <= 1 else None
    if len(unique_authors) > 1:
        author_prompt_hint = (
            "Multiple selected books have different authors. "
            "Leave blank to keep per-book authors, or enter a common author for all selected books."
        )
        author_prompt_examples = _unique_examples(
            unique_authors[:5],
            fallback=normalized_author,
        )
    if len(unique_titles) > 1:
        title_prompt_hint = (
            "Multiple selected books have different titles. "
            "Leave blank to keep per-book titles, or enter a common title for all selected books."
        )
        title_prompt_examples = _unique_examples(
            unique_titles[:5],
            fallback=normalized_book_title,
        )

    filename_policy: dict[str, object] = deepcopy(DEFAULT_FILENAME_POLICY)
    filename_policy.update(
        {
            "author": normalized_author,
            "title": normalized_book_title,
        }
    )
    filename_policy.update(_answer_dict(state, "filename_policy"))

    default_values = {
        "title": normalized_book_title,
        "artist": normalized_author,
        "album": normalized_book_title,
        "album_artist": normalized_author,
    }
    id3_policy: dict[str, object] = {
        "field_map": deepcopy(DEFAULT_FIELD_MAP),
        "values": default_values,
    }
    id3_policy.update(_answer_dict(state, "id3_policy"))
    field_map = _as_str_str_dict(id3_policy.get("field_map"))
    values = _as_str_str_dict(id3_policy.get("values"))

    return {
        "source_author": source_author,
        "book_title": source_title,
        "normalize_author": normalized_author,
        "normalize_book_title": normalized_book_title,
        "validation": validation,
        "author_prompt_hint": author_prompt_hint,
        "title_prompt_hint": title_prompt_hint,
        "author_prompt_examples": author_prompt_examples,
        "title_prompt_examples": title_prompt_examples,
        "author_prompt_prefill": author_prompt_prefill,
        "title_prompt_prefill": title_prompt_prefill,
        "effective_author_title": effective_author_title,
        "filename_policy": filename_policy,
        "field_map": field_map,
        "values": values,
        "selected_book_ids": selected_ids,
        "selected_source_relative_paths": selected_paths,
        "authority_by_book": validated_books,
    }
