from __future__ import annotations

import re
import sys
from collections.abc import Callable
from pathlib import Path

from .errors import RunnerError
from .gate_badguys import (
    DEFAULT_BADGUYS_COMMAND,
    resolve_badguys_workspaces_dir,
    run_amp_owned_badguys_gate,
    should_run_badguys,
)
from .gate_docs import check_docs_gate
from .gate_step_capture import GateStepCallback, run_logged_gate_step
from .gate_typescript import run_typescript_gate
from .gates_wiring_guard import assert_single_run_gates_callsite
from .log import Logger
from .monolith_gate import run_monolith_gate
from .pytest_bucket_routing import select_pytest_targets
from .python_gate_runtime import build_python_gate_env, resolve_python_gate_interpreter

_run_gates_wiring_checked = False


def _norm_targets(targets: list[str], fallback: list[str]) -> list[str]:
    out: list[str] = []
    for t in targets:
        s = str(t).strip()
        if s and s not in out:
            out.append(s)
    return out or list(fallback)


def _select_python_for_gate(**kwargs: object) -> str:
    repo_root_obj = kwargs.get("active_repository_tree_root")
    if repo_root_obj is None:
        repo_root_obj = kwargs["repo_root"]
    active_root = repo_root_obj if isinstance(repo_root_obj, Path) else Path(str(repo_root_obj))
    return resolve_python_gate_interpreter(
        active_repository_tree_root=active_root,
        python_gate_mode=str(kwargs.get("python_gate_mode", "auto")),
        python_gate_python=str(kwargs.get("python_gate_python", ".venv/bin/python")),
    )


def _cmd_py(module: str, *, python: str) -> list[str]:
    return [python, "-m", module]


def _norm_exclude_paths(exclude: list[str]) -> list[str]:
    out: list[str] = []
    for x in exclude:
        s = str(x).strip().replace("\\\\", "/")
        if s.startswith("./"):
            s = s[2:]
        s = s.strip("/")
        if s and s not in out:
            out.append(s)
    return out


def _compile_exclude_regex(exclude: list[str]) -> str | None:
    ex = _norm_exclude_paths(exclude)
    if not ex:
        return None
    parts = "|".join(re.escape(p) for p in ex)
    return rf"(^|/)({parts})(/|$)"


def _norm_rel_path(p: str) -> str:
    s = str(p).strip().replace("\\", "/")
    if s.startswith("./"):
        s = s[2:]
    s = s.strip("/")
    return s


def _norm_rel_paths(paths: list[str]) -> list[str]:
    out: list[str] = []
    for p in paths:
        s = _norm_rel_path(p)
        if s and s not in out:
            out.append(s)
    return out


def _norm_js_extensions(exts: list[str]) -> list[str]:
    out: list[str] = []
    for e in exts:
        s = str(e).strip().lower()
        if not s:
            continue
        if not s.startswith("."):
            s = "." + s
        if s not in out:
            out.append(s)
    return out


def check_js_gate(
    decision_paths: list[str],
    *,
    extensions: list[str],
) -> tuple[bool, list[str]]:
    """Return (triggered, js_paths).

    The gate triggers only if at least one changed path ends with one of the configured extensions.
    Returned js_paths are normalized repo-relative paths (forward slashes, no leading ./).
    """
    exts = _norm_js_extensions(extensions)
    if not exts:
        return False, []

    paths = _norm_rel_paths(decision_paths)
    js_paths: list[str] = []
    for p in paths:
        pl = p.lower()
        if any(pl.endswith(e) for e in exts):
            js_paths.append(p)

    if not js_paths:
        return False, []
    js_paths.sort()
    return True, js_paths


def run_js_syntax_gate(
    logger: Logger,
    cwd: Path,
    *,
    decision_paths: list[str],
    extensions: list[str],
    command: list[str],
) -> bool:
    """Run JS syntax validation via an external command (default: node --check).

    The gate is a no-op (SKIP) when no JS files are touched.
    """
    triggered, js_paths = check_js_gate(decision_paths, extensions=extensions)
    if not triggered:
        logger.warning_core("gate_js=SKIP (no_js_touched)")
        return True

    existing_js_paths: list[str] = []
    for rel in js_paths:
        if (cwd / rel).is_file():
            existing_js_paths.append(rel)

    if not existing_js_paths:
        logger.warning_core("gate_js=SKIP (no_existing_js_files)")
        return True

    cmd0 = [str(x) for x in command if str(x).strip()]
    if not cmd0:
        raise RunnerError("GATES", "JS_CMD", "gate_js_command must be non-empty")

    logger.section("GATE: JS SYNTAX")
    logger.line("gate_js_extensions=" + ",".join(_norm_js_extensions(extensions)))
    logger.line("gate_js_cmd=" + " ".join(cmd0))

    for rel in existing_js_paths:
        logger.line("gate_js_file=" + rel)
        r = logger.run_logged([*cmd0, rel], cwd=cwd)
        if r.returncode != 0:
            return False
    return True


def check_file_scoped_gate(
    decision_paths: list[str],
    *,
    extensions: list[str],
) -> tuple[bool, list[str]]:
    """Return (triggered, matched_paths).

    The gate triggers if at least one changed path ends with one of the extensions.
    Returned paths are normalized repo-relative paths (forward slashes, no leading ./).
    """
    exts = _norm_js_extensions(extensions)
    if not exts:
        return False, []

    paths = _norm_rel_paths(decision_paths)
    matched: list[str] = []
    for p in paths:
        pl = p.lower()
        if any(pl.endswith(e) for e in exts):
            matched.append(p)

    if not matched:
        return False, []
    matched.sort()
    return True, matched


def run_file_scoped_gate(
    logger: Logger,
    cwd: Path,
    *,
    name: str,
    decision_paths: list[str],
    extensions: list[str],
    command: list[str],
) -> bool:
    triggered, paths = check_file_scoped_gate(decision_paths, extensions=extensions)
    if not triggered:
        logger.warning_core(f"gate_{name}=SKIP (no_matching_files)")
        return True

    existing: list[str] = []
    for rel in paths:
        if (cwd / rel).is_file():
            existing.append(rel)

    if not existing:
        logger.warning_core(f"gate_{name}=SKIP (no_existing_files)")
        return True

    cmd0 = [str(x) for x in command if str(x).strip()]
    if not cmd0:
        raise RunnerError("GATES", "CMD", f"gate_{name}_command must be non-empty")

    logger.section(f"GATE: {name}")
    logger.line(f"gate_{name}_extensions=" + ",".join(_norm_js_extensions(extensions)))
    logger.line(f"gate_{name}_cmd=" + " ".join(cmd0))
    for rel in existing:
        logger.line(f"gate_{name}_file=" + rel)

    r = logger.run_logged([*cmd0, *existing], cwd=cwd)
    return r.returncode == 0


def run_ruff(
    logger: Logger,
    cwd: Path,
    *,
    repo_root: Path | None = None,
    active_repository_tree_root: Path | None = None,
    python_gate_mode: str = "auto",
    python_gate_python: str = ".venv/bin/python",
    ruff_format: bool,
    autofix: bool,
    targets: list[str],
    gate_step_callback: GateStepCallback | None = None,
) -> bool:
    targets = _norm_targets(targets, ["src", "tests"])
    py = _select_python_for_gate(
        repo_root=repo_root or cwd,
        active_repository_tree_root=active_repository_tree_root,
        python_gate_mode=python_gate_mode,
        python_gate_python=python_gate_python,
    )

    if ruff_format:
        logger.section("GATE: RUFF FORMAT")
        rfmt = run_logged_gate_step(
            logger,
            cwd,
            step_key="ruff_format",
            argv=_cmd_py("ruff", python=py) + ["format", *targets],
            callback=gate_step_callback,
            failure_dump_mode="warn_detail",
        )
        if rfmt.returncode != 0:
            return False

    logger.section("GATE: RUFF (initial)")
    r = logger.run_logged(
        _cmd_py("ruff", python=py) + ["check", *targets],
        cwd=cwd,
        failure_dump_mode="diagnostic_detail",
    )
    if r.returncode == 0:
        return True
    if not autofix:
        return False

    logger.section("GATE: RUFF (fix)")
    _ = run_logged_gate_step(
        logger,
        cwd,
        step_key="ruff_fix",
        argv=_cmd_py("ruff", python=py) + ["check", *targets, "--fix"],
        callback=gate_step_callback,
        failure_dump_mode="warn_detail",
    )

    logger.section("GATE: RUFF (final)")
    r2 = logger.run_logged(_cmd_py("ruff", python=py) + ["check", *targets], cwd=cwd)
    return r2.returncode == 0


def run_biome(
    logger: Logger,
    cwd: Path,
    *,
    decision_paths: list[str],
    extensions: list[str],
    command: list[str],
    biome_format: bool,
    format_command: list[str],
    autofix: bool,
    fix_command: list[str],
    gate_step_callback: GateStepCallback | None = None,
) -> bool:
    triggered, paths = check_file_scoped_gate(decision_paths, extensions=extensions)
    if not triggered:
        logger.warning_core("gate_biome=SKIP (no_matching_files)")
        return True

    existing: list[str] = []
    for rel in paths:
        if (cwd / rel).is_file():
            existing.append(rel)
    if not existing:
        logger.warning_core("gate_biome=SKIP (no_existing_files)")
        return True

    cmd0 = [str(x) for x in command if str(x).strip()]
    if not cmd0:
        raise RunnerError("GATES", "CMD", "gate_biome_command must be non-empty")

    if biome_format:
        fmt_cmd0 = [str(x) for x in format_command if str(x).strip()]
        if not fmt_cmd0:
            # Defensive fallback: older policy overlays may omit the format command.
            # Keep deterministic behavior by using the Policy default.
            fmt_cmd0 = ["npm", "exec", "--", "biome", "format", "--write"]

        logger.section("GATE: BIOME FORMAT")
        logger.line("gate_biome_format_cmd=" + " ".join(fmt_cmd0))
        r0 = run_logged_gate_step(
            logger,
            cwd,
            step_key="biome_format",
            argv=[*fmt_cmd0, *existing],
            callback=gate_step_callback,
            failure_dump_mode="warn_detail",
        )
        if r0.returncode != 0:
            return False

    logger.section("GATE: BIOME (check)")
    logger.line("gate_biome_extensions=" + ",".join(_norm_js_extensions(extensions)))
    logger.line("gate_biome_cmd=" + " ".join(cmd0))
    for rel in existing:
        logger.line("gate_biome_file=" + rel)

    r = logger.run_logged(
        [*cmd0, *existing],
        cwd=cwd,
        failure_dump_mode="diagnostic_detail",
    )
    if r.returncode == 0:
        return True
    if not autofix:
        return False

    fix_cmd0 = [str(x) for x in fix_command if str(x).strip()]
    if not fix_cmd0:
        raise RunnerError("GATES", "CMD", "gate_biome_fix_command must be non-empty")

    logger.section("GATE: BIOME_AUTOFIX (apply)")
    logger.line("gate_biome_fix_cmd=" + " ".join(fix_cmd0))
    _ = run_logged_gate_step(
        logger,
        cwd,
        step_key="biome_autofix",
        argv=[*fix_cmd0, *existing],
        callback=gate_step_callback,
        failure_dump_mode="warn_detail",
    )

    logger.section("GATE: BIOME (final)")
    r2 = logger.run_logged([*cmd0, *existing], cwd=cwd)
    return r2.returncode == 0


def run_pytest(
    logger: Logger,
    cwd: Path,
    *,
    repo_root: Path | None = None,
    active_repository_tree_root: Path | None = None,
    python_gate_mode: str = "auto",
    python_gate_python: str = ".venv/bin/python",
    pytest_use_venv: bool,
    targets: list[str],
) -> bool:
    targets = _norm_targets(targets, [])
    if not targets:
        raise RunnerError(
            "CONFIG",
            "PYTEST_TARGETS_EMPTY",
            "effective pytest target list is empty",
        )

    py = _select_python_for_gate(
        repo_root=repo_root or cwd,
        active_repository_tree_root=active_repository_tree_root,
        python_gate_mode=python_gate_mode,
        python_gate_python=python_gate_python,
    )

    logger.section("GATE: PYTEST")
    logger.line(f"pytest_use_venv={pytest_use_venv}")
    logger.line(f"sys_executable={sys.executable}")
    logger.line(f"pytest_python={py}")
    env = build_python_gate_env(python_exe=py)
    env["AM_PATCH_PYTEST_GATE"] = "1"
    r = logger.run_logged(_cmd_py("pytest", python=py) + ["-q", *targets], cwd=cwd, env=env)
    return r.returncode == 0


def run_mypy(
    logger: Logger,
    cwd: Path,
    *,
    active_repository_tree_root: Path,
    python_gate_mode: str,
    python_gate_python: str,
    targets: list[str],
) -> bool:
    targets = _norm_targets(targets, ["src"])
    py = resolve_python_gate_interpreter(
        active_repository_tree_root=active_repository_tree_root,
        python_gate_mode=python_gate_mode,
        python_gate_python=python_gate_python,
    )
    logger.section("GATE: MYPY")
    r = logger.run_logged(_cmd_py("mypy", python=py) + [*targets], cwd=cwd)
    return r.returncode == 0


def run_compile_check(
    logger: Logger,
    cwd: Path,
    *,
    active_repository_tree_root: Path,
    python_gate_mode: str,
    python_gate_python: str,
    targets: list[str],
    exclude: list[str],
) -> bool:
    """Compile Python sources to catch syntax errors early."""
    logger.section("GATE: compile")
    py = resolve_python_gate_interpreter(
        active_repository_tree_root=active_repository_tree_root,
        python_gate_mode=python_gate_mode,
        python_gate_python=python_gate_python,
    )
    logger.line(f"compile_python={py}")
    targets = _norm_targets(targets, ["."])
    exclude = _norm_exclude_paths(exclude)
    logger.line(f"compile_targets={targets}")
    logger.line(f"compile_exclude={exclude}")
    cmd: list[str] = [py, "-m", "compileall", "-q"]
    rx = _compile_exclude_regex(exclude)
    if rx:
        logger.line(f"compile_exclude_regex={rx}")
        cmd += ["-x", rx]
    cmd += targets
    r = logger.run_logged(cmd, cwd=cwd)
    return r.returncode == 0


def _norm_gate_name(s: str) -> str:
    return str(s).strip().lower()


def _norm_gates_order(order: list[str] | None) -> list[str]:
    if not order:
        return []
    allowed = {
        "dont-touch",
        "compile",
        "js",
        "biome",
        "typescript",
        "ruff",
        "pytest",
        "mypy",
        "docs",
        "monolith",
        "badguys",
    }
    out: list[str] = []
    for item in order:
        name = _norm_gate_name(item)
        if name in allowed and name not in out:
            out.append(name)
    return out


def run_gates(
    logger: Logger,
    cwd: Path,
    *,
    repo_root: Path,
    run_all: bool,
    compile_check: bool,
    compile_targets: list[str],
    compile_exclude: list[str],
    allow_fail: bool,
    skip_dont_touch: bool = False,
    dont_touch_paths: list[str] | None = None,
    skip_ruff: bool,
    skip_js: bool,
    skip_biome: bool = True,
    skip_typescript: bool = True,
    skip_pytest: bool,
    skip_mypy: bool,
    skip_docs: bool,
    skip_monolith: bool,
    skip_badguys: bool = False,
    gate_monolith_enabled: bool,
    gate_monolith_mode: str,
    gate_monolith_scan_scope: str,
    gate_monolith_extensions: list[str] | None = None,
    gate_monolith_compute_fanin: bool,
    gate_monolith_on_parse_error: str,
    gate_monolith_areas_prefixes: list[str],
    gate_monolith_areas_names: list[str],
    gate_monolith_areas_dynamic: list[str],
    gate_monolith_large_loc: int,
    gate_monolith_huge_loc: int,
    gate_monolith_large_allow_loc_increase: int,
    gate_monolith_huge_allow_loc_increase: int,
    gate_monolith_large_allow_exports_delta: int,
    gate_monolith_huge_allow_exports_delta: int,
    gate_monolith_large_allow_imports_delta: int,
    gate_monolith_huge_allow_imports_delta: int,
    gate_monolith_new_file_max_loc: int,
    gate_monolith_new_file_max_exports: int,
    gate_monolith_new_file_max_imports: int,
    gate_monolith_hub_fanin_delta: int,
    gate_monolith_hub_fanout_delta: int,
    gate_monolith_hub_exports_delta_min: int,
    gate_monolith_hub_loc_delta_min: int,
    gate_monolith_crossarea_min_distinct_areas: int,
    gate_monolith_catchall_basenames: list[str],
    gate_monolith_catchall_dirs: list[str],
    gate_monolith_catchall_allowlist: list[str],
    docs_include: list[str],
    docs_exclude: list[str],
    docs_required_files: list[str],
    docs_status_entries: list[tuple[str, str]] | None = None,
    js_extensions: list[str],
    js_command: list[str],
    biome_extensions: list[str] | None = None,
    biome_command: list[str] | None = None,
    biome_format: bool = True,
    biome_format_command: list[str] | None = None,
    biome_autofix: bool = True,
    biome_fix_command: list[str] | None = None,
    typescript_extensions: list[str] | None = None,
    typescript_command: list[str] | None = None,
    gate_typescript_mode: str = "auto",
    typescript_targets: list[str] | None = None,
    gate_typescript_base_tsconfig: str = "tsconfig.json",
    ruff_format: bool,
    ruff_autofix: bool,
    ruff_targets: list[str],
    pytest_targets: list[str],
    mypy_targets: list[str],
    gate_ruff_mode: str = "auto",
    gate_mypy_mode: str = "auto",
    gate_pytest_mode: str = "auto",
    gate_pytest_py_prefixes: list[str] | None = None,
    gate_pytest_js_prefixes: list[str] | None = None,
    gate_badguys_mode: str = "auto",
    gate_badguys_trigger_prefixes: list[str] | None = None,
    gate_badguys_trigger_files: list[str] | None = None,
    gate_badguys_command: list[str] | None = None,
    badguys_changed_entries: list[tuple[str, str]] | None = None,
    pytest_routing_policy: dict[str, object] | None = None,
    gates_order: list[str] | None,
    pytest_use_venv: bool,
    active_repository_tree_root: Path | None = None,
    workspaces_dir: Path | None = None,
    cli_mode: str = "finalize",
    issue_id: str | int | None = None,
    python_gate_mode: str = "auto",
    python_gate_python: str = ".venv/bin/python",
    decision_paths: list[str],
    progress: Callable[[str], None] | None = None,
    gate_step_callback: GateStepCallback | None = None,
) -> None:
    global _run_gates_wiring_checked
    if not _run_gates_wiring_checked:
        assert_single_run_gates_callsite()
        _run_gates_wiring_checked = True

    failures: list[str] = []
    skipped: list[str] = []
    active_tree_root = active_repository_tree_root or cwd

    order = _norm_gates_order(gates_order)
    biome_exts = biome_extensions or []
    biome_cmd = biome_command or []
    biome_fmt_cmd = biome_format_command or []
    biome_fix_cmd = biome_fix_command or []
    ts_exts = typescript_extensions or []
    ts_cmd = typescript_command or []
    ts_mode = str(gate_typescript_mode).strip()
    if ts_mode not in ("auto", "always"):
        raise RunnerError(
            "CONFIG",
            "INVALID_GATE_TYPESCRIPT_MODE",
            f"invalid gate_typescript_mode: {ts_mode!r}",
        )
    ts_targets = _norm_targets(typescript_targets or [], fallback=[])
    ts_base = str(gate_typescript_base_tsconfig).strip() or "tsconfig.json"
    if not order:
        logger.section("GATES: SKIPPED (gates_order empty)")
        logger.warning_core("GATES: SKIPPED (gates_order empty)")
        return

    _norm_decision_paths = [p.replace("\\", "/").lstrip("./") for p in decision_paths]
    gate_pytest_py_prefixes = gate_pytest_py_prefixes or []
    gate_pytest_js_prefixes = gate_pytest_js_prefixes or []

    def _has_changed_basename(names: tuple[str, ...]) -> bool:
        return any(pth in names for pth in _norm_decision_paths)

    def _has_changed_file(exts: tuple[str, ...], prefixes: list[str]) -> bool:
        norm_prefixes = [x.rstrip("/").lstrip("./") for x in prefixes if x]
        for pth in _norm_decision_paths:
            if not pth.endswith(exts):
                continue
            for pfx in norm_prefixes:
                if pth == pfx or pth.startswith(pfx + "/"):
                    return True
        return False

    def _run_gate(name: str) -> bool:
        if name == "dont-touch":
            if skip_dont_touch:
                skipped.append("dont-touch")
                logger.warning_core("gate_dont_touch=SKIP (skipped_by_user)")
                return True
            from .gate_dont_touch import run_dont_touch_gate

            logger.section("GATE: dont-touch")
            ok, reason = run_dont_touch_gate(
                decision_paths=decision_paths,
                protected_paths=list(dont_touch_paths or []),
            )
            if ok:
                logger.line("gate_dont_touch=OK")
                return True
            logger.error_core("gate_dont_touch=FAIL")
            if reason:
                logger.error_core(reason)
            return False

        if name == "compile":
            if not compile_check:
                skipped.append("compile")
                logger.warning_core("gate_compile=SKIP (disabled_by_policy)")
                return True
            return run_compile_check(
                logger,
                cwd=cwd,
                active_repository_tree_root=active_tree_root,
                python_gate_mode=python_gate_mode,
                python_gate_python=python_gate_python,
                targets=compile_targets,
                exclude=compile_exclude,
            )

        if name == "js":
            if skip_js:
                skipped.append("js")
                logger.warning_core("gate_js=SKIP (skipped_by_user)")
                return True
            return run_js_syntax_gate(
                logger,
                cwd=cwd,
                decision_paths=decision_paths,
                extensions=js_extensions,
                command=js_command,
            )

        if name == "biome":
            if skip_biome:
                skipped.append("biome")
                logger.warning_core("gate_biome=SKIP (skipped_by_user)")
                return True
            return run_biome(
                logger,
                cwd=cwd,
                decision_paths=decision_paths,
                extensions=biome_exts,
                command=biome_cmd,
                biome_format=biome_format,
                format_command=biome_fmt_cmd,
                autofix=biome_autofix,
                fix_command=biome_fix_cmd,
                gate_step_callback=gate_step_callback,
            )

        if name == "typescript":
            if skip_typescript:
                skipped.append("typescript")
                logger.warning_core("gate_typescript=SKIP (skipped_by_user)")
                return True
            return run_typescript_gate(
                logger,
                cwd,
                decision_paths=_norm_decision_paths,
                extensions=ts_exts,
                command=ts_cmd,
                mode=ts_mode,
                targets=ts_targets,
                base_tsconfig=ts_base,
            )

        if name == "ruff":
            if skip_ruff:
                skipped.append("ruff")
                logger.warning_core("gate_ruff=SKIP (skipped_by_user)")
                return True
            if gate_ruff_mode != "always":
                trigger = _has_changed_basename(("pyproject.toml",)) or _has_changed_file(
                    (".py",), ruff_targets
                )
                if not trigger:
                    skipped.append("ruff")
                    logger.warning_core("gate_ruff=SKIP (no_matching_files)")
                    return True
            return run_ruff(
                logger,
                cwd,
                active_repository_tree_root=active_tree_root,
                python_gate_mode=python_gate_mode,
                python_gate_python=python_gate_python,
                ruff_format=ruff_format,
                autofix=ruff_autofix,
                targets=ruff_targets,
                gate_step_callback=gate_step_callback,
            )

        if name == "pytest":
            if skip_pytest:
                skipped.append("pytest")
                logger.warning_core("gate_pytest=SKIP (skipped_by_user)")
                return True
            if gate_pytest_mode != "always":
                trigger_py = _has_changed_basename(
                    ("pyproject.toml", "pytest.ini")
                ) or _has_changed_file((".py",), gate_pytest_py_prefixes)
                trigger_js = bool(gate_pytest_js_prefixes) and _has_changed_file(
                    (".js", ".mjs", ".cjs"), gate_pytest_js_prefixes
                )
                if not trigger_py and not trigger_js:
                    skipped.append("pytest")
                    logger.warning_core("gate_pytest=SKIP (no_matching_files)")
                    return True
            pytest_targets_eff = select_pytest_targets(
                decision_paths=decision_paths,
                pytest_targets=pytest_targets,
                routing_policy=pytest_routing_policy,
                repo_root=repo_root,
            )
            try:
                return run_pytest(
                    logger,
                    cwd,
                    active_repository_tree_root=active_tree_root,
                    python_gate_mode=python_gate_mode,
                    python_gate_python=python_gate_python,
                    pytest_use_venv=pytest_use_venv,
                    targets=pytest_targets_eff,
                )
            except TypeError as exc:
                if "unexpected keyword argument" not in str(exc):
                    raise
                return run_pytest(
                    logger,
                    cwd,
                    repo_root=active_tree_root,
                    pytest_use_venv=pytest_use_venv,
                    targets=pytest_targets_eff,
                )

        if name == "mypy":
            if skip_mypy:
                skipped.append("mypy")
                logger.warning_core("gate_mypy=SKIP (skipped_by_user)")
                return True
            if gate_mypy_mode != "always":
                trigger = _has_changed_basename(("pyproject.toml",)) or _has_changed_file(
                    (".py",), mypy_targets
                )
                if not trigger:
                    skipped.append("mypy")
                    logger.warning_core("gate_mypy=SKIP (no_matching_files)")
                    return True
            return run_mypy(
                logger,
                cwd,
                active_repository_tree_root=active_tree_root,
                python_gate_mode=python_gate_mode,
                python_gate_python=python_gate_python,
                targets=mypy_targets,
            )

        if name == "monolith":
            if skip_monolith:
                skipped.append("monolith")
                logger.warning_core("gate_monolith=SKIP (skipped_by_user)")
                return True
            if not gate_monolith_enabled:
                skipped.append("monolith")
                logger.warning_core("gate_monolith=SKIP (disabled_by_policy)")
                return True
            return run_monolith_gate(
                logger,
                cwd,
                repo_root=repo_root,
                decision_paths=decision_paths,
                gate_monolith_mode=gate_monolith_mode,
                gate_monolith_scan_scope=gate_monolith_scan_scope,
                gate_monolith_extensions=gate_monolith_extensions,
                gate_monolith_compute_fanin=gate_monolith_compute_fanin,
                gate_monolith_on_parse_error=gate_monolith_on_parse_error,
                gate_monolith_areas_prefixes=gate_monolith_areas_prefixes,
                gate_monolith_areas_names=gate_monolith_areas_names,
                gate_monolith_areas_dynamic=gate_monolith_areas_dynamic,
                gate_monolith_large_loc=gate_monolith_large_loc,
                gate_monolith_huge_loc=gate_monolith_huge_loc,
                gate_monolith_large_allow_loc_increase=gate_monolith_large_allow_loc_increase,
                gate_monolith_huge_allow_loc_increase=gate_monolith_huge_allow_loc_increase,
                gate_monolith_large_allow_exports_delta=gate_monolith_large_allow_exports_delta,
                gate_monolith_huge_allow_exports_delta=gate_monolith_huge_allow_exports_delta,
                gate_monolith_large_allow_imports_delta=gate_monolith_large_allow_imports_delta,
                gate_monolith_huge_allow_imports_delta=gate_monolith_huge_allow_imports_delta,
                gate_monolith_new_file_max_loc=gate_monolith_new_file_max_loc,
                gate_monolith_new_file_max_exports=gate_monolith_new_file_max_exports,
                gate_monolith_new_file_max_imports=gate_monolith_new_file_max_imports,
                gate_monolith_hub_fanin_delta=gate_monolith_hub_fanin_delta,
                gate_monolith_hub_fanout_delta=gate_monolith_hub_fanout_delta,
                gate_monolith_hub_exports_delta_min=gate_monolith_hub_exports_delta_min,
                gate_monolith_hub_loc_delta_min=gate_monolith_hub_loc_delta_min,
                gate_monolith_crossarea_min_distinct_areas=(
                    gate_monolith_crossarea_min_distinct_areas
                ),
                gate_monolith_catchall_basenames=gate_monolith_catchall_basenames,
                gate_monolith_catchall_dirs=gate_monolith_catchall_dirs,
                gate_monolith_catchall_allowlist=gate_monolith_catchall_allowlist,
            )

        if name == "docs":
            if skip_docs:
                skipped.append("docs")
                logger.warning_core("gate_docs=SKIP (skipped_by_user)")
                return True
            ok, missing, trigger_reason = check_docs_gate(
                decision_paths,
                include=docs_include,
                exclude=docs_exclude,
                required_files=docs_required_files,
                changed_entries=docs_status_entries,
            )
            if ok:
                logger.line("gate_docs=OK")
                return True
            trig = trigger_reason or "unknown"
            logger.error_core("gate_docs=FAIL")
            logger.error_core("gate_docs_trigger=" + trig)
            logger.error_core("gate_docs_missing=" + ",".join(missing))
            return False

        if name == "badguys":
            if skip_badguys:
                skipped.append("badguys")
                logger.warning_core("gate_badguys=SKIP (skipped_by_user)")
                return True
            triggered, reason = should_run_badguys(
                decision_paths=decision_paths,
                mode=gate_badguys_mode,
                trigger_prefixes=gate_badguys_trigger_prefixes or [],
                trigger_files=gate_badguys_trigger_files or [],
            )
            if not triggered:
                skipped.append("badguys")
                logger.warning_core(f"gate_badguys=SKIP ({reason})")
                return True
            return run_amp_owned_badguys_gate(
                logger,
                cwd,
                repo_root=repo_root,
                command=list(gate_badguys_command or DEFAULT_BADGUYS_COMMAND),
                changed_entries=list(badguys_changed_entries or []),
                workspaces_dir=resolve_badguys_workspaces_dir(
                    repo_root=repo_root, workspaces_dir=workspaces_dir
                ),
                cli_mode=cli_mode,
                issue_id=issue_id,
            )

        return True

    for gate in (
        "dont-touch",
        "compile",
        "js",
        "biome",
        "typescript",
        "ruff",
        "pytest",
        "mypy",
        "docs",
        "monolith",
        "badguys",
    ):
        if gate not in order:
            skipped.append(gate)
            logger.warning_core(f"gate_{gate}=SKIP (not in gates_order)")

    for gate in order:
        stage = f"GATE_{gate.upper()}"
        if progress is not None:
            progress(f"DO:{stage}")
        ok = _run_gate(gate)
        if progress is not None:
            progress(f"OK:{stage}" if ok else f"FAIL:{stage}")
        if not ok:
            failures.append(gate)
            if not run_all:
                if allow_fail:
                    break
                raise RunnerError("GATES", "GATES", f"gate failed: {gate}")

    if failures and not allow_fail:
        raise RunnerError("GATES", "GATES", "gates failed: " + ", ".join(failures))

    if failures and allow_fail:
        logger.warning_core("gates_failed_allowed=true")
        logger.warning_core("gates_failed=" + ",".join(failures))
