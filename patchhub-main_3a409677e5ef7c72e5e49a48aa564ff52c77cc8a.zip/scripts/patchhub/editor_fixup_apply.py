from __future__ import annotations

from copy import deepcopy
from typing import cast

from .editor_codec import JsonValue, ObjectRecord, recompute_meta_counts, scaffold_object
from .editor_fixup_shared import CLIENT_ONLY_ACTIONS, EditorFixupError


def _sid(obj: ObjectRecord) -> str:
    return str(obj.get("id", "")).strip()


def _by_id(items: list[ObjectRecord], obj_id: str) -> ObjectRecord | None:
    return next((obj for obj in items if _sid(obj) == obj_id), None)


def _obj(items: list[ObjectRecord], obj_id: str) -> ObjectRecord:
    obj = _by_id(items, obj_id)
    if obj is None:
        raise EditorFixupError(f"Object not found: {obj_id}")
    return obj


def _items(items: list[ObjectRecord], kind: str) -> list[ObjectRecord]:
    return [obj for obj in items if obj.get("type") == kind]


def _obj_list(value: object) -> list[object]:
    if isinstance(value, list):
        return list(cast(list[object], value))
    if isinstance(value, tuple):
        return list(cast(tuple[object, ...], value))
    if isinstance(value, set):
        return list(cast(set[object], value))
    return []


def _iter_values(values: object) -> list[object]:
    if isinstance(values, list):
        return list(cast(list[object], values))
    if isinstance(values, tuple):
        return list(cast(tuple[object, ...], values))
    if isinstance(values, set):
        return list(cast(set[object], values))
    if values in (None, ""):
        return []
    return [values]


def _str_list(values: object) -> list[str]:
    return [str(x) for x in _iter_values(values)]


def _json_str_list(values: list[str]) -> list[JsonValue]:
    out: list[JsonValue] = []
    out.extend(values)
    return out


def _swap(values: object, old: str, new: str) -> list[JsonValue]:
    out: list[JsonValue] = []
    for item in _iter_values(values):
        out.append(new if str(item) == old else str(item))
    return out


def _drop(values: object, old: str) -> list[JsonValue]:
    out: list[JsonValue] = []
    for item in _iter_values(values):
        text = str(item)
        if text != old:
            out.append(text)
    return out


def _remove(items: list[ObjectRecord], obj_id: str) -> None:
    items[:] = [obj for obj in items if _sid(obj) != obj_id]


def _replace(items: list[ObjectRecord], obj_id: str, new_obj: ObjectRecord) -> None:
    for idx, obj in enumerate(items):
        if _sid(obj) == obj_id:
            items[idx] = new_obj
            return
    raise EditorFixupError(f"Object not found: {obj_id}")


def _unique(items: list[ObjectRecord], base: str) -> str:
    used = {_sid(obj) for obj in items}
    if base not in used:
        return base
    idx = 1
    while f"{base}.{idx}" in used:
        idx += 1
    return f"{base}.{idx}"


def _append(items: list[ObjectRecord], kind: str, preferred_id: str) -> ObjectRecord:
    obj = deepcopy(scaffold_object(kind))
    obj["id"] = _unique(items, preferred_id or str(obj.get("id", kind.upper() + ".NEW")))
    items.append(obj)
    return obj


def _first(items: list[ObjectRecord], kind: str, *, route_ref: str = "") -> ObjectRecord:
    matches = [obj for obj in items if obj.get("type") == kind]
    if route_ref:
        matches = [obj for obj in matches if str(obj.get("route_ref", "")) == route_ref]
    if not matches:
        raise EditorFixupError(f"No matching {kind} object found")
    return sorted(matches, key=_sid)[0]


def _first_id(items: list[ObjectRecord], kind: str) -> str:
    return _sid(_first(items, kind))


def _set_route_ref(obj: ObjectRecord, route_id: str) -> None:
    field = {
        "surface": "route_ref",
        "implementation": "implements_route",
        "workflow_step": "route_ref",
    }.get(str(obj.get("type", "")))
    if field is None:
        raise EditorFixupError("Object does not carry a route reference")
    obj[field] = route_id


FixContext = tuple[str, str, list[ObjectRecord]]


def apply_fix_action(
    *,
    action_id: str,
    objects: list[ObjectRecord],
    primary_id: str,
    secondary_id: str,
    loaded_objects: list[ObjectRecord],
) -> list[ObjectRecord]:
    if action_id in CLIENT_ONLY_ACTIONS:
        raise EditorFixupError(f"Action {action_id} is client-side only")
    items = deepcopy(objects)
    ctx = (primary_id.strip(), secondary_id.strip(), deepcopy(loaded_objects))
    _apply(items, ctx, action_id)
    recompute_meta_counts(items)
    return items


def _providers(items: list[ObjectRecord], route: ObjectRecord) -> list[ObjectRecord]:
    out: list[ObjectRecord] = []
    for provider_id in _str_list(route.get("provider_chain", [])):
        found = _by_id(items, provider_id)
        if found is not None:
            out.append(found)
    return out


def _missing_cap_id(items: list[ObjectRecord], primary_id: str) -> str:
    primary = _by_id(items, primary_id)
    field = (
        "requires_capabilities"
        if primary and primary.get("type") == "surface"
        else "covers_capabilities"
    )
    for cap_id in _obj_list((primary or {}).get(field, [])):
        if _by_id(items, str(cap_id)) is None:
            return str(cap_id)
    return "CAP.FIX"


def _apply(items: list[ObjectRecord], ctx: FixContext, action_id: str) -> None:
    primary_id, secondary_id, loaded_objects = ctx
    if action_id == "delete_unsaved_block":
        _remove(items, primary_id)
    elif action_id == "rename_current_id":
        _obj(items, primary_id)["id"] = _unique(items, primary_id + ".RENAMED")
    elif action_id == "revert_block":
        _replace(items, primary_id, deepcopy(_obj(loaded_objects, primary_id)))
    elif action_id in {"recreate_meta_block", "restore_last_loaded_meta"}:
        meta = next((obj for obj in loaded_objects if obj.get("type") == "meta"), None)
        items[:] = [obj for obj in items if obj.get("type") != "meta"]
        replacement = scaffold_object("meta") if action_id == "recreate_meta_block" else meta
        items.insert(0, deepcopy(replacement or scaffold_object("meta")))
    elif action_id == "merge_into_existing_binding_meta":
        keep_id = secondary_id or _first_id(items, "binding_meta")
        kept: list[ObjectRecord] = []
        seen = False
        for obj in items:
            if obj.get("type") != "binding_meta":
                kept.append(obj)
            elif not seen and str(obj.get("id", "")) == keep_id:
                kept.append(obj)
                seen = True
        items[:] = kept
    elif action_id == "create_binding_meta_block":
        _append(items, "binding_meta", "BINDING_META.NEW")
        items.insert(1 if items and items[0].get("type") == "meta" else 0, items.pop())
    elif action_id == "recompute_meta_counts":
        return
    elif action_id == "relink_rule_to_existing_capability":
        cap = _first(items, "capability")
        refs = _str_list(cap.get("triggers_rules", []))
        if primary_id not in refs:
            refs.append(primary_id)
        cap["triggers_rules"] = _json_str_list(refs)
    elif action_id == "create_companion_capability_block":
        cap = _append(items, "capability", "CAP.FIX")
        cap["triggers_rules"] = [primary_id]
        cap["name"] = primary_id
    elif action_id == "create_missing_rule_block":
        rule = _append(items, "rule", secondary_id or "RULE.FIX")
        rule["statement"] = f"Auto-created rule for {primary_id or rule['id']}"
    elif action_id == "relink_capability_rule_ref":
        cap = _obj(items, primary_id)
        rid = _first_id(items, "rule")
        cap["triggers_rules"] = _swap(cap.get("triggers_rules", []), secondary_id, rid)
    elif action_id == "remove_broken_rule_ref":
        cap = _obj(items, primary_id)
        cap["triggers_rules"] = _drop(cap.get("triggers_rules", []), secondary_id)
    elif action_id == "create_missing_capability_block":
        cap = _append(items, "capability", secondary_id or _missing_cap_id(items, primary_id))
        cap["name"] = cap["id"]
    elif action_id == "relink_route_capability_ref":
        route = _obj(items, primary_id)
        cid = _first_id(items, "capability")
        route["covers_capabilities"] = _swap(
            route.get("covers_capabilities", []),
            secondary_id,
            cid,
        )
    elif action_id == "remove_broken_route_capability_ref":
        route = _obj(items, primary_id)
        route["covers_capabilities"] = _drop(route.get("covers_capabilities", []), secondary_id)
    elif action_id == "add_provider_capability_coverage":
        route = _obj(items, primary_id)
        chain = _str_list(route.get("provider_chain", []))
        if not chain:
            raise EditorFixupError("Route has no provider_chain")
        provider = _obj(items, chain[-1])
        provided_caps = _str_list(provider.get("provides_capabilities", []))
        for cap_id in _obj_list(route.get("covers_capabilities", [])):
            if str(cap_id) not in provided_caps:
                provided_caps.append(str(cap_id))
        provider["provides_capabilities"] = _json_str_list(provided_caps)
    elif action_id == "create_provider_block":
        route = _obj(items, primary_id)
        provider = _append(items, "provider", "PROVIDER.FIX")
        provider["provides_capabilities"] = _json_str_list(
            _str_list(route.get("covers_capabilities", []))
        )
        chain = _str_list(route.get("provider_chain", []))
        chain.append(_sid(provider))
        route["provider_chain"] = _json_str_list(chain)
    elif action_id == "reduce_route_capabilities":
        route = _obj(items, primary_id)
        provided_ids = {
            str(cap_id)
            for provider in _providers(items, route)
            for cap_id in _obj_list(provider.get("provides_capabilities", []))
        }
        route_caps = _str_list(route.get("covers_capabilities", []))
        route["covers_capabilities"] = _json_str_list(
            [cap_id for cap_id in route_caps if cap_id in provided_ids]
        )
    elif action_id in {"select_existing_route_ref", "create_route_block"}:
        if action_id == "create_route_block":
            route = _append(items, "route", secondary_id or primary_id or "ROUTE.FIX")
            _set_route_ref(_obj(items, primary_id), _sid(route))
        else:
            _set_route_ref(_obj(items, primary_id), _first_id(items, "route"))
    elif action_id == "select_existing_capabilities":
        surface = _obj(items, primary_id)
        route_obj = _by_id(items, str(surface.get("route_ref", "")))
        cap_ids = [
            str(cap_id)
            for cap_id in _obj_list((route_obj or {}).get("covers_capabilities", []))
            if _by_id(items, str(cap_id))
        ]
        surface["requires_capabilities"] = _json_str_list(
            cap_ids or sorted(str(obj.get("id", "")) for obj in _items(items, "capability"))
        )
    elif action_id == "add_missing_declared_capabilities":
        impl = _obj(items, primary_id)
        route = _obj(items, str(impl.get("implements_route", "")))
        declared = _str_list(impl.get("declared_capabilities", []))
        for cap_id in _obj_list(route.get("covers_capabilities", [])):
            if str(cap_id) not in declared:
                declared.append(str(cap_id))
        impl["declared_capabilities"] = _json_str_list(declared)
    elif action_id in {"select_existing_oracle_ref", "create_oracle_block"}:
        if action_id == "create_oracle_block":
            oracle = _append(items, "oracle", secondary_id or "ORACLE.FIX")
            _obj(items, primary_id)["oracle_ref"] = oracle["id"]
        else:
            _obj(items, primary_id)["oracle_ref"] = _first_id(items, "oracle")
    elif action_id == "clear_current_entry_fields":
        step = _obj(items, primary_id)
        step["entry_scope"] = ""
        step["entry_mode"] = ""
    elif action_id == "create_transition_block":
        sid = str(_obj(items, primary_id).get("id", ""))
        steps = sorted(_items(items, "workflow_step"), key=_sid)
        other = next((obj for obj in steps if str(obj.get("id", "")) != sid), None)
        if other is None:
            raise EditorFixupError("At least two workflow steps are required")
        inbound = any(
            str(obj.get("to_step", "")) == sid for obj in _items(items, "workflow_transition")
        )
        trans = _append(items, "workflow_transition", "WORKFLOW_TRANSITION.FIX")
        other_id = str(other.get("id", ""))
        trans["from_step"], trans["to_step"] = (sid, other_id) if inbound else (other_id, sid)
    elif action_id == "create_invalidation_block":
        steps = sorted(_items(items, "workflow_step"), key=_sid)
        target = next(
            (
                obj
                for obj in steps
                if str(obj.get("id", "")) != primary_id and obj.get("root_marker")
            ),
            None,
        )
        target = target or next(
            (obj for obj in steps if str(obj.get("id", "")) != primary_id),
            None,
        )
        if target is None:
            raise EditorFixupError("No invalidation target available")
        inv = _append(items, "workflow_invalidation", "WORKFLOW_INVALIDATION.FIX")
        inv["failing_step"] = primary_id
        inv["invalidates_step"] = str(target.get("id", ""))
    elif action_id == "create_rollback_block":
        target = next(
            (obj for obj in _items(items, "workflow_step") if obj.get("root_marker")),
            None,
        )
        if target is None:
            raise EditorFixupError("No rollback target available")
        rb = _append(items, "workflow_rollback", "WORKFLOW_ROLLBACK.FIX")
        rb["from_step"] = primary_id
        rb["rollback_to_step"] = str(target.get("id", ""))
    elif action_id == "clear_rollback_required_flag":
        _obj(items, primary_id)["rollback_required"] = False
    elif action_id == "create_entry_gate_block":
        step = _obj(items, primary_id)
        gate = _append(items, "workflow_gate", "WORKFLOW_GATE.FIX")
        gate["step_ref"] = primary_id
        gate["gate_kind"] = "entry"
        gate["gate_capabilities"] = _json_str_list(_str_list(step.get("required_capabilities", [])))
        gate["gate_rule_ids"] = []
    elif action_id == "mark_workflow_step_root":
        step = _obj(items, primary_id)
        step["root_marker"] = True
        if not str(step.get("entry_scope", "")).strip():
            step["entry_scope"] = "implementation_scope"
        if not str(step.get("entry_mode", "")).strip():
            step["entry_mode"] = "final"
    elif action_id in {"create_workflow_step_for_surface", "create_workflow_step_for_route"}:
        source = _obj(items, primary_id)
        step = _append(items, "workflow_step", "WORKFLOW_STEP.FIX")
        if action_id.endswith("surface"):
            surface_id, route_id = primary_id, str(source.get("route_ref", ""))
            req_caps = _str_list(source.get("requires_capabilities", []))
        else:
            surface_id = str(_first(items, "surface", route_ref=primary_id).get("id", ""))
            route_id = primary_id
            req_caps = _str_list(source.get("covers_capabilities", []))
        step["display_name"] = primary_id
        step["branch"] = "editor_fix"
        step["route_ref"] = route_id
        step["surface_ref"] = surface_id
        step["required_capabilities"] = _json_str_list(req_caps)
    elif action_id == "relink_workflow_step_surface":
        step = _obj(items, primary_id)
        step["surface_ref"] = str(
            _first(
                items,
                "surface",
                route_ref=str(step.get("route_ref", "")),
            ).get("id", "")
        )
    elif action_id == "relink_workflow_step_route":
        step = _obj(items, primary_id)
        step["route_ref"] = str(_obj(items, str(step.get("surface_ref", ""))).get("route_ref", ""))
    else:
        raise EditorFixupError(f"Unknown action_id: {action_id}")
