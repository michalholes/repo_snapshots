from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, cast

from fastapi.responses import StreamingResponse

from .route_ui_snapshot import legacy_snapshot_payload

if TYPE_CHECKING:
    from .async_app_core import AsyncAppCore
    from .snapshot_change_broker import SnapshotChangeBroker


def _snapshot_state_from_indexer(core: AsyncAppCore) -> dict[str, object] | None:
    snap = core.indexer.get_ui_snapshot()
    if snap is None:
        return None
    return {
        "seq": int(getattr(snap, "seq", 0) or 0),
        "sigs": {
            "jobs": str(snap.jobs_sig),
            "runs": str(snap.runs_sig),
            "patches": str(snap.patches_sig),
            "workspaces": str(snap.workspaces_sig),
            "header": str(snap.header_sig),
            "operator_info": str(snap.operator_info_sig),
            "snapshot": str(snap.snapshot_sig),
        },
    }


async def _snapshot_state(core: AsyncAppCore) -> dict[str, object]:
    got = _snapshot_state_from_indexer(core)
    if got is not None:
        return got
    payload = await legacy_snapshot_payload(core)
    sigs_raw = payload.get("sigs")
    if not isinstance(sigs_raw, dict):
        return {"seq": 0, "sigs": {}}
    sigs_dict = cast(dict[object, object], sigs_raw)
    sigs = {str(key): str(value) for key, value in sigs_dict.items()}
    return {"seq": 0, "sigs": sigs}


async def build_snapshot_event_stream(
    *,
    core: AsyncAppCore,
    broker: SnapshotChangeBroker,
    ping_interval_s: float = 10.0,
) -> AsyncIterator[bytes]:
    state = await _snapshot_state(core)
    data = json.dumps(state, ensure_ascii=True)
    yield f"event: snapshot_state\ndata: {data}\n\n".encode()

    sub = broker.subscribe()
    while True:
        try:
            item = await asyncio.wait_for(sub.__anext__(), timeout=ping_interval_s)
        except StopAsyncIteration:
            return
        except TimeoutError:
            yield b": ping\n\n"
            continue
        payload = json.dumps(item, ensure_ascii=True)
        yield f"event: snapshot_changed\ndata: {payload}\n\n".encode()


async def handle_api_snapshot_events(
    core: AsyncAppCore,
    broker: SnapshotChangeBroker,
) -> StreamingResponse:
    return StreamingResponse(
        build_snapshot_event_stream(core=core, broker=broker),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"},
    )
