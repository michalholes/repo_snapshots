from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from am_patch.cli import CliArgs
from am_patch.config import Policy
from am_patch.errors import RunnerError
from am_patch.log import Logger
from am_patch.manifest import load_files
from am_patch.patch_archive_select import select_latest_issue_patch
from am_patch.patch_exec import precheck_patch_script
from am_patch.patch_select import (
    PatchSelectError,
    choose_default_patch_input,
    decide_unified_mode,
)
from am_patch.repo_root import is_under


@dataclass(frozen=True)
class PatchPlan:
    patch_script: Path
    unified_mode: bool
    files_declared: list[str]
    patch_target_repo_name: str | None = None


def _validate_repo_token(text: str) -> str:
    value = str(text).strip()
    if not value:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", "target.txt must be non-empty")
    if "\n" in value or "\r" in value:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", "target.txt must be a single line")
    if any(ch.isspace() for ch in value):
        raise RunnerError("PREFLIGHT", "PATCH_PATH", "target.txt must not contain whitespace")
    if "/" in value or "\\" in value:
        raise RunnerError(
            "PREFLIGHT",
            "PATCH_PATH",
            "target.txt must be a bare token (no path separators)",
        )
    try:
        value.encode("ascii")
    except UnicodeEncodeError as e:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", "target.txt must be ASCII-only") from e
    return value


def _read_zip_target_repo_name(zip_path: Path) -> str | None:
    try:
        with ZipFile(zip_path, "r") as zf:
            try:
                raw = zf.read("target.txt")
            except KeyError:
                return None
    except BadZipFile as e:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", f"invalid zip file: {zip_path} ({e})") from e
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError as e:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", "target.txt must be ASCII-only") from e
    if "\r" in text:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", "target.txt must use LF newlines")
    value = text[:-1] if text.endswith("\n") else text
    return _validate_repo_token(value)


def resolve_patch_plan(
    *,
    logger: Logger | None,
    cli: CliArgs,
    policy: Policy,
    issue_id: int,
    repo_root: Path,
    patch_root: Path,
) -> PatchPlan:
    patch_script: Path | None = None
    del logger, repo_root

    patch_script_arg = cli.patch_script

    if cli.load_latest_patch:
        hint_name = Path(patch_script_arg).name if patch_script_arg else None
        patch_script = select_latest_issue_patch(
            patch_dir=patch_root,
            issue_id=str(issue_id),
            hint_name=hint_name,
        )
    elif patch_script_arg:
        raw = Path(patch_script_arg)
        if raw.is_absolute():
            patch_script = raw
        else:
            cand_cwd = (Path.cwd() / raw).resolve()
            cand_patchdir = (patch_root / raw).resolve()
            if cand_cwd.exists() and is_under(cand_cwd, patch_root):
                patch_script = cand_cwd
            elif cand_patchdir.exists():
                patch_script = cand_patchdir
            else:
                raise RunnerError(
                    "PREFLIGHT",
                    "MANIFEST",
                    f"patch script not found (tried: {cand_cwd} and {cand_patchdir})",
                )
    else:
        try:
            patch_script = choose_default_patch_input(patch_root, issue_id)
        except PatchSelectError as e:
            raise RunnerError("PREFLIGHT", "MANIFEST", str(e)) from e

    assert patch_script is not None

    if not patch_script.exists():
        raise RunnerError("PREFLIGHT", "MANIFEST", f"patch script not found: {patch_script}")

    if not is_under(patch_script, patch_root):
        raise RunnerError(
            "PREFLIGHT",
            "PATCH_PATH",
            f"patch script must be under {patch_root} (got {patch_script})",
        )

    try:
        unified_mode = decide_unified_mode(
            patch_script,
            explicit_unified=bool(policy.unified_patch),
        )
    except PatchSelectError as e:
        raise RunnerError("PREFLIGHT", "PATCH_PATH", str(e)) from e

    if not unified_mode:
        precheck_patch_script(patch_script, ascii_only=policy.ascii_only_patch)

    files_declared: list[str] = [] if unified_mode else load_files(patch_script)
    patch_target_repo_name = (
        _read_zip_target_repo_name(patch_script) if patch_script.suffix == ".zip" else None
    )

    return PatchPlan(
        patch_script=patch_script,
        unified_mode=unified_mode,
        files_declared=files_declared,
        patch_target_repo_name=patch_target_repo_name,
    )
