from __future__ import annotations

# Recomputes constraint-pack workflow context via the canonical authority module.
import hashlib
import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypeAlias, cast

import __main__ as _m

if TYPE_CHECKING:
    from .type_aliases import JsonDict, JsonList
else:
    try:
        from .type_aliases import JsonDict, JsonList
    except ImportError:
        JsonDict: TypeAlias = dict[str, Any]
        JsonList: TypeAlias = list[JsonDict]

R = _m.RuleResult
VE = _m.ValidationError
_rz, _dar, _iz = _m._read_zip, _m._decode_ascii_raw, _m._iter_zip_files
AOP, IR, SBT = _m.AUTHORITY_ONLY_PATHS, _m.INSTRUCTIONS_REQUIRED, _m.SUPPORTED_BINDING_TYPES

REPO_SPEC_PATH = "governance/specification.jsonl"
GOVERNANCE_SPEC_PATH = "governance/governance.jsonl"
SUPPORTED_AUTHORITY_SOURCES = {REPO_SPEC_PATH, GOVERNANCE_SPEC_PATH}

if TYPE_CHECKING:
    from argparse import Namespace

    from .pm_validator import RuleResult


def _workspace_root_file_bytes(path: Path, relpath: str) -> bytes | None:
    file_path = path / Path(relpath)
    if not file_path.is_file():
        return None
    return file_path.read_bytes()


def _is_missing_repo_spec_error(err: str | None) -> bool:
    text = str(err or "").strip()
    return text.endswith(f":{REPO_SPEC_PATH}")


if TYPE_CHECKING or __package__:
    from .workflow_effective_context import (
        WorkflowEffectiveContextError,
        build_workflow_effective_context,
    )
else:
    from workflow_effective_context import (
        WorkflowEffectiveContextError,
        build_workflow_effective_context,
    )


def _supplemental_governance_workflow_bytes(args: Namespace) -> bytes:
    if args.repair_overlay:
        overlay = cast(dict[str, bytes], _iz(Path(args.repair_overlay)))
        if GOVERNANCE_SPEC_PATH in overlay:
            return overlay[GOVERNANCE_SPEC_PATH]
    if getattr(args, "workspace_root", None):
        raw = _workspace_root_file_bytes(Path(args.workspace_root), GOVERNANCE_SPEC_PATH)
        if raw is not None:
            return raw
    if args.workspace_snapshot:
        snapshot = cast(dict[str, bytes], _iz(Path(args.workspace_snapshot)))
        if GOVERNANCE_SPEC_PATH in snapshot:
            return snapshot[GOVERNANCE_SPEC_PATH]
    raise VE("missing_governance_workflow_source")


def _supported_authority_sources(pack: JsonDict) -> list[str]:
    sources = pack.get("authoritative_sources", [])
    if not isinstance(sources, list) or not sources:
        raise VE("pack_authoritative_sources_missing")
    out = []
    for item in sources:
        path = str(item or "").strip()
        if not path:
            raise VE("pack_authoritative_sources_empty")
        if path not in SUPPORTED_AUTHORITY_SOURCES:
            raise VE(f"pack_authoritative_source_unsupported:{path}")
        out.append(path)
    if len(out) != 1:
        raise VE(f"pack_authoritative_source_count:{len(out)}")
    return out


def _authority_source_bytes(args: Namespace, relpath: str) -> tuple[bytes | None, str | None]:
    if not args.repair_overlay:
        if getattr(args, "workspace_root", None):
            raw = _workspace_root_file_bytes(Path(args.workspace_root), relpath)
            if raw is not None:
                return raw, None
            return None, f"missing_source_in_workspace_root:{relpath}"
        snapshot = cast(dict[str, bytes], _iz(Path(args.workspace_snapshot)))
        if relpath in snapshot:
            return snapshot[relpath], None
        return None, f"missing_source_in_workspace_snapshot:{relpath}"
    overlay = cast(dict[str, bytes], _iz(Path(args.repair_overlay)))
    if relpath in overlay:
        return overlay[relpath], None
    if relpath in set(args.supplemental_file):
        if getattr(args, "workspace_root", None):
            raw = _workspace_root_file_bytes(Path(args.workspace_root), relpath)
            if raw is not None:
                return raw, None
            return None, f"supplemental_source_missing_in_workspace_root:{relpath}"
        if args.workspace_snapshot:
            snapshot = cast(dict[str, bytes], _iz(Path(args.workspace_snapshot)))
            if relpath in snapshot:
                return snapshot[relpath], None
            return None, f"supplemental_source_missing_in_snapshot:{relpath}"
    return None, f"missing_source_for_recompute:{relpath}"


BINDING_REQUIRED_FIELDS = (
    "id",
    "binding_type",
    "match",
    "symbol_role",
    "authoritative_semantics",
    "peer_renderers",
    "shared_contract_refs",
    "downstream_consumers",
    "exception_state_refs",
    "required_wiring",
    "forbidden",
    "required_validation",
    "verification_mode",
    "verification_method",
    "semantic_group",
    "conflict_policy",
    "oracle_ref",
)


def _rr(i: str, s: str, d: str) -> RuleResult:
    return cast("RuleResult", R(i, s, d))


def _decode_utf8_text(raw: bytes) -> str | None:
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _normalize_single_ascii_line(raw: bytes) -> tuple[str | None, str | None]:
    text = _dar(raw)
    if text is None:
        return None, "non_ascii"
    if "\r" in text:
        return None, "must_use_lf"
    value = text[:-1] if text.endswith("\n") else text
    if "\n" in value:
        return None, "must_have_exactly_one_line"
    return (None, "must_be_non_empty") if value == "" else (value, None)


def _su(bindings: JsonList, field: str) -> list[Any]:
    return sorted({i for b in bindings for i in b.get(field, [])})


def _bm(bindings: JsonList, key: str, value: str) -> dict[str, Any]:
    return {str(binding[key]): binding[value] for binding in bindings}


def _read_instructions_zip(
    path: str | Path | None,
) -> tuple[list[RuleResult], JsonDict | None, bytes | None, str | None]:
    if path is None or not Path(path).is_file():
        out = [
            _rr("INSTRUCTIONS_EXTENSION", "FAIL", "instructions_zip_not_found"),
            _rr("INSTRUCTIONS_LAYOUT", "FAIL", "missing_instructions_zip"),
            _rr("INSTRUCTIONS_HANDOFF", "FAIL", "missing_instructions_zip"),
            _rr("PACK_JSON", "FAIL", "missing_instructions_zip"),
            _rr("PACK_HASH_FILE", "FAIL", "missing_instructions_zip"),
            _rr("PACK_HASH_INTEGRITY", "FAIL", "hash_integrity_prerequisite_missing"),
        ]
        return out, None, None, None
    path = Path(path)
    out = [_rr("INSTRUCTIONS_EXTENSION", "PASS" if path.suffix == ".zip" else "FAIL", str(path))]
    if path.suffix != ".zip":
        out.extend(
            [
                _rr("INSTRUCTIONS_LAYOUT", "FAIL", "instructions_zip_not_zip"),
                _rr("INSTRUCTIONS_HANDOFF", "FAIL", "instructions_zip_not_zip"),
                _rr("PACK_JSON", "FAIL", "instructions_zip_not_zip"),
                _rr("PACK_HASH_FILE", "FAIL", "instructions_zip_not_zip"),
                _rr("PACK_HASH_INTEGRITY", "FAIL", "hash_integrity_prerequisite_missing"),
            ]
        )
        return out, None, None, None
    try:
        names, items = _rz(path)
    except Exception:
        out.extend(
            [
                _rr("INSTRUCTIONS_LAYOUT", "FAIL", "instructions_zip_unreadable"),
                _rr("INSTRUCTIONS_HANDOFF", "FAIL", "instructions_zip_unreadable"),
                _rr("PACK_JSON", "FAIL", "instructions_zip_unreadable"),
                _rr("PACK_HASH_FILE", "FAIL", "instructions_zip_unreadable"),
                _rr("PACK_HASH_INTEGRITY", "FAIL", "hash_integrity_prerequisite_missing"),
            ]
        )
        return out, None, None, None
    roots = sorted(name for name in names if not name.endswith("/"))
    ok = roots == sorted(IR)
    out.append(_rr("INSTRUCTIONS_LAYOUT", "PASS" if ok else "FAIL", f"entries={','.join(roots)}"))
    handoff = items.get("HANDOFF.md")
    pack_raw = items.get("constraint_pack.json")
    hash_raw = items.get("hash_pack.txt")
    hok = handoff is not None and _decode_utf8_text(handoff) is not None
    out.append(
        _rr(
            "INSTRUCTIONS_HANDOFF",
            "PASS" if hok else "FAIL",
            "handoff_readable" if hok else "missing_or_non_utf8_handoff",
        )
    )
    pack = None
    if pack_raw is None:
        out.append(_rr("PACK_JSON", "FAIL", "missing_pack_json"))
    else:
        try:
            pack = json.loads(pack_raw.decode("utf-8"))
            out.append(_rr("PACK_JSON", "PASS", "pack_json_readable"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            out.append(_rr("PACK_JSON", "FAIL", "invalid_pack_json"))
    hv, he = (
        (None, "missing_hash_pack") if hash_raw is None else _normalize_single_ascii_line(hash_raw)
    )
    out.append(_rr("PACK_HASH_FILE", "FAIL" if he else "PASS", he or hv or ""))
    if pack_raw is None or hv is None:
        out.append(_rr("PACK_HASH_INTEGRITY", "FAIL", "hash_integrity_prerequisite_missing"))
    else:
        actual = hashlib.sha256(pack_raw).hexdigest()
        out.append(
            _rr(
                "PACK_HASH_INTEGRITY",
                "PASS" if actual == hv else "FAIL",
                f"expected={hv}:actual={actual}",
            )
        )
    return out, pack, pack_raw, hv


def _load_jsonl_bytes(raw: bytes) -> JsonList:
    text = _decode_utf8_text(raw)
    if text is None:
        raise VE("spec_not_utf8")
    out = []
    for idx, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as exc:
            raise VE(f"spec_jsonl_invalid_line:{idx}:{exc.msg}") from exc
        if not isinstance(obj, dict):
            raise VE(f"spec_jsonl_non_object:{idx}")
        out.append(obj)
    return out


def _collect_binding_meta_and_bindings(
    objects: JsonList,
) -> tuple[JsonDict, JsonList, dict[str, JsonDict]]:
    meta: JsonDict | None = None
    bindings: JsonList = []
    oracles: dict[str, JsonDict] = {}
    for obj in objects:
        kind = obj.get("type")
        if kind == "binding_meta":
            if meta is not None:
                raise VE("binding_meta_duplicate")
            meta = obj
            continue
        if kind == "oracle":
            oid = str(obj.get("id", "")).strip()
            if not oid:
                raise VE("oracle_missing_id")
            if oid in oracles:
                raise VE(f"oracle_duplicate:{oid}")
            oracles[oid] = obj
            continue
        if kind != "obligation_binding":
            continue
        bid = str(obj.get("id", "<missing-id>"))
        missing = [field for field in BINDING_REQUIRED_FIELDS if field not in obj]
        if missing:
            raise VE(f"binding_missing_fields:{bid}:{','.join(missing)}")
        if obj["binding_type"] not in SBT:
            raise VE(f"binding_type_unsupported:{bid}:{obj['binding_type']}")
        for field in (
            "verification_mode",
            "verification_method",
            "semantic_group",
            "conflict_policy",
        ):
            if not str(obj.get(field, "")).strip():
                raise VE(f"binding_empty_field:{bid}:{field}")
        bindings.append(obj)
    if meta is None:
        raise VE("binding_meta_missing")
    return meta, bindings, oracles


def _binding_is_active(binding: JsonDict, mode: str, target_scope: str) -> bool:
    match = binding.get("match", {})
    return binding.get("binding_type") == "constraint_pack" or (
        match.get("phase") == mode and match.get("target") == target_scope
    )


def _ensure_binding_consistency(active_bindings: JsonList, oracles: dict[str, JsonDict]) -> None:
    if not active_bindings:
        raise VE("binding_active_missing")
    symbols: dict[tuple[str, str], list[str]] = {}
    semantics: dict[str, list[str]] = {}
    roles: dict[str, set[str]] = {}
    for binding in active_bindings:
        bid = str(binding.get("id", "<missing-id>"))
        ref = str(binding.get("oracle_ref", "")).strip()
        if not ref:
            raise VE(f"binding_missing_oracle_ref:{bid}")
        if ref not in oracles:
            raise VE(f"binding_unknown_oracle_ref:{bid}:{ref}")
        if binding.get("conflict_policy") != "fail_closed":
            raise VE(f"binding_conflict_policy:{bid}")
        key = json.dumps(binding.get("match", {}), sort_keys=True)
        role = str(binding.get("symbol_role", ""))
        sem = str(binding.get("authoritative_semantics", ""))
        symbols.setdefault((key, role), []).append(bid)
        semantics.setdefault(sem, []).append(bid)
        roles.setdefault(role, set()).add(sem)
    for ids in symbols.values():
        if len(ids) > 1:
            raise VE(f"binding_ambiguous_symbol:{','.join(sorted(ids))}")
    for ids in semantics.values():
        if len(ids) > 1:
            raise VE(f"binding_duplicate_semantics:{','.join(sorted(ids))}")
    for role, vals in roles.items():
        if len(vals) > 1:
            raise VE(f"binding_conflicting_obligations:{role}")


def _resolve_workflow_contract(objects: JsonList, target_scope: str, mode: str) -> JsonDict:
    steps = [obj for obj in objects if obj.get("type") == "workflow_step"]
    transitions = [obj for obj in objects if obj.get("type") == "workflow_transition"]
    gates = [obj for obj in objects if obj.get("type") == "workflow_gate"]
    rollbacks = [obj for obj in objects if obj.get("type") == "workflow_rollback"]
    candidates = [
        step
        for step in steps
        if ("" if step.get("entry_scope") is None else str(step.get("entry_scope", "")).strip())
        == target_scope
        and ("" if step.get("entry_mode") is None else str(step.get("entry_mode", "")).strip())
        == mode
    ]
    if not candidates:
        raise VE(f"workflow_entry_missing:{target_scope}:{mode}")
    if len(candidates) > 1:
        raise VE(f"workflow_entry_ambiguous:{target_scope}:{mode}")
    step = candidates[0]
    step_id = str(step.get("id", "")).strip()
    next_steps = [
        str(item.get("to_step", "")).strip()
        for item in transitions
        if str(item.get("from_step", "")).strip() == step_id
    ]
    required_gates = [
        str(item.get("id", "")).strip()
        for item in gates
        if str(item.get("step_ref", "")).strip() == step_id
        and str(item.get("gate_kind", "")).strip() == "entry"
    ]
    rollback_contract = [
        {
            "id": str(item.get("id", "")).strip(),
            "rollback_to_step": str(item.get("rollback_to_step", "")).strip(),
        }
        for item in rollbacks
        if str(item.get("from_step", "")).strip() == step_id
    ]
    title = str(step.get("display_name", step_id)).strip() or step_id
    surface_ref = str(step.get("surface_ref", "")).strip()
    route_ref = str(step.get("route_ref", "")).strip()
    required_capabilities = [str(item) for item in step.get("required_capabilities", [])]
    summary = (
        f"entry_step={title}; surface={surface_ref}; route={route_ref}; "
        f"required_gates={required_gates}; next_steps={next_steps}"
    )
    return {
        "workflow_entry_step_id": step_id,
        "workflow_entry_title": title,
        "workflow_entry_surface": surface_ref,
        "workflow_entry_route": route_ref,
        "workflow_entry_required_capabilities": required_capabilities,
        "allowed_next_steps": next_steps,
        "required_gates": required_gates,
        "rollback_contract": rollback_contract,
        "workflow_human_summary": summary,
    }


def _build_pack_from_spec_bytes(
    spec_raw: bytes,
    mode: str,
    target_scope: str,
    source_path: str,
    governance_workflow_raw: bytes | None = None,
) -> tuple[bytes, str, JsonList]:
    objs = _load_jsonl_bytes(spec_raw)
    if not objs or objs[0].get("type") != "meta":
        raise VE("spec_meta_missing")
    meta, bindings, oracles = _collect_binding_meta_and_bindings(objs)
    active = [b for b in bindings if _binding_is_active(b, mode, target_scope)]
    _ensure_binding_consistency(active, oracles)
    workflow_objects = objs
    if target_scope == "implementation_scope" and not any(
        obj.get("type") == "workflow_step" for obj in objs
    ):
        if governance_workflow_raw is None:
            raise VE("missing_governance_workflow_source")
        workflow_objects = _load_jsonl_bytes(governance_workflow_raw)
    workflow_contract = _resolve_workflow_contract(workflow_objects, target_scope, mode)
    try:
        workflow_effective = build_workflow_effective_context(
            workflow_objects,
            workflow_contract["workflow_entry_step_id"],
        )
    except WorkflowEffectiveContextError as exc:
        raise VE(str(exc)) from exc
    pack = {
        "target_symbol": None,
        "target_scope": target_scope,
        "mode": mode,
        "spec_fingerprint": hashlib.sha256(spec_raw).hexdigest(),
        "binding_meta_id": meta["id"],
        "active_bindings": active,
        "active_rule_ids": [binding["id"] for binding in active],
        "full_rule_text": _bm(active, "id", "authoritative_semantics"),
        "match_basis": {binding["id"]: binding.get("match", {}) for binding in active},
        "authoritative_sources": [source_path],
        "shared_contracts": _su(active, "shared_contract_refs"),
        "downstream_consumers": _su(active, "downstream_consumers"),
        "exception_state_refs": _su(active, "exception_state_refs"),
        "required_wiring": _su(active, "required_wiring"),
        "forbidden_strategies": _su(active, "forbidden"),
        "required_validation": _su(active, "required_validation"),
        "verification_mode_per_rule": _bm(active, "id", "verification_mode"),
        "verification_method_per_rule": _bm(active, "id", "verification_method"),
        "oracle_refs": {binding["id"]: binding.get("oracle_ref") for binding in active},
        "aggregate_scope_metadata": {
            "binding_count": len(active),
            "mode": mode,
            "target_scope": target_scope,
        },
        **workflow_contract,
        "workflow_effective_step_ids": workflow_effective["effective_step_ids"],
        "workflow_effective_capabilities": workflow_effective["effective_capabilities"],
        "workflow_effective_rule_ids": workflow_effective["effective_rule_ids"],
        "workflow_effective_full_rule_text": workflow_effective["effective_full_rule_text"],
    }
    raw = (json.dumps(pack, indent=2, sort_keys=True, ensure_ascii=True) + "\n").encode("utf-8")
    return raw, hashlib.sha256(raw).hexdigest(), active


def _authority_spec_bytes(
    args: Namespace, pack: JsonDict
) -> tuple[bytes | None, str | None, str | None]:
    try:
        sources = _supported_authority_sources(pack)
    except VE as exc:
        return None, str(exc), None
    source_path = sources[0]
    spec_raw, err = _authority_source_bytes(args, source_path)
    return spec_raw, err, source_path


def _pack_union_rule(
    rule_id: str, pack: JsonDict, key: str, active_bindings: JsonList, field: str
) -> RuleResult:
    exp, act = _su(active_bindings, field), sorted(pack.get(key, []))
    return _rr(rule_id, "PASS" if act == exp else "FAIL", f"expected={exp}:actual={act}")


def _scope_mapping_rule(decision_paths: list[str], pack: JsonDict) -> RuleResult:
    scope = str(pack.get("target_scope", ""))
    if not decision_paths:
        return _rr("PACK_SCOPE_MAPPING", "FAIL", "no_patch_paths")
    if scope == "authority_scope":
        bad = [path for path in decision_paths if path not in AOP]
        return _rr(
            "PACK_SCOPE_MAPPING",
            "PASS" if not bad else "FAIL",
            "authority_paths_ok" if not bad else f"out_of_scope={bad}",
        )
    if scope == "implementation_scope":
        bad = [p for p in decision_paths if p in AOP]
        return _rr(
            "PACK_SCOPE_MAPPING",
            "PASS" if not bad else "FAIL",
            "implementation_paths_ok" if not bad else f"authority_paths={bad}",
        )
    return _rr("PACK_SCOPE_MAPPING", "FAIL", f"unsupported_target_scope:{scope}")


def _forbidden_bypass_rule(
    patch_member_names: list[str], pack: JsonDict, active_bindings: JsonList
) -> RuleResult:
    exp, act = _su(active_bindings, "forbidden"), sorted(pack.get("forbidden_strategies", []))
    if act != exp:
        return _rr("PACK_FORBIDDEN_BYPASS", "FAIL", f"expected={exp}:actual={act}")
    blocked = {"HANDOFF.md", "constraint_pack.json", "hash_pack.txt"}
    leaked = [name for name in patch_member_names if any(item in name for item in blocked)]
    if leaked:
        return _rr(
            "PACK_FORBIDDEN_BYPASS", "FAIL", f"patch_contains_instruction_artifacts:{leaked}"
        )
    return _rr("PACK_FORBIDDEN_BYPASS", "PASS", "forbidden_bypass_checks_ok")


def _recompute_pack_rule(
    args: Namespace, pack: JsonDict, pack_raw: bytes | None
) -> tuple[RuleResult, JsonList | None]:
    spec_raw, err, source_path = _authority_spec_bytes(args, pack)
    if err is not None or spec_raw is None or source_path is None:
        status = "SKIP" if _is_missing_repo_spec_error(err) else "UNVERIFIED_ENVIRONMENT"
        detail = (
            "missing_repo_specification_jsonl"
            if _is_missing_repo_spec_error(err)
            else (err or "missing_authority_spec")
        )
        return _rr("PACK_RECOMPUTE", status, detail), None
    mode, scope = str(pack.get("mode", "")), str(pack.get("target_scope", ""))
    if not mode or not scope:
        return _rr("PACK_RECOMPUTE", "FAIL", "missing_mode_or_target_scope"), None
    try:
        governance_workflow_raw = None
        if scope == "implementation_scope" and source_path != GOVERNANCE_SPEC_PATH:
            governance_workflow_raw = _supplemental_governance_workflow_bytes(args)
        rebuilt, _rebuilt_hash, active = _build_pack_from_spec_bytes(
            spec_raw,
            mode,
            scope,
            source_path,
            governance_workflow_raw=governance_workflow_raw,
        )
    except VE as exc:
        return _rr("PACK_RECOMPUTE", "FAIL", str(exc)), None
    if pack_raw is None:
        return _rr("PACK_RECOMPUTE", "FAIL", "missing_pack_bytes"), active
    status = "PASS" if rebuilt == pack_raw else "FAIL"
    return _rr(
        "PACK_RECOMPUTE", status, "recompute_match" if status == "PASS" else "recompute_mismatch"
    ), active


def _pack_rule_verdicts(
    pack: JsonDict, active_bindings: JsonList, support_rules: dict[str, RuleResult]
) -> list[RuleResult]:
    out: list[RuleResult] = []
    bindings = active_bindings if active_bindings is not None else pack.get("active_bindings", [])
    for binding in bindings:
        bid = str(binding.get("id", "<missing-id>"))
        mode = str(binding.get("verification_mode", "")).strip()
        if not mode:
            out.append(_rr(f"PACK_RULE:{bid}", "FAIL", "missing_verification_mode"))
            continue
        if mode != "machine":
            out.append(_rr(f"PACK_RULE:{bid}", "MANUAL_REVIEW_REQUIRED", f"mode={mode}"))
            continue
        fail = [rule for rule in support_rules.values() if rule.status != "PASS"]
        if fail:
            first = fail[0]
            status = (
                first.status
                if first.status in {"SKIP", "UNVERIFIED_ENVIRONMENT", "MANUAL_REVIEW_REQUIRED"}
                else "FAIL"
            )
            out.append(_rr(f"PACK_RULE:{bid}", status, first.rule_id))
            continue
        detail = (
            f"mode={binding.get('verification_mode')} method={binding.get('verification_method')}"
        )
        out.append(_rr(f"PACK_RULE:{bid}", "PASS", detail))
    return out


def _verdict_coverage_rule(pack: JsonDict, verdicts: list[RuleResult]) -> RuleResult:
    exp = sorted(str(b.get("id", "<missing-id>")) for b in pack.get("active_bindings", []))
    act = sorted(v.rule_id.split(":", 1)[1] for v in verdicts if v.rule_id.startswith("PACK_RULE:"))
    return _rr(
        "PACK_VERDICT_COVERAGE", "PASS" if act == exp else "FAIL", f"expected={exp}:actual={act}"
    )


def _pack_rules(
    args: Namespace,
    instructions_path: str | Path | None,
    decision_paths: list[str],
    patch_member_names: list[str],
) -> tuple[list[RuleResult], JsonDict | None]:
    out, pack, pack_raw, _hash_value = _read_instructions_zip(instructions_path)
    if pack is None:
        return out, None
    recompute, active = _recompute_pack_rule(args, pack, pack_raw)
    out.append(recompute)
    active = pack.get("active_bindings", []) if active is None else active
    out.append(
        _pack_union_rule("PACK_REQUIRED_WIRING", pack, "required_wiring", active, "required_wiring")
    )
    out.append(_forbidden_bypass_rule(patch_member_names, pack, active))
    out.append(
        _pack_union_rule(
            "PACK_DOWNSTREAM_COVERAGE", pack, "downstream_consumers", active, "downstream_consumers"
        )
    )
    out.append(
        _pack_union_rule(
            "PACK_REQUIRED_VALIDATION", pack, "required_validation", active, "required_validation"
        )
    )
    out.append(_scope_mapping_rule(decision_paths, pack))
    watch = {
        "PACK_HASH_INTEGRITY",
        "PACK_RECOMPUTE",
        "PACK_REQUIRED_WIRING",
        "PACK_FORBIDDEN_BYPASS",
        "PACK_DOWNSTREAM_COVERAGE",
        "PACK_REQUIRED_VALIDATION",
        "PACK_SCOPE_MAPPING",
    }
    support = {rule.rule_id: rule for rule in out if rule.rule_id in watch}
    verdicts = _pack_rule_verdicts(pack, active, support)
    out.extend(verdicts)
    out.append(_verdict_coverage_rule(pack, verdicts))
    return out, pack
